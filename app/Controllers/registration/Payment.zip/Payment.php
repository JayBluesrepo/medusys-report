<?php 
namespace App\Controllers\registration;
use App\Controllers\BaseController;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\RegisterUserModel;

class Payment extends BaseController
{
    public function index()
    {
        $new_user_id = session()->get('new_user_id');
        $model = new RegisterUserModel();
        $details = $model->where('id',$new_user_id)->first();
        $data['usercheck'] = $details;

        $model->where('id',$new_user_id);
        $details1 = $model->where('verify_email',1)->first();
        $data['otpmatched'] = $details1;

        return view('registration/payment',$data);
    }
}
?>