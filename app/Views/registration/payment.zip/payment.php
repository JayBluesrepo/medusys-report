<?php echo view("includes/header-mels"); ?>

<div class="top-dots">
	<?php if($usercheck){ ?>
		<i class="fa fa-check-circle-o fa-lg mr-2" aria-hidden="true" style="color:light-green;"></i>
	<?php }else{ ?>
		<i class="fa fa-circle-thin fa-lg mr-2" aria-hidden="true"></i>
	<?php }; ?>
	<?php if($otpmatched){ ?>
		<i class="fa fa-check-circle-o fa-lg mr-2" aria-hidden="true" style="color:light-green;"></i>
	<?php }else{ ?>
		<i class="fa fa-circle-thin fa-lg mr-2" aria-hidden="true"></i>
	<?php }; ?>
	<i class="fa fa-circle-thin fa-lg mr-2" aria-hidden="true"></i>
</div>

<section class="payment">
	<div class="container">
		<div class="row">
			<div class="col-sm-6" style="padding:0;">
				<div class="payment-bg-img">
					<div class="reg-left-img">
			 			<img src="<?php echo base_url('assets/images/Circle-Design.png');?>">
			 		</div>
			 		<div class="reg-right-img">
			 			<img src="<?php echo base_url('assets/images/Arrow-Design.png');?>">
			 		</div>
			 		<div class="reg-content-2">
			 			<h3>Please complete <br> the payment </h3>
			 			<p>Annual Subscription fee of Rs 3000/- includes access to GAS-Medusys App along with GAS membership. This software is subscribed to you on a non-exclusive, non-assignable, and nontransferable basis. MEDUSYS strives to protect the security and privacy of the users and its product.</p>
			 		</div>
			 		<div class="bottom-img-2">
			 			<div class="row">
			 				<div class="col-sm-3"><img src="<?php echo base_url('assets/images/Arrow-Design-2.png');?>" style="padding-top: 140%;"></div>
			 				<div class="col-sm-6"><img src="<?php echo base_url('assets/images/payment-img.png');?>" class="img-fluid d-block mx-auto"></div>
			 				<div class="col-sm-3"><img src="<?php echo base_url('assets/images/Circle-Design.png');?>" style="padding-top: 90%;"></div>
			 			</div>
			 		</div>
				</div><!--payment-bg-img-->
			</div><!--col-6-->
			<div class="col-sm-6" style="padding:0;">
				<div class="payment-form">
					<form>
						<h3>Payment Method</h3>
						<a href="">Pay from Cards/Banks or UPI</a>
						<div class="row">
							<div class="col-sm-6"></div>
							<div class="col-sm-6">
								<div class="btn-otp">
									<button type="button" class="btn-otp">Cancel</button>
								</div>
							</div>
						</div><!--row-->
					</form>
				</div>
			</div><!--col-6-->
		</div><!--row-->
	</div>
</section>


<?php echo view("includes/footer-mels"); ?>