
<?php
    echo view('includes/flow-header');    
?>

<link rel="stylesheet" type="text/css" href="<?php echo base_url('public/assets/css/conference.css'); ?>">

<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,300;0,400;0,500;1,400&family=Montserrat&family=Ms+Madi&family=My+Soul&family=Open+Sans&family=Poppins:wght@200;400&family=Roboto:ital,wght@0,300;0,500;1,300&family=Updock&display=swap" rel="stylesheet">


<section class="faculty-flow">
    <div class="row">
        <div class="col-sm-3">
             <div class="conference-left">
                <ul>
                    <li><a href="">Conferences & Workshops</a></li>
                </ul>
                <div class="go-back">
                    <a href="<?php echo base_url('Gas');?>"><i class="fa fa-arrow-left" aria-hidden="true"></i>Go Back</a>
                </div>
            </div>
        </div>
        <div class="col-sm-9">
            <div class="conference-right">
                 <div class="con-head">
                    <div class="row" id="conf-bt">
                        <div class="col-sm-5">
                            <div class="conf-left-text">
                                <h5>Conferences & Workshops</h5>
                            </div>
                        </div>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" placeholder="search" name="">
                        </div>
                    </div><!----->
                 </div>
                <header class="cf pt-4">
                    <div class="navigation">
                        <nav>
                            <a href="javascript:void(0)" class="smobitrigger ion-navicon-round"><span>Menu</span></a>
                            <ul class="mobimenu">
                                <li><a href="<?php echo base_url('/Conference-Details?id='.$val['conference_id']); ?>">About</a></li>
                                <li><a href="<?php echo base_url('/Programs?id='.$val['conference_id']); ?>">Program Schedule</a></li>
                                <li class="conf-act"><a href="<?php echo base_url('/Faculty-Details?id='.$val['conference_id']); ?>">Faculty</a></li>
                                <li><a href="<?php echo base_url('/Registration-Details?id='.$val['conference_id']); ?>">Registration</a></li>
                                <li><a href="">Attend</a></li>
                                <li><a href="">Feedback</a></li>
                                <li><a href="">Certificate</a></li>
                            </ul>
                        </nav>
                    </div>
                </header>
            </div><!--conference-right--->
            <div class="container">
               
                     <div class="row pt-5">
                        <div class="col-sm-2">
                            <label><b>Title</b>:</label>
                        </div>
                        <div class="col-sm-10">
                            <h3><b><?php echo $val['title']; ?></b></h3>
                        </div>
                    </div><!--row-->
                      <div class="vertical-tabs">
                        <div class="row pt-5">
                            <div class="col-sm-4">
                                <h4>Click on the Faculty Name for details</h4>
                                <ul class="nav nav-tabs" role="tablist">
                                <?php 
                    		    $i = 1;
                                    foreach($faculty  as $f){
                                    if($i == 1){
                                        ?>
                                        <li>
                                                <button id = "<?php echo 'button'.$i; ?>" class="nav-link active" onclick = "change_details('<?php echo $f['id'] ?>',<?php echo $i ?>)"><?php echo $f['name']; ?>
                                                </button>
                                         </li>
                                        <?php
                                            $i++;
                                    }
                                    else{
				
                                            ?>
                                            <li>
                                                    <button id = "<?php echo 'button'.$i; ?>" class="nav-link" onclick = "change_details('<?php echo $f['id'] ?>',<?php echo $i ?>)"><?php echo $f['name']; ?>
                                                    </button>
                                             </li>
                                            <?php
                                                $i++;
                                        }
                         
                                    }
                                ?>
                             		<input type = "hidden" id = "total_num" value = "<?php echo $i; ?>" name = "total_num"/>
                                 </ul>
                            </div>
                            <div class="col-sm-8">
                                <div class="tab-content">
                                    <div class="tab-pane active" id="pag1" role="tabpanel">
                         <?php
                        $j = 0; 
                        foreach($faculty  as $f){
                            if($j == 0){
                                $j++;
                            ?>
                              <div class="sv-tab-panel">
                                <p><b>Profile Picture</b></p>
                                <div>
                   
				    <img id = "profile" src="<?php echo base_url('images/faculty_profile/'.$f['profile_pic']); ?>" alt="PROFILE PIC" width="200" height="200">
                                </div>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <tbody>
                                                <tr>
                                                    <td>Name</td>
                                                    <td><p id = "name"><?php echo $f['name']; ?></p></td>
                                                </tr>
                                                <tr>
                                                    <td>Present Designation</td>
                                                    <td><p id = "present_des" ><?php echo $f['present_des']; ?></p></td>
                                                </tr>
                                                <tr>
                                                    <td>Qualifications </td>
                                                    <td><p id = "qualification" ><?php echo $f['qualification']; ?></p></td>
                                                </tr>
                                                <tr>
                                                    <td>Special Interests</td>
                                                    <td><pid = "special_int"><?php echo $f['special_int']; ?></p></td>
                                                </tr>
                                                <tr>
                                                    <td>Publications</td>
                                                    <td><p id = "publication"><?php echo $f['publication']; ?></p></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                      </div>
                                      <?php
                                  }
                                  }
                                  ?>
                                    </div><!------1--->
                                    
                                    
                                    

                                    

                                    

                                    

                                  </div><!--tab-content-->
                            </div>
                        </div>
                    </div>
               
            </div>
        </div><!--col--9-->
    </div>
    
</section>

<script>
function change_details(id,selectedbutton){
        var total_num = $('#total_num').val();
 	var i = 0;
	for(i = 1; i < total_num; i++){
		var button = "button"+i;
		var element = document.getElementById(button);
   		element.classList.remove("active");
	}
	var button = "button"+selectedbutton;
	var element = document.getElementById(button);
   	element.classList.add("active");
		$.ajax({
			type   : 'post',
			url    : '<?php echo base_url("indivisual-facultly-details")?>',
			data   : { 'id' : id },
								  
			success:function(response){
				response = jQuery.parseJSON(response);
				console.log(response.data);

				console.log(response.data['id']);
				if(response.result==1)
				{  
					$('#name').text(response.data['name']);
					$('#present_des').text(response.data['present_des']);
					$('#qualification').text(response.data['qualification']);
					$('#special_int').text(response.data['special_int']);
					$('#publication').text(response.data['publication']);

					var edit_save = document.getElementById("profile");

       					edit_save.src = 'https://medusys.in/images/faculty_profile/'+response.data['profile_pic'];
					//toastr["success"](response.message);
					    

				}
				else 
				{
					toastr["error"](response.message);			
				}
			}
		});
	
}
</script>

<?php
    echo view('includes/flow-footer');    
?>