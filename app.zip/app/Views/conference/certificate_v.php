<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
	<title></title>
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,300;0,400;0,500;1,400&family=Montserrat&family=Ms+Madi&family=My+Soul&family=Open+Sans&family=Poppins:wght@200;400&family=Roboto:ital,wght@0,300;0,400;0,500;1,300&family=Updock&display=swap" rel="stylesheet">
</head>
<body>
<div id="editor"></div>
<button id="cmd">generate PDF</button>
	<section class="cert-container">
		<div id="content2" class="cert">
			<img src="<?php echo base_url('images/certificate/'.'bg1.jpg'); ?>" style="height: 700px;">
			<div class="cert-content">
				<div class="header-logo_s">
					<div class="logo-1">
						<img src="<?php echo base_url('images/certificate/'.$certificate['logo1']); ?>">	
					</div>
					<div class="logo-2">
						<img src="<?php echo base_url('images/certificate/'.$certificate['logo2']);?>">
					</div>
					<div class="logo-3">
						<img src="<?php echo base_url('images/certificate/'.$certificate['logo3']); ?>">
					</div>
				</div>
				<div class="" style="padding-left:25%;margin-top: -3%;">
					<h2 style="margin-bottom: 5px;font-size: 21px;">CERTIFICATE OF ATTENDANCE</h2>
					<p class="mt-0">IS HEREBY GRANTED TO</p>
					<h2 style="margin-top:-15px;">DR. <?php echo strtoupper($name); ?></h2>
					<p style="margin-top:-15px;">ATTENDED <?php echo "'".strtoupper($val['title'])."'";?></p>
					<p style="margin-top:-15px;">2nd & 3rd April, 2022</p>
					<h4 style="margin-top:-15px;font-size: 15px;">ACCREDITED BY THE ROYAL COLLEGE OF ANAESTHETISTS FOR 8 CPD CREDITS</h4>
				</div>
				<div class="bottom">
					<div class="bottom-1">
						<p style="margin-bottom:0;"><?php echo $today; ?></p>
						<p>Date</p>
					</div>
					<div class="bottom-1">
						<img src="<?php echo base_url('images/certificate/'.$certificate['signature1']);?>" style="width:35%;">
						<p><?php echo $certificate['sign1']; ?></p> 
					</div>
					<div class="bottom-1">
						<img src="<?php echo base_url('images/certificate/'.$certificate['signature2']);?>" style="width:35%;">
						<p><?php echo $certificate['sign2']; ?></p> 
					</div>
				</div>
				<div class="footer">
					<img src="<?php echo base_url('images/certificate/'.'footer-logo.png');?>">
				</div>
			</div>
		</div>
	</section>
</body>
</html>


<style type="text/css">
	.cert-container{
	   /* margin: 65px 0 10px 0;*/
	   /* width: 100%;*/
	   width: 95%;
	    display: flex;
	    justify-content: center;
	    font-family: 'Roboto', sans-serif;
	}
	.cert{
	    width: 1000px;
	    height: 650px;
	  /*  padding: 15px 20px;*/
	    text-align: center;
	    position: relative;
	   /* z-index: -1;*/
	}
	.cert-content {
	    width: 750px;
	    height: 470px;
	    padding: 70px 60px 0px 60px;
	    text-align: center;
	    position: absolute;
	   	top: 24px;
    	left: 60px;
	}
	.header-logo_s{
		display: flex;
		margin-left:27%;
	}
	.logo-1{
		width: 33%;
	}
	.logo-2{
		width: 33%;
	}
	.logo-3{
		width: 33%;
	}
	.header-logo_s img{
		width:100%;
	}
	.mb-0{
		margin-bottom: 0;
	}
	.mt-0{
		margin-top: 0;
	}
	.bottom{
		display: flex;
		justify-content: space-between;
	}
	.footer{
		float: left;
	}
</style>