<?php
	//print_r($values);
	//die();
    echo view('includes/admin-header');    
?>

<link rel="stylesheet" type="text/css" href="<?php echo base_url('public/assets/css/conference.css'); ?>">
<link rel="stylesheet" type="text/css"  href="<?php echo base_url('public/assets/css/jquery-ui.css'); ?>"/>

<div class="col-sm-10">
	<div class="add-conference-right">
		
		<section class="new-menu">
			<div class="container">
				<div class="row pt-5">
					<div class="col-sm-1"></div>
					<div class="col-sm-11">
						<header class="cf">
							<div class="navigation">
								<nav>
									<a href="javascript:void(0)" class="smobitrigger ion-navicon-round"><span>Menu</span></a>
									<ul class="mobimenu">
										<li class="conf-act"><a href="<?php echo base_url('Conference'); ?>">About</a></li>
										<li><a href="<?php echo base_url('Programschedule'); ?>">Program Schedule</a></li>
										<li><a href="">Faculty</a></li>
										<li><a href="">Registration</a></li>
					          <li><a href="">Attend</a></li>
					          <li><a href="">Certificate</a></li>
									</ul>
								</nav>
							</div>
						</header>
					</div>
				</div><!--row-->
			</div>
		</section>
<!-- ----------conference about-----------			 -->

			<div class="container">
				<div class="about-conf">
					<form id="conference-about">
						<input type="hidden" name="conference_id" value = "<?php echo $values['conference_id'] ?>">
						<div class="row pt-5">
							<div class="col-sm-1">
								<label><b>Title :</b></label>
							</div>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="title_con_e" value = "<?php echo $values['title'] ?>">
							</div>
							<div class="col-sm-1"></div>
						</div><!--row-->
						<div class="row pt-3">
							<div class="col-sm-1">
								<label><b>From Date</b></label>
							</div>
							<div class="col-sm-4">
						
								<input type="text" id="datepicker" class="form-control" name="dates_con_from_e" value = "<?php echo $values['date_from'] ?>">
							</div>
							<div class="col-sm-1">
								<label><b>To Date</b></label>
							</div>
							<div class="col-sm-4">
								<input type="text" id="datepicker1" class="form-control" name="dates_con_to_e" value = "<?php echo $values['date_to'] ?>">
							</div>
							
						</div><!--row-->
						
						<div class="row pt-3">
							<div class="col-sm-1">
								<label><b>Location:</b></label>
							</div>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="location_con_e" value = "<?php echo $values['location'] ?>">
							</div>
							<div class="col-sm-1"></div>
						</div><!--row-->
						<div class="row pt-3">
							<div class="col-sm-1">
								<label><b>Theme:</b></label>
							</div>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="theme_con_e" value = "<?php echo $values['theme'] ?>">
							</div>
							<div class="col-sm-1"></div>
						</div><!--row-->
						<div class="row pt-3">
							<div class="col-sm-1 p-0">
								<label><b>Introduction</b></label>
							</div>
							<div class="col-sm-10">
								<textarea name="intro_con_e" id="comment1"   class="form-control" onkeydown="limitText(this.form.intro_con_e,this.form.countdown,500);" onkeyup="limitText(this.form.intro_con_e,this.form.countdown,500);" ><?php echo $values['intro'] ?></textarea>
								 <span class="limit">(Maximum characters: <input name="countdown" type="text" value="500" size="1" readonly>)</span>
							</div>
							<div class="col-sm-1"></div>
						</div><!--row-->
						<div class="row pt-3">
							<div class="col-sm-1 p-0">
								<label><b>Organizer’s Message:</b></label>
							</div>
							<div class="col-sm-10">
								<textarea name="org_msg_con_e" id="comment" class="form-control"  onkeydown="limitText(this.form.org_msg_con_e,this.form.countdown1,500);" onkeyup="limitText(this.form.org_msg_con_e,this.form.countdown1,500);" ><?php echo $values['org_msg'] ?></textarea>
								 <span class="limit">(Maximum characters: <input name="countdown1" type="text" value="500" size="1" readonly>)</span>
								
							</div>
							<div class="col-sm-1"></div>
						</div><!--row-->
						<div class="row pt-5">
							<div class="col-sm-2" style="text-align: end;">
								<button  type="submit" value="submit"  class="btn">Edit</button>
							</div>
							<div class="col-sm-10"></div>
						</div><!---->
					</form>
			<!-- 	</div></div>
			</div>
		</div> -->
	</div>
</div>

</div></div>

<script type="text/javascript" src="<?php echo base_url('public/assets/js/jquery-ui.js'); ?>"></script>
<script>
  $( function() {
    $("#datepicker").datepicker();
    $("#datepicker1").datepicker();
  } );
  </script>
  <script>

    $('#conference-about').submit(function(e){  
        e.preventDefault();
		var formdata = new FormData(this);
		$.ajax({
			type   : 'post',
			url    : '<?php echo base_url("update-conference")?>',
			data   : formdata,
			contentType: false,
			processData: false,					  
			success:function(response){
				response = jQuery.parseJSON(response);
				console.log(response);
				if(response.result==1)
				{  
					toastr["success"](response.message);
					// $('#library-table').DataTable().ajax.reload(null, false);
					// $(".edit_conferences").modal("hide");	
	           	window.location = '<?php echo base_url("program-scheduleedit")?>?id='+response.data;       

				}
				else 
				{
					toastr["error"](response.message);			
				}
			}
		});
 });
 

</script>

<script language="javascript" type="text/javascript">
			function limitText(limitField, limitCount, limitNum) {
				if (limitField.value.length > limitNum) {
					limitField.value = limitField.value.substring(0, limitNum);
				} else {
					limitCount.value = limitNum - limitField.value.length;
				}
			}
</script>


<?php
    echo view('includes/admin-footer');    
?>