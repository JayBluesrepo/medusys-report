<?php
    echo view('includes/flow-header');    
?>

<section class="coming-soon">
    <h1>Coming soon</h1>
    <a href="<?php echo base_url("Mels-Cme")?>"><i class="fa fa-arrow-left" aria-hidden="true"></i>Go Back</a>
</section>

<?php
    echo view('includes/flow-footer');    
?>