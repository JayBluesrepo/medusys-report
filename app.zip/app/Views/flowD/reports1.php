<?php
    echo view('includes/flow-header');    
?>

<!-- <link rel="stylesheet" type="text/css"  href="<?php echo base_url('assets/css/simpleMobileMenu-2.css'); ?>"/> -->


<section class="reports-main">
    <div class="row">
        <div class="col-sm-3">
            <div class="spec-left">
                <div class="reports-menu">
                    <ul class="mobimenu">
                        <li class="act"><a href="">Patient Characteristics</a></li>
                        <li class="dropdown">
                            <a href="" class="dropdown-toggle" data-toggle="dropdown">Procedure<i class="fa fa-angle-double-down pl-2" aria-hidden="true"></i></a>
                             <ul class="dropdown-menu" id="drop">
                                <li><a href="">Clinical Safety Standards</a></li>
                                <li><a href="">Surgery Details</a></li>
                                <li><a href="">Techniques</a></li>
                                <li><a href="">Epidural Technique</a></li>
                                <li><a href="">Needle Details</a></li>
                                <li><a href="">LA Utilisation</a></li>
                                <li><a href="">Adjuvant Usage</a></li>
                                <li><a href="">Sensory & Motor Block</a></li>
                            </ul>
                        </li>
                        <li><a href="">Outcomes</a></li>
                        <li><a href="">Follow-Up</a></li>
                        <li><a href="">Feedback</a></li>
                    </ul>
                </div>
                <div class="go-back">
                         <a href="<?php echo base_url('User');?>"><i class="fa fa-arrow-left" aria-hidden="true"></i>Go Back</a>
                    </div>   
            </div>
        </div>
         <div class="col-sm-9">
            <div class="reports-right">
                <h3>Patient Characteristics</h3>
            </div>
        </div>
    </div>
</section>


<!---------------- Menu Drodown --------------------->
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('.mobimenu li.dropdown').hover(function() {
              $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
            }, function() {
              $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
            });         
        });
    </script>
<!---------------- Menu Drodown --------------------->


<?php
    echo view('includes/flow-footer');    
?>
