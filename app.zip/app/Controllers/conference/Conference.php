<?php
namespace App\Controllers\conference ;
use App\Controllers\BaseController;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\OrganisationModel;
use App\Models\Conf_About;
use App\Models\ProgramScheduleModel;
use App\Models\RegisterUserModel;
use App\Models\FacultyModel;
use App\Models\ConferencefeedbackModel;
use App\Models\CertificateModel;
use App\Models\Conf_paymentModel;

class Conference extends BaseController
{
        use ResponseTrait;
    public function __construct()
    {
        helper(['form','url']);
    }

    public function index()
    {
    $dr_id = session()->get('dr_id');

        if($dr_id){

            $e_library=['z,x,y'];
            $data['conference'] = $e_library;

            $model = new OrganisationModel();
            $details  = $model->get()->getResultArray();
            $data['org'] = $details;

            $org_id = session()->get('org_id');
            $model1 = new Conf_About();
            $model1->where('org_id',$org_id);
            $model1->select('*');
            $data['con_upcoming']  = $model1->get()->getResultArray();

            $data['dr_id'] =  $dr_id;
            return view('conference/conference_home',$data);
        }
        else{
            return view('login');
        }
    }
    public function conference_about()
    {
    $dr_id = session()->get('dr_id');
    $conference_id = $_GET['id'];
    
        if($dr_id){

            $e_library=['z,x,y'];
            $data['conference'] = $e_library;

            $model = new OrganisationModel();
            $details  = $model->get()->getResultArray();
            $data['org'] = $details;

            $org_id = session()->get('org_id');
            $model1 = new Conf_About();

            $model1->select('*');
            $data['val']  = $model1->where('conference_id',$conference_id)->first();

            $data['dr_id'] =  $dr_id; 
            return view('conference/conference_about',$data);
        }
        else{
            return view('login');
        }
    }
    public function programs()
    {
        $dr_id = session()->get('dr_id');
        $conference_id = $_GET['id'];

        if($dr_id){

            $e_library=['z,x,y'];
            $data['conference'] = $e_library;

            $model = new OrganisationModel();
            $details  = $model->get()->getResultArray();
            $data['org'] = $details;

            $org_id = session()->get('org_id');

            $model = new Conf_About();
            $model->select('*');
            $data['val']  = $model->where('conference_id',$conference_id)->first();


            $model1 = new ProgramScheduleModel();
            $model1->select('*');
            $model1->where('conference_id',$conference_id);
            $data['programs'] = $model1->get()->getResultArray();

            $data['dr_id'] =  $dr_id; 
            return view('conference/program_schedule',$data);
        }
        else{
            return view('login');
        }
    }
    public function faculty_details()
    {
        $dr_id = session()->get('dr_id');
        $conference_id = $_GET['id'];

        if($dr_id){

            $e_library=['z,x,y'];
            $data['conference'] = $e_library;

            $model = new OrganisationModel();
            $details  = $model->get()->getResultArray();
            $data['org'] = $details;

            $org_id = session()->get('org_id');

            $model = new Conf_About();
            $model->select('*');
            $data['val']  = $model->where('conference_id',$conference_id)->first();


            $model1 = new FacultyModel();
            $model1->select('*');
            $model1->where('conference_id',$conference_id);
            $data['faculty'] =$model1->get()->getResultArray();
            $data['dr_id'] =  $dr_id; 
            return view('conference/faculty_details',$data);
        }
        else{
            return view('login');
        }
    }
    public function registration_details()
    {
        $dr_id = session()->get('dr_id');
        $conference_id = $_GET['id'];

        if($dr_id){

            $e_library=['z,x,y'];
            $data['conference'] = $e_library;

            $model = new OrganisationModel();
            $details  = $model->get()->getResultArray();
            $data['org'] = $details;

            $org_id = session()->get('org_id');

            $model = new Conf_About();
            $model->select('*');
            $data['val']  = $model->where('conference_id',$conference_id)->first();


            $model1 = new FacultyModel();
            $model1->select('*');
            $model1->where('conference_id',$conference_id);
            $data['faculty'] =$model1->get()->getResultArray();
            $data['dr_id'] =  $dr_id; 
            return view('conference/conference_registation',$data);
        }
        else{
            return view('login');
        }
    }
    public function attend_conference()
    {
        $dr_id = session()->get('dr_id');
        $conference_id = $_GET['id'];

        if($dr_id){
        
            $model = new Conf_About();
            $model->select('*');
            $data['val']  = $model->where('conference_id',$conference_id)->first();
            if($data['val']['reg_fee'] != 0){
                $model2 = new Conf_paymentModel();
                $model2->select('*');
                $model2->where('conference_id',$conference_id);
                $model2->where('user_id',$dr_id);
                $payment =$model2->get()->getResultArray();
            
                if($payment){


                    $e_library=['z,x,y'];
                    $data['conference'] = $e_library;

                    $model = new OrganisationModel();
                    $details  = $model->get()->getResultArray();
                    $data['org'] = $details;

                    $org_id = session()->get('org_id');

                    $model1 = new ProgramScheduleModel();
                    $model1->select('*');
                    $model1->where('conference_id',$conference_id);
                    $data['attend_link'] =$model1->get()->getResultArray();
                    $data['dr_id'] =  $dr_id; 
                    return view('conference/attend_conference',$data);
                }
                else{
                    return view('conference/no_payment',$data);
                }
            }
            else{
                    $e_library=['z,x,y'];
                    $data['conference'] = $e_library;

                    $model = new OrganisationModel();
                    $details  = $model->get()->getResultArray();
                    $data['org'] = $details;

                    $org_id = session()->get('org_id');

                    $model1 = new ProgramScheduleModel();
                    $model1->select('*');
                    $model1->where('conference_id',$conference_id);
                    $data['attend_link'] =$model1->get()->getResultArray();
                    $data['dr_id'] =  $dr_id; 
                    return view('conference/attend_conference',$data);
            }
        }
        else{
            return view('login');
        }
    }
    public function feedback()
    {
        $dr_id = session()->get('dr_id');
        $conference_id = $_GET['id'];
        
        if($dr_id){

                $model = new Conf_About();
                $model->select('*');
                $data['val']  = $model->where('conference_id',$conference_id)->first();
                if($data['val']['reg_fee'] != 0){
                    $e_library=['z,x,y'];
                    $data['conference'] = $e_library;

                    $model = new OrganisationModel();
                    $details  = $model->get()->getResultArray();
                    $data['org'] = $details;

                    $org_id = session()->get('org_id');

                    $model2 = new Conf_paymentModel();
                    $model2->select('*');
                    $model2->where('conference_id',$conference_id);
                    $model2->where('user_id',$dr_id);
                    $payment =$model2->get()->getResultArray();
                
                    if($payment){
                        $model1 = new ProgramScheduleModel();
                        $model1->select('*');
                        $model1->where('conference_id',$conference_id);
                        $data['programs'] =$model1->get()->getResultArray();
                        $data['dr_id'] =  $dr_id; 
                            return view('conference/feedback',$data);
                    }
                    else{
                        return view('conference/no_payment',$data);
                    }
                }
                else{
                    $model1 = new ProgramScheduleModel();
                    $model1->select('*');
                    $model1->where('conference_id',$conference_id);
                    $data['programs'] =$model1->get()->getResultArray();
                    $data['dr_id'] =  $dr_id; 
                        return view('conference/feedback',$data);
                }
        }
        else{
            return view('login');
        }
    }
     public function certificate()
    {

        $dr_id = session()->get('dr_id');
        
        if($dr_id){
            $conference_id = $_GET['id'];

            $model = new Conf_About();
            $model->select('*');
            $data['val']  = $model->where('conference_id',$conference_id)->first();
            if($data['val']){ 
                $model1 = new ConferencefeedbackModel();
                $model1->select('*');
                $model1->where('conference_id',$conference_id);
                $model1->where('created_by',$dr_id);
                $feedback = $model1->get()->getResultArray();
                if($feedback){
              $model2 = new CertificateModel();
                      $model2->select('*');
                      $data['certificate'] = $model2->where('conference_id',$conference_id)->first();
              $data['name'] = session()->get('name');
              $data['today'] = date("Y-m-d");
              return view('conference/certificate_v',$data);
                    
                }
                else{
                    
                    return view('conference/no_feedback',$data);
                }
                
            }
            else{
                return view('invalid_url');
            }


            
        }
        else{
            return view('login');
        }
    }
    
    public function update_feedback()
    {
   // print_r($_POST);
   // die();
    $dr_id = session()->get('dr_id'); 
    $name = session()->get('name'); 
    $conference_id = $this->request->getvar('conference_id');
        if($dr_id){

        $org_id = session()->get('org_id');


        $model1 = new ProgramScheduleModel();
        $model1->select('*');
        $model1->where('conference_id',$conference_id);
        $programs =$model1->get()->getResultArray();
        $review = $this->request->getvar('comment');

        $i = 1;

        foreach($programs as $key=>$val){
            $radio = 'optradio'.$i;
            $feedaback = $this->request->getvar($radio);

            $feedbback = array(
                'conference_id'=>$conference_id,
                'ps_id'=> $programs[$key]['ps_id'],
                'rating'=> $feedaback,
                'review'=> $review,
                'user_name' =>$name,
                'created_by' =>$dr_id
             );
      //print_r($feedbback);
          
            $model = new ConferencefeedbackModel(); 
            $model->save($feedbback);
            $insertedID = $model->insertID();
            $i++;

        }
        if($insertedID){
                    return json_encode(array(
                 
                    'data' => $faculty,
                    'result'    => 1,
                    'message'     => 'Feedback Inserted Succesfully..You can Download the certificate..'
                    ));
        
            }
            else{
                    return json_encode(array(
                        'result'    => 0,
                        'message'     => 'Something went wrong.....'
                    ));
            }

        }
        else{
            return view('login');
        }
    }
    public function indivisual_facultly_details()
    {
    $dr_id = session()->get('dr_id');
    $fac_id = $this->request->getvar('id');
    
    
        if($dr_id){

            $e_library=['z,x,y'];
            $data['conference'] = $e_library;

            $model = new OrganisationModel();
            $details  = $model->get()->getResultArray();
            $data['org'] = $details;

            $org_id = session()->get('org_id');

            $model = new Conf_About();
            $model->select('*');
            $data['val']  = $model->where('conference_id',$conference_id)->first();


            $model1 = new FacultyModel();
            $model1->select('*');
            $faculty = $model1->where('id',$fac_id)->first();
            if($faculty){
                return json_encode(array(

                'data' => $faculty,
                'result'    => 1,
                'message'     => 'update Data'
                ));

            }
            else{
                return json_encode(array(
                'result'    => 0,
                'message'     => 'Something went wrong.....'
                ));
            }

        }
        else{
            return view('login');
        }
    }
}
?>