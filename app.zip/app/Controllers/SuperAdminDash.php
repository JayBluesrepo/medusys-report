<?php 
namespace App\Controllers\admin;
use App\Controllers\BaseController;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\CategoriesModel;
use App\Models\OrganisationModel;
use App\Models\RegisterUserModel;
use App\Models\E_LibrarySectionModel;
use App\Models\conferenceModel;

class SuperAdminDash extends BaseController{
  
    public function index(){
        $dr_id = session()->get('dr_id');
        // print_r($dr_id );die();
        if($dr_id ){

            $dash=['a,b,c'];
            $data['dash_b'] = $dash;

            $model8 = new OrganisationModel();
            $details  = $model8->get()->getResultArray();
            $data['org'] = $details;

            $model = new OrganisationModel(); 
            $details = $model->get()->getResultArray();           
            $data['no_org'] = $details;

            $model1 = new RegisterUserModel();
            $model1->where('role_id',3);
            $details1 = $model1->get()->getResultArray(); 
            $data['moduler_role'] = $details1;

            $model2 = new RegisterUserModel();
            $model2->where('role_id',4);
            $details2 = $model2->get()->getResultArray(); 
            $data['faculty_role'] = $details2;

            $model3 = new RegisterUserModel();
            $model3->where('role_id',0);
            $model3->where('org_id', 1);
            $details3 = $model3->get()->getResultArray(); 
            $data['totaluser_role'] = $details3;
         
            $model4 = new RegisterUserModel();
            $model4->where('valid_user',1);
            $details4 = $model4->get()->getResultArray(); 
            $data['active_valid'] = $details4;

            date_default_timezone_set('Asia/Kolkata');   
            $current_date = date('Y-m-d H:i:s', time());
            $previous_date = date("Y-m-d H:i:s",strtotime("-1 month"));
            $model5 = new RegisterUserModel();                
            $model5->where('created_at >=',$previous_date);          
            $model5->where('created_at <=',$current_date);
            $details5 = $model5->get()->getResultArray(); 
            $data['lastmonth_user'] = $details5;

            $model6 = new E_LibrarySectionModel();
            $model6->where('org_id', 1);
            $details7 = $model6->get()->getResultArray(); 
            $data['total_elibrary'] = $details7;

            $model7 = new conferenceModel();
            $model7->where('org_id', 1);
            $details8 = $model7->get()->getResultArray(); 
            $data['total_conference'] = $details8;

            // $model7 = new RegisterUserModel();
            // $model7->select('last_login');
            // // $model1->where('password');
            // // $model1->where('email');
            // $model7->where('role_id',1);
            // $details7 = $model7->get()->getResultArray(); 
            // $data['lastuser_loggedin'] = $details7;

            // print_r(count($details7));die();

            $details16 = date('Y-m-d');
            $data['crnt_date'] = $details16;

            return view('admin/super-admin-dashboard', $data);
        }else{
            return view('admin/super-admin-login');
        }

        
    }

    public function power_bi_dash(){

        $dr_id = session()->get('dr_id');
       
        if($dr_id ){

            $dash=['a,b,c'];
            $data['dash_b'] = $dash;

            $model = new OrganisationModel();
            $details  = $model->get()->getResultArray();
            $data['org'] = $details;

            return view('admin/Power-BI-dashboard', $data);
        }else{
            return view('admin/super-admin-login');
        }
    }
}
?>