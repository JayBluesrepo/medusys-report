<?php 

namespace App\Controllers\cnb;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\ApiModel;


class Reports extends ResourceController
{

    use ResponseTrait;

	public function index() {
        // report analytics
        return view('flowD/reports');  
		               
    }
    public function reports_home() {
        // echo 'home';
        return view('cnb/reports/cnb-reports');  
		               
    }

    public function n_report1() {
        
		$db = \Config\Database::connect();

		$total = 0;
		$products = [];

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("MAX(age) as maxage,MIN(age) as minage,MAX(weight_kg) as maxweight,MIN(weight_kg) as minweight");
		$query = $builder->get();
		$record = $query->getResult();
		foreach($record as $row) {
			$max_age = $row->maxage;
			$min_age = $row->minage;

			$maxweight = $row->maxweight;
			$minweight = $row->minweight;
		}
		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(gender) as female");
		$query = $builder->where('gender','Female');
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$female = $row->female;
		}
		$products[] = array(
			    'day'   => 'Female',
			    'sell' => $female
		);
		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(gender) as male");
		$query = $builder->where('gender','Male');
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$male = $row->male;
		}
		$products[] = array(
			    'day'   => 'Male',
			    'sell' => $male
		);

		$bmi = [];

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(bmi) as bmi1");
		$query = $builder->where('bmi >=','30');
		$query = $builder->where('bmi <=','34.99');
		$query = $builder->get();
		$record = $query->getResult();
		
		
		foreach($record as $row) {
			
			$bmi1 = $row->bmi1;
			$bmi[] = array(
			    'day'   => 'bmi >= 30',
			    'sell' => $bmi1
			);
		}

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(bmi) as bmi2");
		$query = $builder->where('bmi >=','35');
		$query = $builder->where('bmi <=','39.99');
		$query = $builder->get();
		$record = $query->getResult();
		
		
		foreach($record as $row) {
			
			$bmi2 = $row->bmi2;
			$bmi[] = array(
			    'day'   => 'bmi >= 35',
			    'sell' => $bmi2
			);
		}

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(bmi) as bmi3");
		$query = $builder->where('bmi >=','40');
		$query = $builder->get();
		$record = $query->getResult();
		
		
		foreach($record as $row) {
			
			$bmi3 = $row->bmi3;
			$bmi[] = array(
			    'day'   => 'bmi >= 40',
			    'sell' => $bmi3
			);
		}

		$data['bmi1'] = $bmi1;
		$data['bmi2'] = $bmi2;
		$data['bmi3'] = $bmi3;
		$data['total_n'] = $total; 
		$data['max_age'] = $max_age; 
		$data['min_age'] = $min_age; 
		$data['female'] = $female;
		$data['male'] = $male; 
		$data['maxweight'] = $maxweight; 
		$data['minweight'] = $minweight;


		$data['products'] = ($products); 
		$data['bmi'] = ($bmi);  

		

		return view('cnb/reports/demography_v', $data);                
    }

	
	public function n_report() {
        
		$db = \Config\Database::connect();

		$total = 0;
		$products = [];

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$products[] = array(
			    'day'   => 'N',
			    'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$total = 0;


		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(cnb_postop.id) as count");
		$builder->join('manual_feedback', 'manual_feedback.patient_id = cnb_postop.patient_id');
		$builder->join('cnb_followup', 'cnb_followup.patient_id = cnb_postop.patient_id');
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(cnb_postop.id) as count");
		$builder->join('e_feedback', 'e_feedback.patient_id = cnb_postop.patient_id');
		$builder->join('cnb_followup', 'cnb_followup.patient_id = cnb_postop.patient_id');
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
			$products[] = array(
			   'day'   => 'Nc',
			   'sell' => $total
			);

		}



		//$query = $db->getLastQuery();
		//echo (string)$query;

		$data['products'] = ($products); 

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/n_report', $data);                
    }

    public function bar() {
		$db = \Config\Database::connect();
	       
		$builder = $db->table('cnb_preop');
	        $query = $builder->select("COUNT(id) as count, COUNT(asa) as s,asa as day");
		$query = $builder->groupBy('asa');
		$query = $builder->get();
	        $data['products'] = $query->getResult();

		$data['products'] = $query->getResult();


		return view('cnb/reports/bar', $data); 
   }
   //------------------------ procedure---------------//

   public function safety() { 
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_preop');
		$query = $builder->select("COUNT(id) as count, asa as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('asa');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/safety_v', $data);                
    }
    public function surgical() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_preop');
		$query = $builder->select("COUNT(id) as count, category as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('category');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/surgical_v', $data);                
    }
    public function speciality() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_preop');
		$query = $builder->select("COUNT(id) as count, speciality as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('speciality');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/speciality_v', $data);                
    }
    public function location() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_preop');
		$query = $builder->select("COUNT(id) as count, surgery_location as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('surgery_location');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/location_v', $data);                
    }
    public function purpose() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_preop');
		$query = $builder->select("COUNT(id) as count, purpose as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('purpose');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/purpose_v', $data);                
    }

    public function consultant() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("COUNT(id) as count, cnb_done_by2 as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('cnb_done_by2');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("COUNT(id) as count, supervision as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('supervision');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$supervision = [];
		foreach($record as $row) {
			$supervision[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);
		$data['supervision'] = ($supervision);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/consultant_v', $data);                
    }

    public function patient_status() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count, patient_status as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('patient_status');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count, patient_position as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('patient_position');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$patient_position = [];
		foreach($record as $row) {
			$patient_position[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);
		$data['patient_position'] = ($patient_position);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/patient_status_v', $data);                 
    }

     public function sterility_features() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count, skin_prep as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('skin_prep');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/sterility_features_v', $data);                
    }

    public function anatomical() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,anatomical_landmark as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('anatomical_landmark');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,approach as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('approach');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$approach = [];
		foreach($record as $row) {
			$approach[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,no_attempts as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('no_attempts');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$attempts = [];
		foreach($record as $row) {
			$attempts[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);
		$data['approach'] = ($approach);
		$data['attempts'] = ($attempts);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/anatomical_v', $data);                
    }

    public function ultra_sound() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,ultra_sound as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('ultra_sound');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,image_quality as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('image_quality');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$image_quality = [];
		foreach($record as $row) {
			$image_quality[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

	

		$data['products'] = ($products);
		$data['image_quality'] = ($image_quality);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/ultra_sound_v', $data);                
    }

    public function needle_brand() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,needle_brand as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('needle_brand');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		

		$data['products'] = ($products);
		
		$data['total'] = $total;       
		//$query = $db->getLastQuery();
		return view('cnb/reports/needle_brand_v', $data);                
    }


	public function cse_technique() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('procedure_cse');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_cse');
		$query = $builder->select("COUNT(id) as count,cse_technique as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('cse_technique');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		

		$data['products'] = ($products);
		
		$data['total'] = $total;    

		return view('cnb/reports/cse_technique_v', $data);                
    }


	public function csa_technique() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,	csa as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('csa');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		

		$data['products'] = ($products);
		
		$data['total'] = $total;    

		return view('cnb/reports/csa_technique_v', $data);                
    }

	public function stay_duration() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_followup');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_followup');
		$query = $builder->select("COUNT(id) as count,	duration as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('duration');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		

		$data['products'] = ($products);
		
		$data['total'] = $total;    

		// print_r($data);die();

		return view('cnb/reports/stay_duration_v', $data);                
    }


	public function epidural_adjuvant() {
        
		$db = \Config\Database::connect();
		
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(opioid_dose) as NO");
		$query = $builder->where('opioid_dose ','');
		$query = $builder->get();
		$record3 = $query->getResult();
		foreach($record3 as $row) {
			$opioid_dose3 = $row->NO;
		}
		$opioide[] = array(
			    'day'   => 'NO',
			    'sell' => $opioid_dose3
		);

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(opioid_dose) as YES");
		$query = $builder->where('opioid_dose !=','');
		$query = $builder->get();
		$record2 = $query->getResult();

		foreach($record2 as $row) {
			$opioid_dose = $row->YES;
		}
		$opioide[] = array(
			    'day'   => 'YES',
			    'sell' => $opioid_dose
		);

		$data['opioide'] = ($opioide); 


		//  ---------------------------OPIOIDE ADJUVANT----------------------

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(clonidina_dose) as NO");
		$query = $builder->where('clonidina_dose ','');
		$query = $builder->get();
		$record4 = $query->getResult();
		foreach($record4 as $row) {
			$clonidina_dose = $row->NO;
		}
		$clonidina[] = array(
			    'day'   => 'NO',
			    'sell' => $clonidina_dose
		);

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(clonidina_dose) as YES");
		$query = $builder->where('clonidina_dose !=','');
		$query = $builder->get();
		$record5 = $query->getResult();

		foreach($record5 as $row) {
			$clonidina_dose = $row->YES;
		}
		$clonidina[] = array(
			    'day'   => 'YES',
			    'sell' => $clonidina_dose
		);
		$data['clonidina'] = ($clonidina); 

		//  ---------------------------dexmeditomidine ADJUVANT----------------------

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(dexmeditomidine_dose) as NO");
		$query = $builder->where('dexmeditomidine_dose ','');
		$query = $builder->get();
		$record6 = $query->getResult();
		foreach($record6 as $row) {
			$dexmeditomidine_dose = $row->NO;
		}
		$dexmeditomidine[] = array(
			    'day'   => 'NO',
			    'sell' => $dexmeditomidine_dose
		);

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(dexmeditomidine_dose) as YES");
		$query = $builder->where('dexmeditomidine_dose !=','');
		$query = $builder->get();
		$record7 = $query->getResult();

		foreach($record7 as $row) {
			$dexmeditomidine_dose = $row->YES;
		}
		$dexmeditomidine[] = array(
			    'day'   => 'YES',
			    'sell' => $dexmeditomidine_dose
		);
		$data['dexmeditomidine'] = ($dexmeditomidine); 


		//  ---------------------------dexamephasone ADJUVANT----------------------


		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(dexamephasone_dose) as NO");
		$query = $builder->where('dexamephasone_dose ','');
		$query = $builder->get();
		$record8 = $query->getResult();
		foreach($record8 as $row) {
			$dexamephasone_dose = $row->NO;
		}
		$dexamephasone[] = array(
			    'day'   => 'NO',
			    'sell' => $dexamephasone_dose
		);

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(dexamephasone_dose) as YES");
		$query = $builder->where('dexamephasone_dose !=','');
		$query = $builder->get();
		$record9 = $query->getResult();

		foreach($record9 as $row) {
			$dexamephasone_dose = $row->YES;
		}
		$dexamephasone[] = array(
			    'day'   => 'YES',
			    'sell' => $dexamephasone_dose
		);
		$data['dexamephasone'] = ($dexamephasone);


		//  ---------------------------tramadol ADJUVANT----------------------


		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(tramadol_dose) as NO");
		$query = $builder->where('tramadol_dose ','');
		$query = $builder->get();
		$record10 = $query->getResult();
		foreach($record10 as $row) {
			$tramadol_dose = $row->NO;
		}
		$tramadol[] = array(
			    'day'   => 'NO',
			    'sell' => $tramadol_dose
		);

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(tramadol_dose) as YES");
		$query = $builder->where('tramadol_dose !=','');
		$query = $builder->get();
		$record11 = $query->getResult();

		foreach($record11 as $row) {
			$tramadol_dose = $row->YES;
		}
		$tramadol[] = array(
			    'day'   => 'YES',
			    'sell' => $tramadol_dose
		);
		$data['tramadol'] = ($tramadol);


		//  ---------------------------kepamine ADJUVANT----------------------


		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(kepamine_dose) as NO");
		$query = $builder->where('kepamine_dose ','');
		$query = $builder->get();
		$record12 = $query->getResult();
		foreach($record12 as $row) {
			$kepamine_dose = $row->NO;
		}
		$kepamine[] = array(
			    'day'   => 'NO',
			    'sell' => $kepamine_dose
		);

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(kepamine_dose) as YES");
		$query = $builder->where('kepamine_dose !=','');
		$query = $builder->get();
		$record13 = $query->getResult();

		foreach($record13 as $row) {
			$kepamine_dose = $row->YES;
		}
		$kepamine[] = array(
			    'day'   => 'YES',
			    'sell' => $kepamine_dose
		);
		$data['kepamine'] = ($kepamine);


			//  ---------------------------midazolam ADJUVANT----------------------


			$builder = $db->table('procedure_epidural');
			$query = $builder->select("count(midazolam_dose) as NO");
			$query = $builder->where('midazolam_dose ','');
			$query = $builder->get();
			$record14 = $query->getResult();
			foreach($record14 as $row) {
				$midazolam_dose = $row->NO;
			}
			$midazolam[] = array(
					'day'   => 'NO',
					'sell' => $midazolam_dose
			);
	
			$builder = $db->table('procedure_epidural');
			$query = $builder->select("count(midazolam_dose) as YES");
			$query = $builder->where('midazolam_dose !=','');
			$query = $builder->get();
			$record15 = $query->getResult();
	
			foreach($record15 as $row) {
				$midazolam_dose = $row->YES;
			}
			$midazolam[] = array(
					'day'   => 'YES',
					'sell' => $midazolam_dose
			);
			$data['midazolam'] = ($midazolam);

				//  ---------------------------other ADJUVANT----------------------


				$builder = $db->table('procedure_epidural');
				$query = $builder->select("count(other7) as NO");
				$query = $builder->where('other7 ','NO');
				$query = $builder->get();
				$record16 = $query->getResult();
				foreach($record16 as $row) {
					$other7 = $row->NO;
				}
				$other[] = array(
						'day'   => 'NO',
						'sell' => $other7
				);
		
				$builder = $db->table('procedure_epidural');
				$query = $builder->select("count(other7) as YES");
				$query = $builder->where('other7 ','YES');
				$query = $builder->get();
				$record17 = $query->getResult();
		
				foreach($record17 as $row) {
					$other7 = $row->YES;
				}
				$other[] = array(
						'day'   => 'YES',
						'sell' => $other7
				);
				$data['other'] = ($other);

		return view('cnb/reports/epidural_adjuvant_v', $data);                
    }


	public function spinal_adjuvant() {
        
		$db = \Config\Database::connect();
		
		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(opioid_dose) as NO");
		$query = $builder->where('opioid_dose ','');
		$query = $builder->get();
		$record3 = $query->getResult();
		foreach($record3 as $row) {
			$opioid_dose3 = $row->NO;
		}
		$opioide[] = array(
			    'day'   => 'NO',
			    'sell' => $opioid_dose3
		);

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(opioid_dose) as YES");
		$query = $builder->where('opioid_dose !=','');
		$query = $builder->get();
		$record2 = $query->getResult();

		foreach($record2 as $row) {
			$opioid_dose = $row->YES;
		}
		$opioide[] = array(
			    'day'   => 'YES',
			    'sell' => $opioid_dose
		);

		$data['opioide'] = ($opioide); 


		//  ---------------------------OPIOIDE ADJUVANT----------------------

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(clonidina_dose) as NO");
		$query = $builder->where('clonidina_dose ','');
		$query = $builder->get();
		$record4 = $query->getResult();
		foreach($record4 as $row) {
			$clonidina_dose = $row->NO;
		}
		$clonidina[] = array(
			    'day'   => 'NO',
			    'sell' => $clonidina_dose
		);

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(clonidina_dose) as YES");
		$query = $builder->where('clonidina_dose !=','');
		$query = $builder->get();
		$record5 = $query->getResult();

		foreach($record5 as $row) {
			$clonidina_dose = $row->YES;
		}
		$clonidina[] = array(
			    'day'   => 'YES',
			    'sell' => $clonidina_dose
		);
		$data['clonidina'] = ($clonidina); 

		//  ---------------------------dexmeditomidine ADJUVANT----------------------

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(dexmeditomidine_dose) as NO");
		$query = $builder->where('dexmeditomidine_dose ','');
		$query = $builder->get();
		$record6 = $query->getResult();
		foreach($record6 as $row) {
			$dexmeditomidine_dose = $row->NO;
		}
		$dexmeditomidine[] = array(
			    'day'   => 'NO',
			    'sell' => $dexmeditomidine_dose
		);

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(dexmeditomidine_dose) as YES");
		$query = $builder->where('dexmeditomidine_dose !=','');
		$query = $builder->get();
		$record7 = $query->getResult();

		foreach($record7 as $row) {
			$dexmeditomidine_dose = $row->YES;
		}
		$dexmeditomidine[] = array(
			    'day'   => 'YES',
			    'sell' => $dexmeditomidine_dose
		);
		$data['dexmeditomidine'] = ($dexmeditomidine); 


		//  ---------------------------dexamephasone ADJUVANT----------------------


		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(dexamephasone_dose) as NO");
		$query = $builder->where('dexamephasone_dose ','');
		$query = $builder->get();
		$record8 = $query->getResult();
		foreach($record8 as $row) {
			$dexamephasone_dose = $row->NO;
		}
		$dexamephasone[] = array(
			    'day'   => 'NO',
			    'sell' => $dexamephasone_dose
		);

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(dexamephasone_dose) as YES");
		$query = $builder->where('dexamephasone_dose !=','');
		$query = $builder->get();
		$record9 = $query->getResult();

		foreach($record9 as $row) {
			$dexamephasone_dose = $row->YES;
		}
		$dexamephasone[] = array(
			    'day'   => 'YES',
			    'sell' => $dexamephasone_dose
		);
		$data['dexamephasone'] = ($dexamephasone);


		//  ---------------------------tramadol ADJUVANT----------------------


		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(tramadol_dose) as NO");
		$query = $builder->where('tramadol_dose ','');
		$query = $builder->get();
		$record10 = $query->getResult();
		foreach($record10 as $row) {
			$tramadol_dose = $row->NO;
		}
		$tramadol[] = array(
			    'day'   => 'NO',
			    'sell' => $tramadol_dose
		);

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(tramadol_dose) as YES");
		$query = $builder->where('tramadol_dose !=','');
		$query = $builder->get();
		$record11 = $query->getResult();

		foreach($record11 as $row) {
			$tramadol_dose = $row->YES;
		}
		$tramadol[] = array(
			    'day'   => 'YES',
			    'sell' => $tramadol_dose
		);
		$data['tramadol'] = ($tramadol);


		//  ---------------------------kepamine ADJUVANT----------------------


		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(ketamine_dose) as NO");
		$query = $builder->where('ketamine_dose ','');
		$query = $builder->get();
		$record12 = $query->getResult();
		foreach($record12 as $row) {
			$ketamine_dose = $row->NO;
		}
		$ketamine[] = array(
			    'day'   => 'NO',
			    'sell' => $ketamine_dose
		);

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(ketamine_dose) as YES");
		$query = $builder->where('ketamine_dose !=','');
		$query = $builder->get();
		$record13 = $query->getResult();

		foreach($record13 as $row) {
			$ketamine_dose = $row->YES;
		}
		$ketamine[] = array(
			    'day'   => 'YES',
			    'sell' => $ketamine_dose
		);
		$data['ketamine'] = ($ketamine);


			//  ---------------------------midazolam ADJUVANT----------------------


			$builder = $db->table('procedure_spinal');
			$query = $builder->select("count(midazolam_dose) as NO");
			$query = $builder->where('midazolam_dose ','');
			$query = $builder->get();
			$record14 = $query->getResult();
			foreach($record14 as $row) {
				$midazolam_dose = $row->NO;
			}
			$midazolam[] = array(
					'day'   => 'NO',
					'sell' => $midazolam_dose
			);
	
			$builder = $db->table('procedure_spinal');
			$query = $builder->select("count(midazolam_dose) as YES");
			$query = $builder->where('midazolam_dose !=','');
			$query = $builder->get();
			$record15 = $query->getResult();
	
			foreach($record15 as $row) {
				$midazolam_dose = $row->YES;
			}
			$midazolam[] = array(
					'day'   => 'YES',
					'sell' => $midazolam_dose
			);
			$data['midazolam'] = ($midazolam);

				//  ---------------------------midazolam ADJUVANT----------------------


				$builder = $db->table('procedure_spinal');
				$query = $builder->select("count(adrenaline_dose) as NO");
				$query = $builder->where('adrenaline_dose ','');
				$query = $builder->get();
				$record18 = $query->getResult();
				foreach($record18 as $row) {
					$adrenaline_dose = $row->NO;
				}
				$adrenaline[] = array(
						'day'   => 'NO',
						'sell' => $adrenaline_dose
				);
		
				$builder = $db->table('procedure_spinal');
				$query = $builder->select("count(adrenaline_dose) as YES");
				$query = $builder->where('adrenaline_dose !=','');
				$query = $builder->get();
				$record19 = $query->getResult();
		
				foreach($record19 as $row) {
					$adrenaline_dose = $row->YES;
				}
				$adrenaline[] = array(
						'day'   => 'YES',
						'sell' => $adrenaline_dose
				);
				$data['adrenaline'] = ($adrenaline);

				//  ---------------------------other ADJUVANT----------------------


				$builder = $db->table('procedure_spinal');
				$query = $builder->select("count(other7) as NO");
				$query = $builder->where('other7 ','NO');
				$query = $builder->get();
				$record16 = $query->getResult();
				foreach($record16 as $row) {
					$other7 = $row->NO;
				}
				$other[] = array(
						'day'   => 'NO',
						'sell' => $other7
				);
		
				$builder = $db->table('procedure_spinal');
				$query = $builder->select("count(other7) as YES");
				$query = $builder->where('other7 ','YES');
				$query = $builder->get();
				$record17 = $query->getResult();
		
				foreach($record17 as $row) {
					$other7 = $row->YES;
				}
				$other[] = array(
						'day'   => 'YES',
						'sell' => $other7
				);
				$data['other'] = ($other);

		return view('cnb/reports/spinal_adjuvant_v', $data);                
    }


	public function csa_adjuvant() {
        
		$db = \Config\Database::connect();
		
		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(opioid_aj) as NO");
		$query = $builder->where('opioid_aj ','');
		$query = $builder->get();
		$record3 = $query->getResult();
		foreach($record3 as $row) {
			$opioid_dose3 = $row->NO;
		}
		$opioide[] = array(
			    'day'   => 'NO',
			    'sell' => $opioid_dose3
		);

		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(opioid_aj) as YES");
		$query = $builder->where('opioid_aj !=','');
		$query = $builder->get();
		$record2 = $query->getResult();

		foreach($record2 as $row) {
			$opioid_dose = $row->YES;
		}
		$opioide[] = array(
			    'day'   => 'YES',
			    'sell' => $opioid_dose
		);

		$data['opioide'] = ($opioide); 


		//  ---------------------------OPIOIDE ADJUVANT----------------------

		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(clonidne_aj) as NO");
		$query = $builder->where('clonidne_aj ','');
		$query = $builder->get();
		$record4 = $query->getResult();
		foreach($record4 as $row) {
			$clonidina_dose = $row->NO;
		}
		$clonidina[] = array(
			    'day'   => 'NO',
			    'sell' => $clonidina_dose
		);

		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(clonidne_aj) as YES");
		$query = $builder->where('clonidne_aj !=','');
		$query = $builder->get();
		$record5 = $query->getResult();

		foreach($record5 as $row) {
			$clonidina_dose = $row->YES;
		}
		$clonidina[] = array(
			    'day'   => 'YES',
			    'sell' => $clonidina_dose
		);
		$data['clonidina'] = ($clonidina); 

		//  ---------------------------dexmeditomidine ADJUVANT----------------------

		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(dexmeditomidine_aj) as NO");
		$query = $builder->where('dexmeditomidine_aj ','');
		$query = $builder->get();
		$record6 = $query->getResult();
		foreach($record6 as $row) {
			$dexmeditomidine_dose = $row->NO;
		}
		$dexmeditomidine[] = array(
			    'day'   => 'NO',
			    'sell' => $dexmeditomidine_dose
		);

		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(dexmeditomidine_aj) as YES");
		$query = $builder->where('dexmeditomidine_aj !=','');
		$query = $builder->get();
		$record7 = $query->getResult();

		foreach($record7 as $row) {
			$dexmeditomidine_dose = $row->YES;
		}
		$dexmeditomidine[] = array(
			    'day'   => 'YES',
			    'sell' => $dexmeditomidine_dose
		);
		$data['dexmeditomidine'] = ($dexmeditomidine); 


		//  ---------------------------dexamephasone ADJUVANT----------------------


		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(dexamethasone_aj) as NO");
		$query = $builder->where('dexamethasone_aj ','');
		$query = $builder->get();
		$record8 = $query->getResult();
		foreach($record8 as $row) {
			$dexamephasone_dose = $row->NO;
		}
		$dexamephasone[] = array(
			    'day'   => 'NO',
			    'sell' => $dexamephasone_dose
		);

		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(dexamethasone_aj) as YES");
		$query = $builder->where('dexamethasone_aj !=','');
		$query = $builder->get();
		$record9 = $query->getResult();

		foreach($record9 as $row) {
			$dexamephasone_dose = $row->YES;
		}
		$dexamephasone[] = array(
			    'day'   => 'YES',
			    'sell' => $dexamephasone_dose
		);
		$data['dexamephasone'] = ($dexamephasone);


		//  ---------------------------tramadol ADJUVANT----------------------


		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(tramadol_aj) as NO");
		$query = $builder->where('tramadol_aj ','');
		$query = $builder->get();
		$record10 = $query->getResult();
		foreach($record10 as $row) {
			$tramadol_dose = $row->NO;
		}
		$tramadol[] = array(
			    'day'   => 'NO',
			    'sell' => $tramadol_dose
		);

		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(tramadol_aj) as YES");
		$query = $builder->where('tramadol_aj !=','');
		$query = $builder->get();
		$record11 = $query->getResult();

		foreach($record11 as $row) {
			$tramadol_dose = $row->YES;
		}
		$tramadol[] = array(
			    'day'   => 'YES',
			    'sell' => $tramadol_dose
		);
		$data['tramadol'] = ($tramadol);


		//  ---------------------------kepamine ADJUVANT----------------------


		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(ketamine_aj) as NO");
		$query = $builder->where('ketamine_aj ','');
		$query = $builder->get();
		$record12 = $query->getResult();
		foreach($record12 as $row) {
			$ketamine_dose = $row->NO;
		}
		$ketamine[] = array(
			    'day'   => 'NO',
			    'sell' => $ketamine_dose
		);

		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(ketamine_aj) as YES");
		$query = $builder->where('ketamine_aj !=','');
		$query = $builder->get();
		$record13 = $query->getResult();

		foreach($record13 as $row) {
			$ketamine_dose = $row->YES;
		}
		$ketamine[] = array(
			    'day'   => 'YES',
			    'sell' => $ketamine_dose
		);
		$data['ketamine'] = ($ketamine);


			//  ---------------------------midazolam ADJUVANT----------------------


			$builder = $db->table('procedure_csa');
			$query = $builder->select("count(midazolam_aj) as NO");
			$query = $builder->where('midazolam_aj ','');
			$query = $builder->get();
			$record14 = $query->getResult();
			foreach($record14 as $row) {
				$midazolam_dose = $row->NO;
			}
			$midazolam[] = array(
					'day'   => 'NO',
					'sell' => $midazolam_dose
			);
	
			$builder = $db->table('procedure_csa');
			$query = $builder->select("count(midazolam_aj) as YES");
			$query = $builder->where('midazolam_aj !=','');
			$query = $builder->get();
			$record15 = $query->getResult();
	
			foreach($record15 as $row) {
				$midazolam_dose = $row->YES;
			}
			$midazolam[] = array(
					'day'   => 'YES',
					'sell' => $midazolam_dose
			);
			$data['midazolam'] = ($midazolam);

				//  ---------------------------midazolam ADJUVANT----------------------


				$builder = $db->table('procedure_csa');
				$query = $builder->select("count(adrenaline_aj) as NO");
				$query = $builder->where('adrenaline_aj ','');
				$query = $builder->get();
				$record18 = $query->getResult();
				foreach($record18 as $row) {
					$adrenaline_dose = $row->NO;
				}
				$adrenaline[] = array(
						'day'   => 'NO',
						'sell' => $adrenaline_dose
				);
		
				$builder = $db->table('procedure_csa');
				$query = $builder->select("count(adrenaline_aj) as YES");
				$query = $builder->where('adrenaline_aj !=','');
				$query = $builder->get();
				$record19 = $query->getResult();
		
				foreach($record19 as $row) {
					$adrenaline_dose = $row->YES;
				}
				$adrenaline[] = array(
						'day'   => 'YES',
						'sell' => $adrenaline_dose
				);
				$data['adrenaline'] = ($adrenaline);

				//  ---------------------------other ADJUVANT----------------------


				$builder = $db->table('procedure_csa');
				$query = $builder->select("count(aj) as NO");
				$query = $builder->where('aj ','NO');
				$query = $builder->get();
				$record16 = $query->getResult();
				foreach($record16 as $row) {
					$other7 = $row->NO;
				}
				$other[] = array(
						'day'   => 'NO',
						'sell' => $other7
				);
		
				$builder = $db->table('procedure_csa');
				$query = $builder->select("count(aj) as YES");
				$query = $builder->where('aj ','YES');
				$query = $builder->get();
				$record17 = $query->getResult();
		
				foreach($record17 as $row) {
					$other7 = $row->YES;
				}
				$other[] = array(
						'day'   => 'YES',
						'sell' => $other7
				);
				$data['other'] = ($other);

		return view('cnb/reports/csa_adjuvant_v', $data);                
    }


	public function epidural_component_adjuvant() {
        
		$db = \Config\Database::connect();
		
		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(opioid_dose) as NO");
		$query = $builder->where('opioid_dose ','');
		$query = $builder->get();
		$record3 = $query->getResult();
		foreach($record3 as $row) {
			$opioid_dose3 = $row->NO;
		}
		$opioide[] = array(
			    'day'   => 'NO',
			    'sell' => $opioid_dose3
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(opioid_dose) as YES");
		$query = $builder->where('opioid_dose !=','');
		$query = $builder->get();
		$record2 = $query->getResult();

		foreach($record2 as $row) {
			$opioid_dose = $row->YES;
		}
		$opioide[] = array(
			    'day'   => 'YES',
			    'sell' => $opioid_dose
		);

		$data['opioide'] = ($opioide); 


		//  ---------------------------OPIOIDE ADJUVANT----------------------

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(clonidina_dose) as NO");
		$query = $builder->where('clonidina_dose ','');
		$query = $builder->get();
		$record4 = $query->getResult();
		foreach($record4 as $row) {
			$clonidina_dose = $row->NO;
		}
		$clonidina[] = array(
			    'day'   => 'NO',
			    'sell' => $clonidina_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(clonidina_dose) as YES");
		$query = $builder->where('clonidina_dose !=','');
		$query = $builder->get();
		$record5 = $query->getResult();

		foreach($record5 as $row) {
			$clonidina_dose = $row->YES;
		}
		$clonidina[] = array(
			    'day'   => 'YES',
			    'sell' => $clonidina_dose
		);
		$data['clonidina'] = ($clonidina); 

		//  ---------------------------dexmeditomidine ADJUVANT----------------------

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(dexmeditomidine_dose) as NO");
		$query = $builder->where('dexmeditomidine_dose ','');
		$query = $builder->get();
		$record6 = $query->getResult();
		foreach($record6 as $row) {
			$dexmeditomidine_dose = $row->NO;
		}
		$dexmeditomidine[] = array(
			    'day'   => 'NO',
			    'sell' => $dexmeditomidine_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(dexmeditomidine_dose) as YES");
		$query = $builder->where('dexmeditomidine_dose !=','');
		$query = $builder->get();
		$record7 = $query->getResult();

		foreach($record7 as $row) {
			$dexmeditomidine_dose = $row->YES;
		}
		$dexmeditomidine[] = array(
			    'day'   => 'YES',
			    'sell' => $dexmeditomidine_dose
		);
		$data['dexmeditomidine'] = ($dexmeditomidine); 


		//  ---------------------------dexamephasone ADJUVANT----------------------


		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(dexamephasone_dose) as NO");
		$query = $builder->where('dexamephasone_dose ','');
		$query = $builder->get();
		$record8 = $query->getResult();
		foreach($record8 as $row) {
			$dexamephasone_dose = $row->NO;
		}
		$dexamephasone[] = array(
			    'day'   => 'NO',
			    'sell' => $dexamephasone_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(dexamephasone_dose) as YES");
		$query = $builder->where('dexamephasone_dose !=','');
		$query = $builder->get();
		$record9 = $query->getResult();

		foreach($record9 as $row) {
			$dexamephasone_dose = $row->YES;
		}
		$dexamephasone[] = array(
			    'day'   => 'YES',
			    'sell' => $dexamephasone_dose
		);
		$data['dexamephasone'] = ($dexamephasone);


		//  ---------------------------tramadol ADJUVANT----------------------


		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(trmadol_dose) as NO");
		$query = $builder->where('trmadol_dose ','');
		$query = $builder->get();
		$record10 = $query->getResult();
		foreach($record10 as $row) {
			$tramadol_dose = $row->NO;
		}
		$tramadol[] = array(
			    'day'   => 'NO',
			    'sell' => $tramadol_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(trmadol_dose) as YES");
		$query = $builder->where('trmadol_dose !=','');
		$query = $builder->get();
		$record11 = $query->getResult();

		foreach($record11 as $row) {
			$tramadol_dose = $row->YES;
		}
		$tramadol[] = array(
			    'day'   => 'YES',
			    'sell' => $tramadol_dose
		);
		$data['tramadol'] = ($tramadol);


		//  ---------------------------kepamine ADJUVANT----------------------


		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(kepamine_dose) as NO");
		$query = $builder->where('kepamine_dose ','');
		$query = $builder->get();
		$record12 = $query->getResult();
		foreach($record12 as $row) {
			$kepamine_dose = $row->NO;
		}
		$kepamine[] = array(
			    'day'   => 'NO',
			    'sell' => $kepamine_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(kepamine_dose) as YES");
		$query = $builder->where('kepamine_dose !=','');
		$query = $builder->get();
		$record13 = $query->getResult();

		foreach($record13 as $row) {
			$kepamine_dose = $row->YES;
		}
		$kepamine[] = array(
			    'day'   => 'YES',
			    'sell' => $kepamine_dose
		);
		$data['ketamine'] = ($kepamine);


			//  ---------------------------midazolam ADJUVANT----------------------


			$builder = $db->table('procedure_cse');
			$query = $builder->select("count(midazolam_dose) as NO");
			$query = $builder->where('midazolam_dose ','');
			$query = $builder->get();
			$record14 = $query->getResult();
			foreach($record14 as $row) {
				$midazolam_dose = $row->NO;
			}
			$midazolam[] = array(
					'day'   => 'NO',
					'sell' => $midazolam_dose
			);
	
			$builder = $db->table('procedure_cse');
			$query = $builder->select("count(midazolam_dose) as YES");
			$query = $builder->where('midazolam_dose !=','');
			$query = $builder->get();
			$record15 = $query->getResult();
	
			foreach($record15 as $row) {
				$midazolam_dose = $row->YES;
			}
			$midazolam[] = array(
					'day'   => 'YES',
					'sell' => $midazolam_dose
			);
			$data['midazolam'] = ($midazolam);


							//  ---------------------------adrenaline ADJUVANT----------------------


							$builder = $db->table('procedure_cse');
							$query = $builder->select("count(adrenaline_dose) as NO");
							$query = $builder->where('adrenaline_dose ','');
							$query = $builder->get();
							$record18 = $query->getResult();
							foreach($record18 as $row) {
								$adrenaline_dose = $row->NO;
							}
							$adrenaline[] = array(
									'day'   => 'NO',
									'sell' => $adrenaline_dose
							);
					
							$builder = $db->table('procedure_cse');
							$query = $builder->select("count(adrenaline_dose) as YES");
							$query = $builder->where('adrenaline_dose !=','');
							$query = $builder->get();
							$record19 = $query->getResult();
					
							foreach($record19 as $row) {
								$adrenaline_dose = $row->YES;
							}
							$adrenaline[] = array(
									'day'   => 'YES',
									'sell' => $adrenaline_dose
							);
							$data['adrenaline'] = ($adrenaline);

			

				//  ---------------------------other ADJUVANT----------------------


				$builder = $db->table('procedure_cse');
				$query = $builder->select("count(aj_epidural_other) as NO");
				$query = $builder->where('aj_epidural_other ','NO');
				$query = $builder->get();
				$record16 = $query->getResult();
				foreach($record16 as $row) {
					$other7 = $row->NO;
				}
				$other[] = array(
						'day'   => 'NO',
						'sell' => $other7
				);
		
				$builder = $db->table('procedure_cse');
				$query = $builder->select("count(aj_epidural_other) as YES");
				$query = $builder->where('aj_epidural_other ','YES');
				$query = $builder->get();
				$record17 = $query->getResult();
		
				foreach($record17 as $row) {
					$other7 = $row->YES;
				}
				$other[] = array(
						'day'   => 'YES',
						'sell' => $other7
				);
				$data['other'] = ($other);

		return view('cnb/reports/epidural_component_adjuvant_v', $data);                
    }



	
	public function spinal_component_adjuvant() {
        
		$db = \Config\Database::connect();
		
		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_opioid) as NO");
		$query = $builder->where('aj_spinal_opioid ','');
		$query = $builder->get();
		$record3 = $query->getResult();
		foreach($record3 as $row) {
			$opioid_dose3 = $row->NO;
		}
		$opioide[] = array(
			    'day'   => 'NO',
			    'sell' => $opioid_dose3
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_opioid) as YES");
		$query = $builder->where('aj_spinal_opioid !=','');
		$query = $builder->get();
		$record2 = $query->getResult();

		foreach($record2 as $row) {
			$opioid_dose = $row->YES;
		}
		$opioide[] = array(
			    'day'   => 'YES',
			    'sell' => $opioid_dose
		);

		$data['opioide'] = ($opioide); 


		//  ---------------------------OPIOIDE ADJUVANT----------------------

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_clonidne) as NO");
		$query = $builder->where('aj_spinal_clonidne ','');
		$query = $builder->get();
		$record4 = $query->getResult();
		foreach($record4 as $row) {
			$clonidina_dose = $row->NO;
		}
		$clonidina[] = array(
			    'day'   => 'NO',
			    'sell' => $clonidina_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_clonidne) as YES");
		$query = $builder->where('aj_spinal_clonidne !=','');
		$query = $builder->get();
		$record5 = $query->getResult();

		foreach($record5 as $row) {
			$clonidina_dose = $row->YES;
		}
		$clonidina[] = array(
			    'day'   => 'YES',
			    'sell' => $clonidina_dose
		);
		$data['clonidina'] = ($clonidina); 

		//  ---------------------------dexmeditomidine ADJUVANT----------------------

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_dexmeditomidine) as NO");
		$query = $builder->where('aj_spinal_dexmeditomidine ','');
		$query = $builder->get();
		$record6 = $query->getResult();
		foreach($record6 as $row) {
			$dexmeditomidine_dose = $row->NO;
		}
		$dexmeditomidine[] = array(
			    'day'   => 'NO',
			    'sell' => $dexmeditomidine_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_dexmeditomidine) as YES");
		$query = $builder->where('aj_spinal_dexmeditomidine !=','');
		$query = $builder->get();
		$record7 = $query->getResult();

		foreach($record7 as $row) {
			$dexmeditomidine_dose = $row->YES;
		}
		$dexmeditomidine[] = array(
			    'day'   => 'YES',
			    'sell' => $dexmeditomidine_dose
		);
		$data['dexmeditomidine'] = ($dexmeditomidine); 


		//  ---------------------------dexamephasone ADJUVANT----------------------


		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_dexamethasone) as NO");
		$query = $builder->where('aj_spinal_dexamethasone ','');
		$query = $builder->get();
		$record8 = $query->getResult();
		foreach($record8 as $row) {
			$dexamephasone_dose = $row->NO;
		}
		$dexamephasone[] = array(
			    'day'   => 'NO',
			    'sell' => $dexamephasone_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_dexamethasone) as YES");
		$query = $builder->where('aj_spinal_dexamethasone !=','');
		$query = $builder->get();
		$record9 = $query->getResult();

		foreach($record9 as $row) {
			$dexamephasone_dose = $row->YES;
		}
		$dexamephasone[] = array(
			    'day'   => 'YES',
			    'sell' => $dexamephasone_dose
		);
		$data['dexamephasone'] = ($dexamephasone);


		//  ---------------------------tramadol ADJUVANT----------------------


		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_tramadol) as NO");
		$query = $builder->where('aj_spinal_tramadol ','');
		$query = $builder->get();
		$record10 = $query->getResult();
		foreach($record10 as $row) {
			$tramadol_dose = $row->NO;
		}
		$tramadol[] = array(
			    'day'   => 'NO',
			    'sell' => $tramadol_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_tramadol) as YES");
		$query = $builder->where('aj_spinal_tramadol !=','');
		$query = $builder->get();
		$record11 = $query->getResult();

		foreach($record11 as $row) {
			$tramadol_dose = $row->YES;
		}
		$tramadol[] = array(
			    'day'   => 'YES',
			    'sell' => $tramadol_dose
		);
		$data['tramadol'] = ($tramadol);


		

				//  ---------------------------adrenaline ADJUVANT----------------------


				$builder = $db->table('procedure_cse');
				$query = $builder->select("count(aj_spinal_adrenaline) as NO");
				$query = $builder->where('aj_spinal_adrenaline ','');
				$query = $builder->get();
				$record18 = $query->getResult();
				foreach($record18 as $row) {
					$adrenaline_dose = $row->NO;
				}
				$adrenaline[] = array(
						'day'   => 'NO',
						'sell' => $adrenaline_dose
				);
		
				$builder = $db->table('procedure_cse');
				$query = $builder->select("count(aj_spinal_adrenaline) as YES");
				$query = $builder->where('aj_spinal_adrenaline !=','');
				$query = $builder->get();
				$record19 = $query->getResult();
		
				foreach($record19 as $row) {
					$adrenaline_dose = $row->YES;
				}
				$adrenaline[] = array(
						'day'   => 'YES',
						'sell' => $adrenaline_dose
				);
				$data['adrenaline'] = ($adrenaline);

			

				//  ---------------------------other ADJUVANT----------------------


				$builder = $db->table('procedure_cse');
				$query = $builder->select("count(aj_epidural_other) as NO");
				$query = $builder->where('aj_epidural_other ','NO');
				$query = $builder->get();
				$record16 = $query->getResult();
				foreach($record16 as $row) {
					$other7 = $row->NO;
				}
				// $other[] = array(
				// 		'day'   => 'NO',
				// 		'sell' => $other7
				// );
		
				$builder = $db->table('procedure_cse');
				$query = $builder->select("aj_epidural_other");
				// $query = $builder->like('aj_epidural_other','[{"name":"","dose":""}]');

				
				$query = $builder->get();
				$record17 = $query->getResult();
				
				foreach($record17 as $key => $row) {
					$other = $record17[11]->aj_epidural_other;
					// foreach($other as $key =>$val){
						
					// 	$other7 = $val;
					// }
					print_r($other);die();
				}

				$other[] = array(
					'day'   => 'YES',
					'sell' => $other7
				);
				$data['other'] = ($other);

				// $aj_spinal_op = $info['aj_spinal_opioid'];
                // $aj_spinal_opioid = json_decode($other7, true);
				// var_dump($aj_spinal_opioid);die();
				
		return view('cnb/reports/spinal_component_adjuvant_v', $data);                
    }


	public function late_complication() {  
        
		$db = \Config\Database::connect();


		// -------------------------postdural_puncture----------------

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(postdural_puncture) as NO");
		$query = $builder->where('postdural_puncture','No');
		$query = $builder->get();
		$record1 = $query->getResult();
		foreach($record1 as $row) {
			$postdural_puncture = $row->NO;
		}
		$postdural[] = array(
			    'day'   => 'NO',
			    'sell' => $postdural_puncture
		);

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(postdural_puncture) as YES");
		$query = $builder->where('postdural_puncture','Yes');
		$query = $builder->get();
		$record2 = $query->getResult();

		foreach($record2 as $row) {
			$postdural_puncture = $row->YES;
		}
		$postdural[] = array(
			    'day'   => 'YES',
			    'sell' => $postdural_puncture
		);

		$data['postdural'] = ($postdural); 


		// -------------------------backache_epidural----------------

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(backache_epidural) as NO");
		$query = $builder->where('backache_epidural','No');
		$query = $builder->get();
		$record3 = $query->getResult();
		foreach($record3 as $row) {
			$backache_epidural = $row->NO;
		}
		$backache[] = array(
			    'day'   => 'NO',
			    'sell' => $backache_epidural
		);

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(backache_epidural) as YES");
		$query = $builder->where('backache_epidural','Yes');
		$query = $builder->get();
		$record4 = $query->getResult();

		foreach($record4 as $row) {
			$backache_epidural = $row->YES;
		}
		$backache[] = array(
			    'day'   => 'YES',
			    'sell' => $backache_epidural
		);

		$data['backache'] = ($backache); 


			// -------------------------perst_motor----------------

			$builder = $db->table('cnb_followup');
			$query = $builder->select("count(perst_motor) as NO");
			$query = $builder->where('perst_motor','No');
			$query = $builder->get();
			$record5 = $query->getResult();
			foreach($record5 as $row) {
				$perst_motor = $row->NO;
			}
			$motor[] = array(
					'day'   => 'NO',
					'sell' => $perst_motor
			);
	
			$builder = $db->table('cnb_followup');
			$query = $builder->select("count(perst_motor) as YES");
			$query = $builder->where('perst_motor','Yes');
			$query = $builder->get();
			$record6 = $query->getResult();
	
			foreach($record6 as $row) {
				$perst_motor = $row->YES;
			}
			$motor[] = array(
					'day'   => 'YES',
					'sell' => $perst_motor
			);
	
			$data['motor'] = ($motor); 

		// -------------------------perst_sensory----------------

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(perst_sensory) as NO");
		$query = $builder->where('perst_sensory','No');
		$query = $builder->get();
		$record7 = $query->getResult();
		foreach($record7 as $row) {
			$perst_sensory = $row->NO;
		}
		$sensory[] = array(
				'day'   => 'NO',
				'sell' => $perst_sensory
		);

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(perst_sensory) as YES");
		$query = $builder->where('perst_sensory','Yes');
		$query = $builder->get();
		$record8 = $query->getResult();

		foreach($record8 as $row) {
			$perst_sensory = $row->YES;
		}
		$sensory[] = array(
				'day'   => 'YES',
				'sell' => $perst_sensory
		);

		$data['sensory'] = ($sensory); 
		
	// -------------------------asep_meningi----------------

	$builder = $db->table('cnb_followup');
	$query = $builder->select("count(asep_meningi) as NO");
	$query = $builder->where('asep_meningi','No');
	$query = $builder->get();
	$record9 = $query->getResult();
	foreach($record9 as $row) {
		$asep_meningi = $row->NO;
	}
	$asep[] = array(
			'day'   => 'NO',
			'sell' => $asep_meningi
	);

	$builder = $db->table('cnb_followup');
	$query = $builder->select("count(asep_meningi) as YES");
	$query = $builder->where('asep_meningi','Yes');
	$query = $builder->get();
	$record10 = $query->getResult();

	foreach($record10 as $row) {
		$asep_meningi = $row->YES;
	}
	$asep[] = array(
			'day'   => 'YES',
			'sell' => $asep_meningi
	);

	$data['asep'] = ($asep); 
	
	
	// -------------------------bacterial_meningi----------------

	$builder = $db->table('cnb_followup');
	$query = $builder->select("count(bacterial_meningi) as NO");
	$query = $builder->where('bacterial_meningi','No');
	$query = $builder->get();
	$record11 = $query->getResult();
	foreach($record11 as $row) {
		$bacterial_meningi = $row->NO;
	}
	$bacterial[] = array(
			'day'   => 'NO',
			'sell' => $bacterial_meningi
	);

	$builder = $db->table('cnb_followup');
	$query = $builder->select("count(bacterial_meningi) as YES");
	$query = $builder->where('bacterial_meningi','Yes');
	$query = $builder->get();
	$record12 = $query->getResult();

	foreach($record12 as $row) {
		$bacterial_meningi = $row->YES;
	}
	$bacterial[] = array(
			'day'   => 'YES',
			'sell' => $bacterial_meningi
	);

	$data['bacterial'] = ($bacterial);

		// -------------------------epidural_abs----------------

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(epidural_abs) as NO");
		$query = $builder->where('epidural_abs','No');
		$query = $builder->get();
		$record13 = $query->getResult();
		foreach($record13 as $row) {
			$epidural_abs = $row->NO;
		}
		$abs[] = array(
				'day'   => 'NO',
				'sell' => $epidural_abs
		);
	
		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(epidural_abs) as YES");
		$query = $builder->where('epidural_abs','Yes');
		$query = $builder->get();
		$record14 = $query->getResult();
	
		foreach($record14 as $row) {
			$epidural_abs = $row->YES;
		}
		$abs[] = array(
				'day'   => 'YES',
				'sell' => $epidural_abs
		);
	
		$data['abs'] = ($abs);

		// -------------------------perm_neuro_compli----------------

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(perm_neuro_compli) as NO");
		$query = $builder->where('perm_neuro_compli','No');
		$query = $builder->get();
		$record15 = $query->getResult();
		foreach($record15 as $row) {
			$perm_neuro_compli = $row->NO;
		}
		$perm[] = array(
				'day'   => 'NO',
				'sell' => $perm_neuro_compli
		);
	
		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(perm_neuro_compli) as YES");
		$query = $builder->where('perm_neuro_compli','Yes');
		$query = $builder->get();
		$record16 = $query->getResult();
	
		foreach($record16 as $row) {
			$perm_neuro_compli = $row->YES;
		}
		$perm[] = array(
				'day'   => 'YES',
				'sell' => $perm_neuro_compli
		);
	
		$data['perm'] = ($perm);

		// -------------------------catheter----------------

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(catheter) as NO");
		$query = $builder->where('catheter','No');
		$query = $builder->get();
		$record17 = $query->getResult();
		foreach($record17 as $row) {
			$catheter1 = $row->NO;
		}
		$catheter[] = array(
				'day'   => 'NO',
				'sell' => $catheter1
		);
	
		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(catheter) as YES");
		$query = $builder->where('catheter','Yes');
		$query = $builder->get();
		$record18 = $query->getResult();
	
		foreach($record18 as $row) {
			$catheter1 = $row->YES;
		}
		$catheter[] = array(
				'day'   => 'YES',
				'sell' => $catheter1
		);
	
		$data['catheter'] = ($catheter);


		// -------------------------epidural_haema----------------

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(epidural_haema) as NO");
		$query = $builder->where('epidural_haema','No');
		$query = $builder->get();
		$record19 = $query->getResult();
		foreach($record19 as $row) {
			$epidural_haema = $row->NO;
		}
		$haema[] = array(
				'day'   => 'NO',
				'sell' => $epidural_haema
		);
	
		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(epidural_haema) as YES");
		$query = $builder->where('epidural_haema','Yes');
		$query = $builder->get();
		$record20 = $query->getResult();
	
		foreach($record20 as $row) {
			$epidural_haema = $row->YES;
		}
		$haema[] = array(
				'day'   => 'YES',
				'sell' => $epidural_haema
		);
	
		$data['haema'] = ($haema);

			// -------------------------others----------------

			$builder = $db->table('cnb_followup');
			$query = $builder->select("count(others) as NO");
			$query = $builder->where('others','No');
			$query = $builder->get();
			$record21 = $query->getResult();
			foreach($record21 as $row) {
				$others1 = $row->NO;
			}
			$others[] = array(
					'day'   => 'NO',
					'sell' => $others1
			);
		
			$builder = $db->table('cnb_followup');
			$query = $builder->select("count(others) as YES");
			$query = $builder->where('others','Yes');
			$query = $builder->get();
			$record21 = $query->getResult();
		
			foreach($record21 as $row) {
				$others1 = $row->YES;
			}
			$others[] = array(
					'day'   => 'YES',
					'sell' => $others1
			);
		
			$data['others'] = ($others);
		// print_r($postdural);die();


		return view('cnb/reports/late_complication_v', $data);     
    }



	public function epidural_needle() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count,needle_type as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('needle_type');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		

		$data['products'] = ($products);
		
		$data['total'] = $total;  
		
		

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count,needle_size as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('needle_size');
		$query = $builder->get();
		$record1 = $query->getResult();
		$total = 0;
		$products1 = [];
		foreach($record1 as $row) {
			$products1[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			// $total += floatval($row->count);
		}

		

		$data['products1'] = ($products1);
		

		return view('cnb/reports/epidural_needle_v', $data);                
    }

	public function spinal_needle() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("COUNT(id) as count,needle_type as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('needle_type');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		

		$data['products'] = ($products);
		
		$data['total'] = $total;  
		
		

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("COUNT(id) as count,needle_size as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('needle_size');
		$query = $builder->get();
		$record1 = $query->getResult();
		$total = 0;
		$products1 = [];
		foreach($record1 as $row) {
			$products1[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			// $total += floatval($row->count);
		}

		

		$data['products1'] = ($products1);
		

		return view('cnb/reports/spinal_needle_v', $data);                
    }


	
	public function csa_needle() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,needle_type as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('needle_type');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		

		$data['products'] = ($products);
		
		$data['total'] = $total;  
		
		

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,needle_size as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('needle_size');
		$query = $builder->get();
		$record1 = $query->getResult();
		$total = 0;
		$products1 = [];
		foreach($record1 as $row) {
			$products1[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			// $total += floatval($row->count);
		}

		

		$data['products1'] = ($products1);
		

		return view('cnb/reports/csa_needle_v', $data);                
    }
	public function epidural_la() {
        
		$db = \Config\Database::connect();


		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(la_ropivacaine) as YES");
		$query = $builder->like('la_regimen','With Adrenaline');
		$query = $builder->get();
		$record1 = $query->getResult();
	
		foreach($record1 as $row) {
			$with = $row->YES;
		}
		$adrenaline[] = array(
				'day'   => 'Without Adrenaline',
				'sell' => $with
		);


		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(la_ropivacaine) as YES");
		$query = $builder->like('la_regimen','Without Adrenaline');
		$query = $builder->get();
		$record2 = $query->getResult();
	
		foreach($record2 as $row){
			$Without = $row->YES;
		}
		$regimen[] = array(
				'day'   => 'Without Adrenaline',
				'sell' => $Without
		);
	
		$data['ropivacaine'] = ($ropivacaine);		

// --------------------------------------------
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count,la_ropivacaine as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('la_ropivacaine');
		$query = $builder->get();
		$record2 = $query->getResult();
		$total = 0;
		$ropivacaine = [];
		foreach($record2 as $row) {
			$exp = explode(",",$row->s);
			// print_r($exp);die();

			$ropivacaine[] = array(
			'day'   => $exp[0],
			'sell' => floatval($row->count)
			);
			
		}

		$data['ropivacaine'] = ($ropivacaine);

		// --------------------------------------------
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count,la_bupivacaine as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('la_bupivacaine');
		$query = $builder->get();
		$record3 = $query->getResult();
		$total = 0;
		$bupivacaine = [];
		foreach($record3 as $row) {
			$bupivacaine[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			
		}

		$data['bupivacaine'] = ($bupivacaine);

		// --------------------------------------------
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count,la_levobupivacaine as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('la_levobupivacaine');
		$query = $builder->get();
		$record4 = $query->getResult();
		$total = 0;
		$levobupivacaine = [];
		foreach($record4 as $row) {
			$levobupivacaine[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			
		}

		$data['levobupivacaine'] = ($levobupivacaine);


		// --------------------------------------------
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count,la_lignocaine as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('la_lignocaine');
		$query = $builder->get();
		$record5 = $query->getResult();
		$total = 0;
		$lignocaine = [];
		foreach($record5 as $row) {
           $exp = explode(",",$row->s);

			$lignocaine[] = array(
			'day'   => $exp[0],
			'sell' => floatval($row->count)
			);
			
		}

		$data['bupivacaine'] = ($bupivacaine);
				
	return view('cnb/reports/epidural_la_v', $data);                
    }
}