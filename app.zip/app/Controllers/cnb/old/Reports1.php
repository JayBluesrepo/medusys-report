<?php 

namespace App\Controllers\cnb;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\ApiModel;


class Reports extends ResourceController
{

    use ResponseTrait;

	public function index() {
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_preop');
		$query = $builder->select("COUNT(id) as count, asa as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('asa');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/asa_v', $data);                
    }

    public function n_report1() {
        
		$db = \Config\Database::connect();

		$total = 0;
		$products = [];

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("MAX(age) as maxage,MIN(age) as minage,MAX(weight_kg) as maxweight,MIN(weight_kg) as minweight");
		$query = $builder->get();
		$record = $query->getResult();
		foreach($record as $row) {
			$max_age = $row->maxage;
			$min_age = $row->minage;

			$maxweight = $row->maxweight;
			$minweight = $row->minweight;
		}
		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(gender) as female");
		$query = $builder->where('gender','Female');
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$female = $row->female;
		}
		$products[] = array(
			    'day'   => 'Female',
			    'sell' => $female
		);
		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(gender) as male");
		$query = $builder->where('gender','Male');
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$male = $row->male;
		}
		$products[] = array(
			    'day'   => 'Male',
			    'sell' => $male
		);

		$bmi = [];

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(bmi) as bmi1");
		$query = $builder->where('bmi >=','30');
		$query = $builder->where('bmi <=','34.99');
		$query = $builder->get();
		$record = $query->getResult();
		
		
		foreach($record as $row) {
			
			$bmi1 = $row->bmi1;
			$bmi[] = array(
			    'day'   => 'bmi >= 30',
			    'sell' => $bmi1
			);
		}

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(bmi) as bmi2");
		$query = $builder->where('bmi >=','35');
		$query = $builder->where('bmi <=','39.99');
		$query = $builder->get();
		$record = $query->getResult();
		
		
		foreach($record as $row) {
			
			$bmi2 = $row->bmi2;
			$bmi[] = array(
			    'day'   => 'bmi >= 35',
			    'sell' => $bmi2
			);
		}

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(bmi) as bmi3");
		$query = $builder->where('bmi >=','40');
		$query = $builder->get();
		$record = $query->getResult();
		
		
		foreach($record as $row) {
			
			$bmi3 = $row->bmi3;
			$bmi[] = array(
			    'day'   => 'bmi >= 40',
			    'sell' => $bmi3
			);
		}

		$data['bmi1'] = $bmi1;
		$data['bmi2'] = $bmi2;
		$data['bmi3'] = $bmi3;
		$data['total_n'] = $total; 
		$data['max_age'] = $max_age; 
		$data['min_age'] = $min_age; 
		$data['female'] = $female;
		$data['male'] = $male; 
		$data['maxweight'] = $maxweight; 
		$data['minweight'] = $minweight;


		$data['products'] = ($products); 
		$data['bmi'] = ($bmi);  

		

		return view('cnb/reports/demography_v', $data);                
    }


	public function n_report() {
        
		$db = \Config\Database::connect();

		$total = 0;
		$products = [];

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$products[] = array(
			    'day'   => 'N',
			    'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$total = 0;


		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(cnb_postop.id) as count");
		$builder->join('manual_feedback', 'manual_feedback.patient_id = cnb_postop.patient_id');
		$builder->join('cnb_followup', 'cnb_followup.patient_id = cnb_postop.patient_id');
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(cnb_postop.id) as count");
		$builder->join('e_feedback', 'e_feedback.patient_id = cnb_postop.patient_id');
		$builder->join('cnb_followup', 'cnb_followup.patient_id = cnb_postop.patient_id');
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
			$products[] = array(
			   'day'   => 'Nc',
			   'sell' => $total
			);

		}



		//$query = $db->getLastQuery();
		//echo (string)$query;

		$data['products'] = ($products); 

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/n_report', $data);                
    }

    public function bar() {
		$db = \Config\Database::connect();
	       
		$builder = $db->table('cnb_preop');
	        $query = $builder->select("COUNT(id) as count, COUNT(asa) as s,asa as day");
		$query = $builder->groupBy('asa');
		$query = $builder->get();
	        $data['products'] = $query->getResult();

		$data['products'] = $query->getResult();


		return view('cnb/reports/bar', $data); 
   }
   //------------------------ procedure---------------//

   public function safety() { 
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_preop');
		$query = $builder->select("COUNT(id) as count, asa as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('asa');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/safety_v', $data);                
    }
    public function surgical() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_preop');
		$query = $builder->select("COUNT(id) as count, category as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('category');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/surgical_v', $data);                
    }
    public function speciality() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_preop');
		$query = $builder->select("COUNT(id) as count, speciality as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('speciality');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/speciality_v', $data);                
    }
    public function location() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_preop');
		$query = $builder->select("COUNT(id) as count, surgery_location as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('surgery_location');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/location_v', $data);                
    }
    public function purpose() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_preop');
		$query = $builder->select("COUNT(id) as count, purpose as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('purpose');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/purpose_v', $data);                
    }

    public function consultant() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("COUNT(id) as count, cnb_done_by2 as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('cnb_done_by2');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("COUNT(id) as count, supervision as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('supervision');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$supervision = [];
		foreach($record as $row) {
			$supervision[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);
		$data['supervision'] = ($supervision);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/consultant_v', $data);                
    }

    public function patient_status() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count, patient_status as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('patient_status');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count, patient_position as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('patient_position');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$patient_position = [];
		foreach($record as $row) {
			$patient_position[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);
		$data['patient_position'] = ($patient_position);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/patient_status_v', $data);                 
    }

     public function sterility_features() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count, skin_prep as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('skin_prep');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/sterility_features_v', $data);                
    }

    public function anatomical() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,anatomical_landmark as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('anatomical_landmark');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,approach as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('approach');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$approach = [];
		foreach($record as $row) {
			$approach[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,no_attempts as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('no_attempts');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$attempts = [];
		foreach($record as $row) {
			$attempts[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);
		$data['approach'] = ($approach);
		$data['attempts'] = ($attempts);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/anatomical_v', $data);                
    }

    public function ultra_sound() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,ultra_sound as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('ultra_sound');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,image_quality as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('image_quality');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$image_quality = [];
		foreach($record as $row) {
			$image_quality[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

	

		$data['products'] = ($products);
		$data['image_quality'] = ($image_quality);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/ultra_sound_v', $data);                
    }

    public function needle_brand() {  
        
		$db = \Config\Database::connect();

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,needle_brand as s");
		if($_POST['from_date'] && $_POST['to_date']){
			$builder->where('created_at >=',$_POST['from_date']);
			$builder->where('created_at <=', $_POST['to_date']);
		}
		$query = $builder->groupBy('needle_brand');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		

		$data['products'] = ($products);
		
		$data['total'] = $total;       
		//$query = $db->getLastQuery();
		return view('cnb/reports/needle_brand_v', $data);                
    }
}