<?php 

namespace App\Controllers\cnb;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\ApiModel;
 


class Reports extends ResourceController
{

    use ResponseTrait;

	public function index() {
        // report analytics
        return view('flowD/reports');  
		               
    }

    public function reports_home() {

    	$name = session()->get('name');
    	// $z = $_POST['from_date'];
    	// print_r($z);die();
     

         // print_r($audit);die();

  //   if($_POST['from_date'] && $_POST['to_date']){
		// 	$builder->where('created_at >=',$_POST['from_date']);
		// 	$builder->where('created_at <=', $_POST['to_date']);
		// }

		// else
		// {
		// 	echo "Please select date";
		// }


        return view('cnb/reports/cnb-reports');  
		               
    }

     public function z(){

		$db = \Config\Database::connect();

    	$name = session()->get('name');

    	   $audit = array(
        	'from_date' => $_POST['from_date'],
        	'to_date'   => $_POST['to_date']
        );

        session()->set($audit);

            return json_encode(array(
                 'result'    => 1,
                 'message'   => 'session created.....'
            ));
    }

     public function procedure_success() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');
		// var_dump($to_date);die();
		// print_r(date('Y-m-d',strtotime($from_date)));die();		
		
		$builder = $db->table('procedure_epidural');
        $query = $builder->select("count(success_status) as NO");
        $query = $builder->where('success_status ','NO');
        // $query = $builder->orLike('success_status ','');
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
        $query = $builder->get();
        $record16 = $query->getResult();
        foreach($record16 as $row) {
          $success_status = $row->NO;
        }
        $other16[] = array(
            'day'   => 'NO',
            'sell' => $success_status
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(success_status) as YES");
        $query = $builder->where('success_status ','YES');
        if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
        $query = $builder->get();
        $record166 = $query->getResult();


    
        foreach($record166 as $row) {
          $success_status = $row->YES;
        }
        $other16[] = array(
            'day'   => 'YES',
            'sell' => $success_status
        );
        $data['other16'] = ($other16);  

		

		return view('cnb/reports/procedure_success', $data);    
		
		// else 
		// return 'Something went wrong...';            
    }
	public function asa() {
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');
// print_r($from_date);die();
		$total = 0;
		$products = [];

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("MAX(age) as maxage,MIN(age) as minage,MAX(weight_kg) as maxweight,MIN(weight_kg) as minweight");
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record = $query->getResult();
		foreach($record as $row) {
			$max_age = $row->maxage;
			$min_age = $row->minage;

			$maxweight = $row->maxweight;
			$minweight = $row->minweight;
		}
		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(gender) as female");
		$query = $builder->where('gender','Female');
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$female = $row->female;
		}
		$products[] = array(
			    'day'   => 'Female',
			    'sell' => $female
		);
		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(gender) as male");
		$query = $builder->where('gender','Male');
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$male = $row->male;
		}
		$products[] = array(
			    'day'   => 'Male',
			    'sell' => $male
		);

		$bmi = [];

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(bmi) as bmi1");
		$query = $builder->where('bmi >=','30');
		$query = $builder->where('bmi <=','34.99');
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record = $query->getResult();
		
		
		foreach($record as $row) {
			
			$bmi1 = $row->bmi1;
			$bmi[] = array(
			    'day'   => 'bmi >= 30',
			    'sell' => $bmi1
			);
		}

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(bmi) as bmi2");
		$query = $builder->where('bmi >=','35');
		$query = $builder->where('bmi <=','39.99');
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record = $query->getResult();
		
		
		foreach($record as $row) {
			
			$bmi2 = $row->bmi2;
			$bmi[] = array(
			    'day'   => 'bmi >= 35',
			    'sell' => $bmi2
			);
		}

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(bmi) as bmi3");
		$query = $builder->where('bmi >=','40');
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record = $query->getResult();
		
		
		foreach($record as $row) {
			
			$bmi3 = $row->bmi3;
			$bmi[] = array(
			    'day'   => 'bmi >= 40',
			    'sell' => $bmi3
			);
		}

		$data['bmi1'] = $bmi1;
		$data['bmi2'] = $bmi2;
		$data['bmi3'] = $bmi3;
		$data['total_n'] = $total; 
		$data['max_age'] = $max_age; 
		$data['min_age'] = $min_age; 
		$data['female'] = $female;
		$data['male'] = $male; 
		$data['maxweight'] = $maxweight; 
		$data['minweight'] = $minweight;


		$data['products'] = ($products); 
		$data['bmi'] = ($bmi);  

		

		return view('cnb/reports/asa_v', $data);                
    }


    public function n_report1() {
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');
// print_r($from_date);die();
		$total = 0;
		$products = [];

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("MAX(age) as maxage,MIN(age) as minage,MAX(weight_kg) as maxweight,MIN(weight_kg) as minweight");
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record = $query->getResult();
		foreach($record as $row) {
			$max_age = $row->maxage;
			$min_age = $row->minage;

			$maxweight = $row->maxweight;
			$minweight = $row->minweight;
		}
		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(gender) as female");
		$query = $builder->where('gender','Female');
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$female = $row->female;
		}
		$products[] = array(
			    'day'   => 'Female',
			    'sell' => $female
		);
		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(gender) as male");
		$query = $builder->where('gender','Male');
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$male = $row->male;
		}
		$products[] = array(
			    'day'   => 'Male',
			    'sell' => $male
		);

		$bmi = [];

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(bmi) as bmi1");
		$query = $builder->where('bmi >=','30');
		$query = $builder->where('bmi <=','34.99');
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record = $query->getResult();
		
		
		foreach($record as $row) {
			
			$bmi1 = $row->bmi1;
			$bmi[] = array(
			    'day'   => 'bmi >= 30',
			    'sell' => $bmi1
			);
		}

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(bmi) as bmi2");
		$query = $builder->where('bmi >=','35');
		$query = $builder->where('bmi <=','39.99');
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record = $query->getResult();
		
		
		foreach($record as $row) {
			
			$bmi2 = $row->bmi2;
			$bmi[] = array(
			    'day'   => 'bmi >= 35',
			    'sell' => $bmi2
			);
		}

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("count(bmi) as bmi3");
		$query = $builder->where('bmi >=','40');
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record = $query->getResult();
		
		
		foreach($record as $row) {
			
			$bmi3 = $row->bmi3;
			$bmi[] = array(
			    'day'   => 'bmi >= 40',
			    'sell' => $bmi3
			);
		}

		$data['bmi1'] = $bmi1;
		$data['bmi2'] = $bmi2;
		$data['bmi3'] = $bmi3;
		$data['total_n'] = $total; 
		$data['max_age'] = $max_age; 
		$data['min_age'] = $min_age; 
		$data['female'] = $female;
		$data['male'] = $male; 
		$data['maxweight'] = $maxweight; 
		$data['minweight'] = $minweight;


		$data['products'] = ($products); 
		$data['bmi'] = ($bmi);  

		

		return view('cnb/reports/demography_v', $data);                
    }

	public function late_complication() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		// -------------------------postdural_puncture----------------

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(postdural_puncture) as NO");
		$query = $builder->where('postdural_puncture','No');
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record1 = $query->getResult();
		foreach($record1 as $row) {
			$postdural_puncture = $row->NO;
		}
		$postdural[] = array(
			    'day'   => 'NO',
			    'sell' => $postdural_puncture
		);

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(postdural_puncture) as YES");
		$query = $builder->where('postdural_puncture','Yes');
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record2 = $query->getResult();

		foreach($record2 as $row) {
			$postdural_puncture = $row->YES;
		}
		$postdural[] = array(
			    'day'   => 'YES',
			    'sell' => $postdural_puncture
		);

		$data['postdural'] = ($postdural); 


		// -------------------------backache_epidural----------------

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(backache_epidural) as NO");
		$query = $builder->where('backache_epidural','No');
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record3 = $query->getResult();
		foreach($record3 as $row) {
			$backache_epidural = $row->NO;
		}
		$backache[] = array(
			    'day'   => 'NO',
			    'sell' => $backache_epidural
		);

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(backache_epidural) as YES");
		$query = $builder->where('backache_epidural','Yes');
		if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
		$query = $builder->get();
		$record4 = $query->getResult();

		foreach($record4 as $row) {
			$backache_epidural = $row->YES;
		}
		$backache[] = array(
			    'day'   => 'YES',
			    'sell' => $backache_epidural
		);

		$data['backache'] = ($backache); 


			// -------------------------perst_motor----------------

			$builder = $db->table('cnb_followup');
			$query = $builder->select("count(perst_motor) as NO");
			$query = $builder->where('perst_motor','No');
			if($from_date && $to_date){
         $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
      }
			$query = $builder->get();
			$record5 = $query->getResult();
			foreach($record5 as $row) {
				$perst_motor = $row->NO;
			}
			$motor[] = array(
					'day'   => 'NO',
					'sell' => $perst_motor
			);
	
			$builder = $db->table('cnb_followup');
			$query = $builder->select("count(perst_motor) as YES");
			$query = $builder->where('perst_motor','Yes');
			$query = $builder->get();
			$record6 = $query->getResult();
	
			foreach($record6 as $row) {
				$perst_motor = $row->YES;
			}
			$motor[] = array(
					'day'   => 'YES',
					'sell' => $perst_motor
			);
	
			$data['motor'] = ($motor); 

		// -------------------------perst_sensory----------------

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(perst_sensory) as NO");
		$query = $builder->where('perst_sensory','No');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record7 = $query->getResult();
		foreach($record7 as $row) {
			$perst_sensory = $row->NO;
		}
		$sensory[] = array(
				'day'   => 'NO',
				'sell' => $perst_sensory
		);

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(perst_sensory) as YES");
		$query = $builder->where('perst_sensory','Yes');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record8 = $query->getResult();

		foreach($record8 as $row) {
			$perst_sensory = $row->YES;
		}
		$sensory[] = array(
				'day'   => 'YES',
				'sell' => $perst_sensory
		);

		$data['sensory'] = ($sensory); 
		
	// -------------------------asep_meningi----------------

	$builder = $db->table('cnb_followup');
	$query = $builder->select("count(asep_meningi) as NO");
	$query = $builder->where('asep_meningi','No');
	if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
	$query = $builder->get();
	$record9 = $query->getResult();
	foreach($record9 as $row) {
		$asep_meningi = $row->NO;
	}
	$asep[] = array(
			'day'   => 'NO',
			'sell' => $asep_meningi
	);

	$builder = $db->table('cnb_followup');
	$query = $builder->select("count(asep_meningi) as YES");
	$query = $builder->where('asep_meningi','Yes');
	if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
	$query = $builder->get();
	$record10 = $query->getResult();

	foreach($record10 as $row) {
		$asep_meningi = $row->YES;
	}
	$asep[] = array(
			'day'   => 'YES',
			'sell' => $asep_meningi
	);

	$data['asep'] = ($asep); 
	
	
	// -------------------------bacterial_meningi----------------

	$builder = $db->table('cnb_followup');
	$query = $builder->select("count(bacterial_meningi) as NO");
	$query = $builder->where('bacterial_meningi','No');
	if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
	$query = $builder->get();
	$record11 = $query->getResult();
	foreach($record11 as $row) {
		$bacterial_meningi = $row->NO;
	}
	$bacterial[] = array(
			'day'   => 'NO',
			'sell' => $bacterial_meningi
	);

	$builder = $db->table('cnb_followup');
	$query = $builder->select("count(bacterial_meningi) as YES");
	$query = $builder->where('bacterial_meningi','Yes');
	if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
	$query = $builder->get();
	$record12 = $query->getResult();

	foreach($record12 as $row) {
		$bacterial_meningi = $row->YES;
	}
	$bacterial[] = array(
			'day'   => 'YES',
			'sell' => $bacterial_meningi
	);

	$data['bacterial'] = ($bacterial);

		// -------------------------epidural_abs----------------

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(epidural_abs) as NO");
		$query = $builder->where('epidural_abs','No');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record13 = $query->getResult();
		foreach($record13 as $row) {
			$epidural_abs = $row->NO;
		}
		$abs[] = array(
				'day'   => 'NO',
				'sell' => $epidural_abs
		);
	
		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(epidural_abs) as YES");
		$query = $builder->where('epidural_abs','Yes');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record14 = $query->getResult();
	
		foreach($record14 as $row) {
			$epidural_abs = $row->YES;
		}
		$abs[] = array(
				'day'   => 'YES',
				'sell' => $epidural_abs
		);
	
		$data['abs'] = ($abs);

		// -------------------------perm_neuro_compli----------------

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(perm_neuro_compli) as NO");
		$query = $builder->where('perm_neuro_compli','No');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record15 = $query->getResult();
		foreach($record15 as $row) {
			$perm_neuro_compli = $row->NO;
		}
		$perm[] = array(
				'day'   => 'NO',
				'sell' => $perm_neuro_compli
		);
	
		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(perm_neuro_compli) as YES");
		$query = $builder->where('perm_neuro_compli','Yes');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record16 = $query->getResult();
	
		foreach($record16 as $row) {
			$perm_neuro_compli = $row->YES;
		}
		$perm[] = array(
				'day'   => 'YES',
				'sell' => $perm_neuro_compli
		);
	
		$data['perm'] = ($perm);

		// -------------------------catheter----------------

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(catheter) as NO");
		$query = $builder->where('catheter','No');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record17 = $query->getResult();
		foreach($record17 as $row) {
			$catheter1 = $row->NO;
		}
		$catheter[] = array(
				'day'   => 'NO',
				'sell' => $catheter1
		);
	
		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(catheter) as YES");
		$query = $builder->where('catheter','Yes');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record18 = $query->getResult();
	
		foreach($record18 as $row) {
			$catheter1 = $row->YES;
		}
		$catheter[] = array(
				'day'   => 'YES',
				'sell' => $catheter1
		);
	
		$data['catheter'] = ($catheter);


		// -------------------------epidural_haema----------------

		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(epidural_haema) as NO");
		$query = $builder->where('epidural_haema','No');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record19 = $query->getResult();
		foreach($record19 as $row) {
			$epidural_haema = $row->NO;
		}
		$haema[] = array(
				'day'   => 'NO',
				'sell' => $epidural_haema
		);
	
		$builder = $db->table('cnb_followup');
		$query = $builder->select("count(epidural_haema) as YES");
		$query = $builder->where('epidural_haema','Yes');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record20 = $query->getResult();
	
		foreach($record20 as $row) {
			$epidural_haema = $row->YES;
		}
		$haema[] = array(
				'day'   => 'YES',
				'sell' => $epidural_haema
		);
	
		$data['haema'] = ($haema);

			// -------------------------others----------------

			$builder = $db->table('cnb_followup');
			$query = $builder->select("count(others) as NO");
			$query = $builder->where('others','No');
			if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
			$query = $builder->get();
			$record21 = $query->getResult();
			foreach($record21 as $row) {
				$others1 = $row->NO;
			}
			$others[] = array(
					'day'   => 'NO',
					'sell' => $others1
			);
		
			$builder = $db->table('cnb_followup');
			$query = $builder->select("count(others) as YES");
			$query = $builder->where('others','Yes');
			if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
			$query = $builder->get();
			$record21 = $query->getResult();
		
			foreach($record21 as $row) {
				$others1 = $row->YES;
			}
			$others[] = array(
					'day'   => 'YES',
					'sell' => $others1
			);
		
			$data['others'] = ($others);
		// print_r($postdural);die();


		return view('cnb/reports/late_complication_v', $data);     
    }

	public function n_re() {

		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		// $total = 0;
		$products = [];

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('cnb_postop.created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('cnb_postop.created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$products[] = array(
			    'day'   => 'N',
			    'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$total = 0;


		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(cnb_postop.id) as count");
		$builder->join('manual_feedback', 'manual_feedback.patient_id = cnb_postop.patient_id');
		$builder->join('cnb_followup', 'cnb_followup.patient_id = cnb_postop.patient_id');
		if($from_date && $to_date){
          $query = $builder->where('cnb_postop.created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('cnb_postop.created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(cnb_postop.id) as count");
		$builder->join('e_feedback', 'e_feedback.patient_id = cnb_postop.patient_id');
		$builder->join('cnb_followup', 'cnb_followup.patient_id = cnb_postop.patient_id');
		if($from_date && $to_date){
          $query = $builder->where('cnb_postop.created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('cnb_postop.created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
			$products[] = array(
			   'day'   => 'Nc',
			   'sell' => $total
			);

		}

		$data['products'] = ($products); 
		$data['total'] = $total;       
// procedure
		$all_total = 0;
		$e_products = [];
		$e_total = 0;

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record11 = $query->getResult();

		foreach($record11 as $row) {
			$e_products[] = array(
			    'day'   => 'Ne',
			    'sell' => floatval($row->count)
			);
			$e_total += floatval($row->count);
			$all_total += floatval($row->count);
		}

		
		$data['e_products'] = ($e_products); 
		$data['e_total'] = $e_total;    
		// print_r($e_total);die(); 

// -------------------------------spinal--------------------
		$s_products = [];
		$s_total = 0;

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record12 = $query->getResult();

		foreach($record12 as $row) {
			$s_products[] = array(
			    'day'   => 'Ns',
			    'sell' => floatval($row->count)
			);
			$s_total += floatval($row->count);
			$all_total += floatval($row->count);
		}

		
		$data['s_products'] = ($s_products); 
		$data['s_total'] = $s_total;    

		// -------------------------------csa--------------------
		$csa_products = [];
		$csa_total = 0;

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record13 = $query->getResult();

		foreach($record13 as $row) {
			$csa_products[] = array(
			    'day'   => 'Ncsa',
			    'sell' => floatval($row->count)
			);
			$csa_total += floatval($row->count);
			$all_total += floatval($row->count);
		}

		
		$data['csa_products'] = ($csa_products); 
		$data['csa_total'] = $csa_total;  
		
		// -------------------------------csa--------------------
		$cse_products = [];
		$cse_total = 0;

		$builder = $db->table('procedure_cse');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record14 = $query->getResult();

		foreach($record14 as $row) {
			$cse_products[] = array(
			    'day'   => 'Ncse',
			    'sell' => floatval($row->count)
			);
			$cse_total += floatval($row->count);
			$all_total += floatval($row->count);
		}

		
		$data['cse_products'] = ($cse_products); 
		$data['cse_total'] = $cse_total;  

		$e_number = (($e_total/$all_total)*100);
		$s_number = (($s_total/$all_total)*100);
		$csa_number = (($csa_total/$all_total)*100);
		$cse_number = (($cse_total/$all_total)*100);
									 
		// echo number_format((float)$number, 2, '.', '')."%";

		// print_r($e_number);die();

		$data['e_perc'] = number_format((float)$e_number, 2, '.', '')."%";
		$data['s_perc'] = number_format((float)$s_number, 2, '.', '')."%";
		$data['csa_perc'] = number_format((float)$csa_number, 2, '.', '')."%";
		$data['cse_perc'] = number_format((float)$cse_number, 2, '.', '')."%";
	

		return view('cnb/reports/n_report', $data);                
    }


	public function n_report() {

		$db = \Config\Database::connect();
	
		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');
	
		if($from_date == '' && $to_date ==''){
			 return view('includes/reports-date-header'); 
		} 
		else{
	
	
		   
			$total = 0;
			$products = [];
	
			$total_nc = 0;
	
			// csa
	
			$builder = $db->table('cnb_postop');
			$query = $builder->select("COUNT(cnb_postop.id) as count");
			$builder->join('procedure_csa', 'procedure_csa.patient_id = cnb_postop.patient_id');
			$query = $builder->where('procedure_csa.procedure_date >=',date('Y-m-d',strtotime($from_date)));
			$query = $builder->where('procedure_csa.procedure_date <=',date('Y-m-d',strtotime($to_date)));
			$query = $builder->get();
			$record = $query->getResult();
	
			foreach($record as $row) {
				$total += floatval($row->count);
				$csa_total = floatval($row->count);
			}
	
	
			// cse
	
			$builder = $db->table('cnb_postop');
			$query = $builder->select("COUNT(cnb_postop.id) as count");
			$builder->join('procedure_cse', 'procedure_cse.patient_id = cnb_postop.patient_id');
			$query = $builder->where('procedure_cse.procedure_date >=',date('Y-m-d',strtotime($from_date)));
			$query = $builder->where('procedure_cse.procedure_date <=',date('Y-m-d',strtotime($to_date)));
			$query = $builder->get();
			$record = $query->getResult();
	
			foreach($record as $row) {
				$total += floatval($row->count);
				$cse_total = floatval($row->count);
			}
	
	
			// 	procedure_epidural
	
	
			$builder = $db->table('cnb_postop');
			$query = $builder->select("COUNT(cnb_postop.id) as count");
			$builder->join('procedure_epidural', 'procedure_epidural.patient_id = cnb_postop.patient_id');
			$query = $builder->where('procedure_epidural.procedure_date >=',date('Y-m-d',strtotime($from_date)));
			$query = $builder->where('procedure_epidural.procedure_date <=',date('Y-m-d',strtotime($to_date)));
			$query = $builder->get();
			$record = $query->getResult();
	
			foreach($record as $row) {
				$total += floatval($row->count);
				$e_total = floatval($row->count);
			}
	
			// 	procedure_spinal
	
	
			$builder = $db->table('cnb_postop');
			$query = $builder->select("COUNT(cnb_postop.id) as count");
			$builder->join('procedure_spinal', 'procedure_spinal.patient_id = cnb_postop.patient_id','left');
			$query = $builder->where('procedure_spinal.procedure_date >=',date('Y-m-d',strtotime($from_date)));
			$query = $builder->where('procedure_spinal.procedure_date <=',date('Y-m-d',strtotime($to_date)));
			$query = $builder->get();
	
			$record = $query->getResult();
	
			foreach($record as $row) {
				$total += floatval($row->count);
				$s_total = floatval($row->count);
			}
			 
	
			// $db = \Config\Database::connect();
			// $query = $db->getLastQuery();
			// echo $query;
	
			// die();
	
	
			$products[] = array(
				 'day'   => 'N`',
				 'sell' => $total
			);
	
	
			// nc csa
	
			$builder = $db->table('cnb_postop');
			$query = $builder->select("COUNT(cnb_postop.id) as count");
			$builder->join('procedure_csa', 'procedure_csa.patient_id = cnb_postop.patient_id');
			$builder->join('manual_feedback', 'manual_feedback.patient_id = cnb_postop.patient_id');
			$builder->join('cnb_followup', 'cnb_followup.patient_id = cnb_postop.patient_id');
			$query = $builder->where('procedure_csa.procedure_date >=',date('Y-m-d',strtotime($from_date)));
			$query = $builder->where('procedure_csa.procedure_date <=',date('Y-m-d',strtotime($to_date)));
	
			$query = $builder->get();
			$record = $query->getResult();
	
			foreach($record as $row) {
				$total_nc += floatval($row->count);
			}
	
	
	
			//nc cse
	
	
			$builder = $db->table('cnb_postop');
			$query = $builder->select("COUNT(cnb_postop.id) as count");
			$builder->join('procedure_cse', 'procedure_cse.patient_id = cnb_postop.patient_id');
			$builder->join('manual_feedback', 'manual_feedback.patient_id = cnb_postop.patient_id');
			$builder->join('cnb_followup', 'cnb_followup.patient_id = cnb_postop.patient_id');
			$query = $builder->where('procedure_cse.procedure_date >=',date('Y-m-d',strtotime($from_date)));
			$query = $builder->where('procedure_cse.procedure_date <=',date('Y-m-d',strtotime($to_date)));
			$query = $builder->get();
			$record = $query->getResult();
	
			foreach($record as $row) {
				$total_nc += floatval($row->count);
			}
	
	
		   // nc epidural
	
	
			$builder = $db->table('cnb_postop');
			$query = $builder->select("COUNT(cnb_postop.id) as count");
			$builder->join('procedure_epidural', 'procedure_epidural.patient_id = cnb_postop.patient_id');
			$builder->join('manual_feedback', 'manual_feedback.patient_id = cnb_postop.patient_id');
			$builder->join('cnb_followup', 'cnb_followup.patient_id = cnb_postop.patient_id');
			$query = $builder->where('procedure_epidural.procedure_date >=',date('Y-m-d',strtotime($from_date)));
			$query = $builder->where('procedure_epidural.procedure_date <=',date('Y-m-d',strtotime($to_date)));
			$query = $builder->get();
			$record = $query->getResult();
	
			foreach($record as $row) {
				$total_nc += floatval($row->count);
			}
	
			// nc spinal
	
			$builder = $db->table('cnb_postop');
			$query = $builder->select("COUNT(cnb_postop.id) as count");
			$builder->join('procedure_spinal', 'procedure_spinal.patient_id = cnb_postop.patient_id');
			$builder->join('manual_feedback', 'manual_feedback.patient_id = cnb_postop.patient_id');
			$builder->join('cnb_followup', 'cnb_followup.patient_id = cnb_postop.patient_id');
			$query = $builder->where('procedure_spinal.procedure_date >=',date('Y-m-d',strtotime($from_date)));
			$query = $builder->where('procedure_spinal.procedure_date <=',date('Y-m-d',strtotime($to_date)));
			$query = $builder->get();
			$record = $query->getResult();
	
			foreach($record as $row) {
				$total_nc += floatval($row->count);
			}
	
	
			 $products[] = array(
				 'day'   => 'Nc',
				 'sell' => $total_nc
			  );
	
	
			  
			  $n_value = array(
				'n' => $total,
				'nc'   => $total_nc
			  );
	  
			  session()->set($n_value);
	
			$e_number = (($e_total/$total)*100);
			$s_number = (($s_total/$total)*100);
			$csa_number = (($csa_total/$total)*100);
			$cse_number = (($cse_total/$total)*100);
						   
			// echo number_format((float)$number, 2, '.', '')."%";
	
			// print_r($e_number);die(); 
	
			 $s_products[] = array(
			  'day'   => 'Ns',
			  'sell' => $s_total
				);
			 $cse_products[] = array(
			  'day'   => 'Ncse',
			  'sell' => $csa_total
				);
			 $csa_products[] = array(
			  'day'   => 'Ncsa',
			  'sell' => $cse_total
				);
			 $e_products[] = array(
			  'day'   => 'Ne',
			  'sell' => $e_total 
				);
	
	
			 $data['products'] = ($products);
	
			 $data['s_products'] = ($s_products);
	
			 $data['cse_products'] = ($cse_products);
	
			 $data['csa_products'] = ($csa_products);
	
			 $data['e_products'] = ($e_products);
	
	
	
	
			$data['total'] = $total;    
	
	
			$data['products'] = ($products);
	
			 $data['s_total'] = ($s_total);
	
			 $data['cse_total'] = ($cse_total);
	
			 $data['csa_total'] = ($csa_total);
	
			 $data['e_total'] = ($e_total);
	
	
			$data['e_perc'] = number_format((float)$e_number, 2, '.', '')."%";
			$data['s_perc'] = number_format((float)$s_number, 2, '.', '')."%";
			$data['csa_perc'] = number_format((float)$csa_number, 2, '.', '')."%";
			$data['cse_perc'] = number_format((float)$cse_number, 2, '.', '')."%";
		  
	
			return view('cnb/reports/n_report', $data);
			}                
		}

    public function bar() {
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');
	       
		$builder = $db->table('cnb_preop');
	    $query = $builder->select("COUNT(id) as count, COUNT(asa) as s,asa as day");
	        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('asa');
		$query = $builder->get();
	        $data['products'] = $query->getResult();

		$data['products'] = $query->getResult();


		return view('cnb/reports/bar', $data); 
   }
   //------------------------ procedure---------------//

   public function safety() { 
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_preop');
		$query = $builder->select("COUNT(id) as count, asa as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('asa');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/safety_v', $data);                
    }
    public function surgical() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_preop');
		$query = $builder->select("COUNT(id) as count, category as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('category');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/surgical_v', $data);                
    }
    public function speciality() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_preop');
		$query = $builder->select("COUNT(id) as count, speciality as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('speciality');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/speciality_v', $data);                
    }
    public function location() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_preop');
		$query = $builder->select("COUNT(id) as count, surgery_location as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('surgery_location');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/location_v', $data);                
    }
    public function purpose() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_preop');
		$query = $builder->select("COUNT(id) as count, purpose as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('purpose');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/purpose_v', $data);                
    }

    public function consultant() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("COUNT(id) as count, cnb_done_by2 as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('cnb_done_by2');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("COUNT(id) as count, supervision as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('supervision');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$supervision = [];
		foreach($record as $row) {
			$supervision[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);
		$data['supervision'] = ($supervision);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/consultant_v', $data);                
    }

    public function patient_status() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count, patient_status as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('patient_status');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count, patient_position as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('patient_position');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$patient_position = [];
		foreach($record as $row) {
			$patient_position[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);
		$data['patient_position'] = ($patient_position);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/patient_status_v', $data);                 
    }

     public function sterility_features() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count, skin_prep as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('skin_prep');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/sterility_features_v', $data);                
    }

    public function anatomical() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,anatomical_landmark as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('anatomical_landmark');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,approach as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('approach');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$approach = [];
		foreach($record as $row) {
			$approach[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,no_attempts as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('no_attempts');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$attempts = [];
		foreach($record as $row) {
			$attempts[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		//$query = $db->getLastQuery();
		//echo (string)$query;
		//print_r($products); 

		$data['products'] = ($products);
		$data['approach'] = ($approach);
		$data['attempts'] = ($attempts);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/anatomical_v', $data);                
    }

    public function ultra_sound() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,ultra_sound as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('ultra_sound');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,image_quality as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('image_quality');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$image_quality = [];
		foreach($record as $row) {
			$image_quality[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

	

		$data['products'] = ($products);
		$data['image_quality'] = ($image_quality);

		$data['total'] = $total;       
		//$query = $db->getLastQuery();


		return view('cnb/reports/ultra_sound_v', $data);                
    }

    public function needle_brand() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,needle_brand as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('needle_brand');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		

		$data['products'] = ($products);
		
		$data['total'] = $total;       
		//$query = $db->getLastQuery();
		return view('cnb/reports/needle_brand_v', $data);                
    }


	public function cse_technique() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('procedure_cse');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_cse');
		$query = $builder->select("COUNT(id) as count,cse_technique as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('cse_technique');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		

		$data['products'] = ($products);
		
		$data['total'] = $total;    

		return view('cnb/reports/cse_technique_v', $data);                
    }


	public function csa_technique() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,	csa as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('csa');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		
		$data['total'] = $total;    

		return view('cnb/reports/csa_technique_v', $data);                
    }

	public function stay_duration() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_followup');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('cnb_followup');
		$query = $builder->select("COUNT(id) as count,	duration as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('duration');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		

		$data['products'] = ($products);
		
		$data['total'] = $total;    

		// print_r($data);die();

		return view('cnb/reports/stay_duration_v', $data);                
    }

//3.1 started
  //   public function Procedure_Outcomes() {  
        
		// $db = \Config\Database::connect();

		

		// return view('cnb/reports/Procedure_Outcomes_v', $data);                
  //   }




    public function technical_problems() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('procedure_epidural');
        $query = $builder->select("count(tc_equipment) as NO");
        $query = $builder->where('tc_equipment ','NO');
        // $query = $builder->orLike('tc_equipment ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record16 = $query->getResult();
        foreach($record16 as $row) {
          $tc_equipment = $row->NO;
        }
        $other16[] = array(
            'day'   => 'NO',
            'sell' => $tc_equipment
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(tc_equipment) as YES");
        $query = $builder->where('tc_equipment ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record166 = $query->getResult();
    
        foreach($record166 as $row) {
          $tc_equipment = $row->YES;
        }
        $other16[] = array(
            'day'   => 'YES',
            'sell' => $tc_equipment
        );
        $data['other16'] = ($other16); 

		
//for 2
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(tc_multiple) as NO");
        $query = $builder->where('tc_multiple ','NO');
        // $query = $builder->orLike('tc_multiple ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record17 = $query->getResult();
        foreach($record17 as $row) {
          $tc_multiple = $row->NO;
        }
        $other17[] = array(
            'day'   => 'NO',
            'sell' => $tc_multiple
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(tc_multiple) as YES");
        $query = $builder->where('tc_multiple ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record177 = $query->getResult();
    
        foreach($record177 as $row) {
          $tc_multiple = $row->YES;
        }
        $other17[] = array(
            'day'   => 'YES',
            'sell' => $tc_multiple
        );
        $data['other17'] = ($other17); 

		
//for 3
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(tc_2_anaestsetist) as NO");
        $query = $builder->where('tc_2_anaestsetist ','NO');
        // $query = $builder->orLike('tc_2_anaestsetist ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record18 = $query->getResult();
        foreach($record18 as $row) {
          $tc_2_anaestsetist = $row->NO;
        }
        $other18[] = array(
            'day'   => 'NO',
            'sell' => $tc_2_anaestsetist
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(tc_2_anaestsetist) as YES");
        $query = $builder->where('tc_2_anaestsetist ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record188 = $query->getResult();
    
        foreach($record188 as $row) {
          $tc_2_anaestsetist = $row->YES;
        }
        $other18[] = array(
            'day'   => 'YES',
            'sell' => $tc_2_anaestsetist
        );
        $data['other18'] = ($other18); 

		
//for 4
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(tc_abondoned) as NO");
        $query = $builder->where('tc_abondoned ','NO');
        // $query = $builder->orLike('tc_abondoned ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record19 = $query->getResult();
        foreach($record19 as $row) {
          $tc_abondoned = $row->NO;
        }
        $other19[] = array(
            'day'   => 'NO',
            'sell' => $tc_abondoned
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(tc_abondoned) as YES");
        $query = $builder->where('tc_abondoned ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record199 = $query->getResult();
    
        foreach($record199 as $row) {
          $tc_abondoned = $row->YES;
        }
        $other19[] = array(
            'day'   => 'YES',
            'sell' => $tc_abondoned
        );
        $data['other19'] = ($other19); 

			
// for 5
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(tc_catheter) as NO");
        $query = $builder->where('tc_catheter ','NO');
        // $query = $builder->orLike('tc_catheter ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record20 = $query->getResult();
        foreach($record20 as $row) {
          $tc_catheter = $row->NO;
        }
        $other20[] = array(
            'day'   => 'NO',
            'sell' => $tc_catheter
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(tc_catheter) as YES");
        $query = $builder->where('tc_catheter ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record200 = $query->getResult();
    
        foreach($record200 as $row) {
          $tc_catheter = $row->YES;
        }
        $other20[] = array(
            'day'   => 'YES',
            'sell' => $tc_catheter
        );
        $data['other20'] = ($other20); 

		// for 6
		$builder = $db->table('procedure_epidural');
        $query = $builder->select("count(tc_other) as NO");
        $query = $builder->where('tc_other ','NO');
        // $query = $builder->orLike('tc_other ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record21 = $query->getResult();
        foreach($record21 as $row) {
          $tc_other = $row->NO;
        }
        $other21[] = array(
            'day'   => 'NO',
            'sell' => $tc_other
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(tc_other) as YES");
        $query = $builder->where('tc_other ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record211 = $query->getResult();
    
        foreach($record211 as $row) {
          $tc_other = $row->YES;
        }
        $other21[] = array(
            'day'   => 'YES',
            'sell' => $tc_other
        );
        $data['other21'] = ($other21); 

		
		return view('cnb/reports/technical-problems_v', $data);                
    }
    public function acute_problems() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_ep_resited) as NO");
        $query = $builder->where('ac_ep_resited ','NO');
        // $query = $builder->orLike('ac_ep_resited ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record1 = $query->getResult();
        foreach($record1 as $row) {
          $ac_ep_resited = $row->NO;
        }
        $other1[] = array(
            'day'   => 'NO',
            'sell' => $ac_ep_resited
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_ep_resited) as YES");
        $query = $builder->where('ac_ep_resited ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record11 = $query->getResult();
    
        foreach($record11 as $row) {
          $ac_ep_resited = $row->YES;
        }
        $other1[] = array(
            'day'   => 'YES',
            'sell' => $ac_ep_resited
        );
        $data['other1'] = ($other1);

		    
// for 2

        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_last) as NO");
        $query = $builder->where('ac_last ','NO');
        // $query = $builder->orLike('ac_last ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record2 = $query->getResult();
        foreach($record2 as $row) {
          $ac_last = $row->NO;
        }
        $other2[] = array(
            'day'   => 'NO',
            'sell' => $ac_last
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_last) as YES");
        $query = $builder->where('ac_last ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record22 = $query->getResult();
    
        foreach($record22 as $row) {
          $ac_last = $row->YES;
        }
        $other2[] = array(
            'day'   => 'YES',
            'sell' => $ac_last
        );
        $data['other2'] = ($other2);  
// for 3
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_re_arrest) as NO");
        $query = $builder->where('ac_re_arrest ','NO');
        // $query = $builder->orLike('ac_re_arrest ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record3 = $query->getResult();
        foreach($record3 as $row) {
          $ac_re_arrest = $row->NO;
        }
        $other3[] = array(
            'day'   => 'NO',
            'sell' => $ac_re_arrest
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_re_arrest) as YES");
        $query = $builder->where('ac_re_arrest ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record33 = $query->getResult();
    
        foreach($record33 as $row) {
          $ac_re_arrest = $row->YES;
        }
        $other3[] = array(
            'day'   => 'YES',
            'sell' => $ac_re_arrest
        );
        $data['other3'] = ($other3);

		 
// for 4
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_ca_arrest) as NO");
        $query = $builder->where('ac_ca_arrest ','NO');
        // $query = $builder->orLike('ac_ca_arrest ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record4 = $query->getResult();
        foreach($record4 as $row) {
          $ac_ca_arrest = $row->NO;
        }
        $other4[] = array(
            'day'   => 'NO',
            'sell' => $ac_ca_arrest
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_ca_arrest) as YES");
        $query = $builder->where('ac_ca_arrest ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record44 = $query->getResult();
    
        foreach($record44 as $row) {
          $ac_ca_arrest = $row->YES;
        }
        $other4[] = array(
            'day'   => 'YES',
            'sell' => $ac_ca_arrest
        );
        $data['other4'] = ($other4);    
// for 5
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_radi_pain) as NO");
        $query = $builder->where('ac_radi_pain ','NO');
        // $query = $builder->orLike('ac_radi_pain ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record5 = $query->getResult();
        foreach($record5 as $row) {
          $ac_radi_pain = $row->NO;
        }
        $other5[] = array(
            'day'   => 'NO',
            'sell' => $ac_radi_pain
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_radi_pain) as YES");
        $query = $builder->where('ac_radi_pain ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record55 = $query->getResult();
    
        foreach($record55 as $row) {
          $ac_radi_pain = $row->YES;
        }
        $other5[] = array(
            'day'   => 'YES',
            'sell' => $ac_radi_pain
        );
        $data['other5'] = ($other5);

		
       
	// for 6
		$builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_parestsesia) as NO");
        $query = $builder->where('ac_parestsesia ','NO');
        // $query = $builder->orLike('ac_parestsesia ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record6 = $query->getResult();
        foreach($record6 as $row) {
          $ac_parestsesia = $row->NO;
        }
        $other6[] = array(
            'day'   => 'NO',
            'sell' => $ac_parestsesia
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_parestsesia) as YES");
        $query = $builder->where('ac_parestsesia ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record66 = $query->getResult();
    
        foreach($record66 as $row) {
          $ac_parestsesia = $row->YES;
        }
        $other6[] = array(
            'day'   => 'YES',
            'sell' => $ac_parestsesia
        );
        $data['other6'] = ($other6); 
    // for 7
		$builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_bloody_tap) as NO");
        $query = $builder->where('ac_bloody_tap ','NO');
        // $query = $builder->orLike('ac_bloody_tap ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record7 = $query->getResult();
        foreach($record7 as $row) {
          $ac_bloody_tap = $row->NO;
        }
        $other7[] = array(
            'day'   => 'NO',
            'sell' => $ac_bloody_tap
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_bloody_tap) as YES");
        $query = $builder->where('ac_bloody_tap ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record77 = $query->getResult();
    
        foreach($record77 as $row) {
          $ac_bloody_tap = $row->YES;
        }
        $other7[] = array(
            'day'   => 'YES',
            'sell' => $ac_bloody_tap
        );
        $data['other7'] = ($other7);
	 
// for 8

		$builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_wet_tap) as NO");
        $query = $builder->where('ac_wet_tap ','NO');
        // $query = $builder->orLike('ac_wet_tap ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record8 = $query->getResult();
        foreach($record8 as $row) {
          $ac_wet_tap = $row->NO;
        }
        $other8[] = array(
            'day'   => 'NO',
            'sell' => $ac_wet_tap
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_wet_tap) as YES");
        $query = $builder->where('ac_wet_tap ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record88 = $query->getResult();
    
        foreach($record88 as $row) {
          $ac_wet_tap = $row->YES;
        }
        $other8[] = array(
            'day'   => 'YES',
            'sell' => $ac_wet_tap
        );
        $data['other8'] = ($other8);
    
		
				
    // for 9
		$builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_hypoten) as NO");
        $query = $builder->where('ac_hypoten ','NO');
        // $query = $builder->orLike('ac_hypoten ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record9 = $query->getResult();
        foreach($record9 as $row) {
          $ac_hypoten = $row->NO;
        }
        $other9[] = array(
            'day'   => 'NO',
            'sell' => $ac_hypoten
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_hypoten) as YES");
        $query = $builder->where('ac_hypoten ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record99 = $query->getResult();
    
        foreach($record99 as $row) {
          $ac_hypoten = $row->YES;
        }
        $other9[] = array(
            'day'   => 'YES',
            'sell' => $ac_hypoten
        );
        $data['other9'] = ($other9);    

// for 10
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_nausea) as NO");
        $query = $builder->where('ac_nausea ','NO');
        // $query = $builder->orLike('ac_nausea ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record10 = $query->getResult();
        foreach($record10 as $row) {
          $ac_nausea = $row->NO;
        }
        $other10[] = array(
            'day'   => 'NO',
            'sell' => $ac_nausea
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_nausea) as YES");
        $query = $builder->where('ac_nausea ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record110 = $query->getResult();
    
        foreach($record110 as $row) {
          $ac_nausea = $row->YES;
        }
        $other10[] = array(
            'day'   => 'YES',
            'sell' => $ac_nausea
        );
        $data['other10'] = ($other10);    

		// for 11

		$builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_vomit) as NO");
        $query = $builder->where('ac_vomit ','NO');
        // $query = $builder->orLike('ac_vomit ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record11 = $query->getResult();
        foreach($record11 as $row) {
          $ac_vomit = $row->NO;
        }
        $other11[] = array(
            'day'   => 'NO',
            'sell' => $ac_vomit
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_vomit) as YES");
        $query = $builder->where('ac_vomit ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record111 = $query->getResult();
    
        foreach($record111 as $row) {
          $ac_vomit = $row->YES;
        }
        $other11[] = array(
            'day'   => 'YES',
            'sell' => $ac_vomit
        );
        $data['other11'] = ($other11);    

		
// for 12
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_high_block) as NO");
        $query = $builder->where('ac_high_block ','NO');
        // $query = $builder->orLike('ac_high_block ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record12 = $query->getResult();
        foreach($record12 as $row) {
          $ac_high_block = $row->NO;
        }
        $other12[] = array(
            'day'   => 'NO',
            'sell' => $ac_high_block
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_high_block) as YES");
        $query = $builder->where('ac_high_block ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record122 = $query->getResult();
    
        foreach($record122 as $row) {
          $ac_high_block = $row->YES;
        }
        $other12[] = array(
            'day'   => 'YES',
            'sell' => $ac_high_block
        );
        $data['other12'] = ($other12);    

// for 13
		$builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_sb_block) as NO");
        $query = $builder->where('ac_sb_block ','NO');
        // $query = $builder->orLike('ac_sb_block ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record13 = $query->getResult();
        foreach($record13 as $row) {
          $ac_sb_block = $row->NO;
        }
        $other13[] = array(
            'day'   => 'NO',
            'sell' => $ac_sb_block
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_sb_block) as YES");
        $query = $builder->where('ac_sb_block ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record133 = $query->getResult();
    
        foreach($record133 as $row) {
          $ac_sb_block = $row->YES;
        }
        $other13[] = array(
            'day'   => 'YES',
            'sell' => $ac_sb_block
        );
        $data['other13'] = ($other13);    

// for 14
		$builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_motor_block) as NO");
        $query = $builder->where('ac_motor_block ','NO');
        // $query = $builder->orLike('ac_motor_block ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record14 = $query->getResult();
        foreach($record14 as $row) {
          $ac_motor_block = $row->NO;
        }
        $other14[] = array(
            'day'   => 'NO',
            'sell' => $ac_motor_block
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_motor_block) as YES");
        $query = $builder->where('ac_motor_block ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record144 = $query->getResult();
    
        foreach($record144 as $row) {
          $ac_motor_block = $row->YES;
        }
        $other14[] = array(
            'day'   => 'YES',
            'sell' => $ac_motor_block
        );
        $data['other14'] = ($other14);    

// for 15
		$builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_totla_spinal) as NO");
        $query = $builder->where('ac_totla_spinal ','NO');
        // $query = $builder->orLike('ac_totla_spinal ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record15 = $query->getResult();
        foreach($record15 as $row) {
          $ac_totla_spinal = $row->NO;
        }
        $other15[] = array(
            'day'   => 'NO',
            'sell' => $ac_totla_spinal
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_totla_spinal) as YES");
        $query = $builder->where('ac_totla_spinal ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record155 = $query->getResult();
    
        foreach($record155 as $row) {
          $ac_totla_spinal = $row->YES;
        }
        $other15[] = array(
            'day'   => 'YES',
            'sell' => $ac_totla_spinal
        );
        $data['other15'] = ($other15);    

// for 16
		$builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_adp) as NO");
        $query = $builder->where('ac_adp ','NO');
        // $query = $builder->orLike('ac_adp ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record16 = $query->getResult();
        foreach($record16 as $row) {
          $ac_adp = $row->NO;
        }
        $other16[] = array(
            'day'   => 'NO',
            'sell' => $ac_adp
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(ac_adp) as YES");
        $query = $builder->where('ac_adp ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record166 = $query->getResult();
    
        foreach($record166 as $row) {
          $ac_adp = $row->YES;
        }
        $other16[] = array(
            'day'   => 'YES',
            'sell' => $ac_adp
        );
        $data['other16'] = ($other16);    


	

		return view('cnb/reports/acute_problems_v', $data);                
    } 


    public function OP_Analgesia() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');
// for 1
		$builder = $db->table('procedure_epidural');
        $query = $builder->select("count(in_analgesia) as NO");
        $query = $builder->where('in_analgesia ','NO');
        // $query = $builder->orLike('in_analgesia ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record16 = $query->getResult();
        foreach($record16 as $row) {
          $in_analgesia = $row->NO;
        }
        $other16[] = array(
            'day'   => 'NO',
            'sell' => $in_analgesia
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(in_analgesia) as YES");
        $query = $builder->where('in_analgesia ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record166 = $query->getResult();
    
        foreach($record166 as $row) {
          $in_analgesia = $row->YES;
        }
        $other16[] = array(
            'day'   => 'YES',
            'sell' => $in_analgesia
        );
        $data['other16'] = ($other16);    

// for 2
		$builder = $db->table('procedure_epidural');
        $query = $builder->select("count(asr_iv_analgesia) as NO");
        $query = $builder->where('asr_iv_analgesia ','NO');
        // $query = $builder->orLike('asr_iv_analgesia ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record17 = $query->getResult();
        foreach($record17 as $row) {
          $asr_iv_analgesia = $row->NO;
        }
        $other17[] = array(
            'day'   => 'NO',
            'sell' => $asr_iv_analgesia
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(asr_iv_analgesia) as YES");
        $query = $builder->where('asr_iv_analgesia ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record177 = $query->getResult();
    
        foreach($record177 as $row) {
          $asr_iv_analgesia = $row->YES;
        }
        $other17[] = array(
            'day'   => 'YES',
            'sell' => $asr_iv_analgesia
        );
        $data['other17'] = ($other17);    

// // for 4
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(opioids) as NO");
        $query = $builder->where('opioids ','NO');
        // $query = $builder->orLike('opioids ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record15 = $query->getResult();
        foreach($record15 as $row) {
          $opioids = $row->NO;
        }
        $other15[] = array(
            'day'   => 'NO',
            'sell' => $opioids
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(opioids) as YES");
        $query = $builder->where('opioids ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record155 = $query->getResult();
    
        foreach($record155 as $row) {
          $opioids = $row->YES;
        }
        $other15[] = array(
            'day'   => 'YES',
            'sell' => $opioids
        );
        $data['other15'] = ($other15); 
// // for 3
		$builder = $db->table('procedure_epidural');
        $query = $builder->select("count(asr_multimode) as NO");
        $query = $builder->where('asr_multimode ','NO');
        // $query = $builder->orLike('asr_multimode ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record18 = $query->getResult();
        foreach($record18 as $row) {
          $asr_multimode = $row->NO;
        }
        $other18[] = array(
            'day'   => 'NO',
            'sell' => $asr_multimode
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(asr_multimode) as YES");
        $query = $builder->where('asr_multimode ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record188 = $query->getResult();
    
        foreach($record188 as $row) {
          $asr_multimode = $row->YES;
        }
        $other18[] = array(
            'day'   => 'YES',
            'sell' => $asr_multimode
        );
        $data['other18'] = ($other18);    
 
 // for 5
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(in_analgesia) as NO");
        $query = $builder->where('in_analgesia ','NO');
        // $query = $builder->orLike('in_analgesia ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record19 = $query->getResult();
        foreach($record19 as $row) {
          $in_analgesia = $row->NO;
        }
        $other19[] = array(
            'day'   => 'NO',
            'sell' => $in_analgesia
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(in_analgesia) as YES");
        $query = $builder->where('in_analgesia ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record199 = $query->getResult();
    
        foreach($record199 as $row) {
          $in_analgesia = $row->YES;
        }
        $other19[] = array(
            'day'   => 'YES',
            'sell' => $in_analgesia
        );
        $data['other19'] = ($other19);    

		return view('cnb/reports/OP_Analgesia_v', $data);                
    }

     public function IV_Supplements() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

    	$builder = $db->table('procedure_epidural');
        $query = $builder->select("count(la_regimen) as Continous_Infusion");
        $query = $builder->where('la_regimen ','Continous_Infusion');
        // $query = $builder->orLike('la_regimen ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record16 = $query->getResult();

        foreach($record16 as $row) {
          $la_regimen = $row->Continous_Infusion;
        }
        $other16[] = array(
            'day'   => 'Continous_Infusion',
            'sell' => $la_regimen
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(la_regimen) as Intermittent_Infusion");
        $query = $builder->where('la_regimen ','Intermittent_Infusion');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record166 = $query->getResult();
    
        foreach($record166 as $row) {
          $la_regimen = $row->Intermittent_Infusion;
        }
        $other16[] = array(
            'day'   => 'Intermittent_Infusion',
            'sell' => $la_regimen
        );
        $data['other16'] = ($other16);
   

		return view('cnb/reports/IV_Supplements_v', $data);                
    }

     public function Outcome_characteristics() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');
// surger anesthesia
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, surgical_anaesthesia as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('surgical_anaesthesia');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$surgical_anaesthesia = [];
		foreach($record as $row) {
			$surgical_anaesthesia[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['surgical_anaesthesia'] = ($surgical_anaesthesia);

		$data['total18'] = $surgical_anaesthesia;
// surgery_duration
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, surgery_duration as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('surgery_duration');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$surgery_duration = [];
		foreach($record as $row) {
			$surgery_duration[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['surgery_duration'] = ($surgery_duration);

		$data['total19'] = $surgery_duration;
// bood_loss
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, blood_loss as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('blood_loss');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$blood_loss = [];
		foreach($record as $row) {
			$blood_loss[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['blood_loss'] = ($blood_loss);

		$data['total21'] = $blood_loss;
// vasopressor_use
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(vasopressor_use) as NO");
        $query = $builder->where('vasopressor_use ','NO');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        // $query = $builder->orLike('vasopressor_use ','');
        $query = $builder->get();
        $record18 = $query->getResult();
        foreach($record18 as $row) {
          $vasopressor_use = $row->NO;
        }
        $other18[] = array(
            'day'   => 'NO',
            'sell' => $vasopressor_use
        );
    
        $builder = $db->table('procedure_epidural');
        $query = $builder->select("count(vasopressor_use) as YES");
        $query = $builder->where('vasopressor_use ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record188 = $query->getResult();
    
        foreach($record188 as $row) {
          $vasopressor_use = $row->YES;
        }
        $other18[] = array(
            'day'   => 'YES',
            'sell' => $vasopressor_use
        );
        $data['other18'] = ($other18);

		return view('cnb/reports/Outcome_characteristics_v', $data);                
    }

     public function Pain_Score() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count, ps_postproc as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('ps_postproc');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$ps_postproc = [];
		foreach($record as $row) {
			$ps_postproc[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['ps_postproc'] = ($ps_postproc);

		$data['total'] = $ps_postproc;

		 $builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count, 	ps_30mins as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('ps_30mins');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$ps_30mins = [];
		foreach($record as $row) {
			$ps_30mins[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['ps_30mins'] = ($ps_30mins);

		$data['total1'] = $ps_30mins;

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count, ps_1hr as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('ps_1hr');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$ps_1hr = [];
		foreach($record as $row) {
			$ps_1hr[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['ps_1hr'] = ($ps_1hr);

		$data['total2'] = $ps_1hr; 

		return view('cnb/reports/Pain_Score_v', $data);                
    }

     public function Nausea() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count, nvs_postproc as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('nvs_postproc');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$nvs_postproc = [];
		foreach($record as $row) {
			$nvs_postproc[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['nvs_postproc'] = ($nvs_postproc);

		$data['total'] = $nvs_postproc;

		 $builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count, 	nvs_30mins as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('nvs_30mins');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$nvs_30mins = [];
		foreach($record as $row) {
			$nvs_30mins[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['nvs_30mins'] = ($nvs_30mins);

		$data['total1'] = $nvs_30mins;

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count, nvs_1hr as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('nvs_1hr');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$nvs_1hr = [];
		foreach($record as $row) {
			$nvs_1hr[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['nvs_1hr'] = ($nvs_1hr);

		$data['total2'] = $nvs_1hr;     

		return view('cnb/reports/Nausea_v', $data);                
    }

     public function Sedation_Scores() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count, ss_postproc as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('ss_postproc');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$ss_postproc = [];
		foreach($record as $row) {
			$ss_postproc[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['ss_postproc'] = ($ss_postproc);

		$data['total'] = $ss_postproc;

		 $builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count, 	ss_30mins as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('ss_30mins');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$ss_30mins = [];
		foreach($record as $row) {
			$ss_30mins[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['ss_30mins'] = ($ss_30mins);

		$data['total1'] = $ss_30mins;

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count, ss_1hr as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('ss_1hr');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$ss_1hr = [];
		foreach($record as $row) {
			$ss_1hr[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['ss_1hr'] = ($ss_1hr);

		$data['total2'] = $ss_1hr;     
    

		return view('cnb/reports/Sedation_Scores_v', $data);                
    }

     public function Recovery() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_postop');
		$query = $builder->select("COUNT(id) as count, time_spent as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('time_spent');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$time_spent = [];
		foreach($record as $row) {
			$time_spent[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['time_spent'] = ($time_spent);

		$data['total2'] = $time_spent;     

		return view('cnb/reports/Recovery_v', $data);                
    }

     public function Analgesia() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');
// intravenous_opioids
		$builder = $db->table('cnb_postop');
        $query = $builder->select("count(intravenous_opioids) as NO");
        $query = $builder->where('intravenous_opioids ','NO');
        // $query = $builder->orLike('intravenous_opioids ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record16 = $query->getResult();
        foreach($record16 as $row) {
          $intravenous_opioids = $row->NO;
        }
        $other16[] = array(
            'day'   => 'NO',
            'sell' => $intravenous_opioids
        );
    
        $builder = $db->table('cnb_postop');
        $query = $builder->select("count(intravenous_opioids) as YES");
        $query = $builder->where('intravenous_opioids ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record166 = $query->getResult();
    
        foreach($record166 as $row) {
          $intravenous_opioids = $row->YES;
        }
        $other16[] = array(
            'day'   => 'YES',
            'sell' => $intravenous_opioids
        );
        $data['other16'] = ($other16); 
// oral opioids
        $builder = $db->table('cnb_postop');
        $query = $builder->select("count(oral_opioids) as NO");
        $query = $builder->where('oral_opioids ','NO');
        // $query = $builder->orLike('oral_opioids ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record15 = $query->getResult();
        foreach($record15 as $row) {
          $oral_opioids = $row->NO;
        }
        $other15[] = array(
            'day'   => 'NO',
            'sell' => $oral_opioids
        );
    
        $builder = $db->table('cnb_postop');
        $query = $builder->select("count(oral_opioids) as YES");
        $query = $builder->where('oral_opioids ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record155 = $query->getResult();
    
        foreach($record155 as $row) {
          $oral_opioids = $row->YES;
        }
        $other15[] = array(
            'day'   => 'YES',
            'sell' => $oral_opioids
        );
        $data['other15'] = ($other15);
// Tramadol
        $builder = $db->table('cnb_postop');
        $query = $builder->select("count(tramadol) as NO");
        $query = $builder->where('tramadol ','NO');
        // $query = $builder->orLike('tramadol ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record14 = $query->getResult();
        foreach($record14 as $row) {
          $tramadol = $row->NO;
        }
        $other14[] = array(
            'day'   => 'NO',
            'sell' => $tramadol
        );
    
        $builder = $db->table('cnb_postop');
        $query = $builder->select("count(tramadol) as YES");
        $query = $builder->where('tramadol ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record144 = $query->getResult();
    
        foreach($record144 as $row) {
          $tramadol = $row->YES;
        }
        $other14[] = array(
            'day'   => 'YES',
            'sell' => $tramadol
        );
        $data['other14'] = ($other14);
//nsaid
        $builder = $db->table('cnb_postop');
        $query = $builder->select("count(nsaid) as NO");
        $query = $builder->where('nsaid ','NO');
        // $query = $builder->orLike('nsaid ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record13 = $query->getResult();
        foreach($record13 as $row) {
          $nsaid = $row->NO;
        }
        $other13[] = array(
            'day'   => 'NO',
            'sell' => $nsaid
        );
    
        $builder = $db->table('cnb_postop');
        $query = $builder->select("count(nsaid) as YES");
        $query = $builder->where('nsaid ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record133 = $query->getResult();
    
        foreach($record133 as $row) {
          $nsaid = $row->YES;
        }
        $other13[] = array(
            'day'   => 'YES',
            'sell' => $nsaid
        );
        $data['other13'] = ($other13);
// paracetamol
        $builder = $db->table('cnb_postop');
        $query = $builder->select("count(paracetamol) as NO");
        $query = $builder->where('paracetamol ','NO');
        // $query = $builder->orLike('paracetamol ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record12 = $query->getResult();
        foreach($record12 as $row) {
          $paracetamol = $row->NO;
        }
        $other12[] = array(
            'day'   => 'NO',
            'sell' => $paracetamol
        );
    
        $builder = $db->table('cnb_postop');
        $query = $builder->select("count(paracetamol) as YES");
        $query = $builder->where('paracetamol ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record122 = $query->getResult();
    
        foreach($record122 as $row) {
          $paracetamol = $row->YES;
        }
        $other12[] = array(
            'day'   => 'YES',
            'sell' => $paracetamol
        );
        $data['other12'] = ($other12);
// la_regimen
        $builder = $db->table('cnb_postop');
        $query = $builder->select("count(la_regimen) as NO");
        $query = $builder->where('la_regimen ','NO');
        // $query = $builder->orLike('la_regimen ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record11 = $query->getResult();
        foreach($record11 as $row) {
          $la_regimen = $row->NO;
        }
        $other11[] = array(
            'day'   => 'NO',
            'sell' => $la_regimen
        );
    
        $builder = $db->table('cnb_postop');
        $query = $builder->select("count(la_regimen) as YES");
        $query = $builder->where('la_regimen ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record111 = $query->getResult();
    
        foreach($record111 as $row) {
          $la_regimen = $row->YES;
        }
        $other11[] = array(
            'day'   => 'YES',
            'sell' => $la_regimen
        );
        $data['other11'] = ($other11);
// other
        $builder = $db->table('cnb_postop');
        $query = $builder->select("count(other) as NO");
        $query = $builder->where('other ','NO');
        // $query = $builder->orLike('other ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record10 = $query->getResult();
        foreach($record10 as $row) {
          $other = $row->NO;
        }
        $other10[] = array(
            'day'   => 'NO',
            'sell' => $other
        );
    
        $builder = $db->table('cnb_postop');
        $query = $builder->select("count(other) as YES");
        $query = $builder->where('other ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record100 = $query->getResult();
    
        foreach($record100 as $row) {
          $other = $row->YES;
        }
        $other10[] = array(
            'day'   => 'YES',
            'sell' => $other
        );
        $data['other10'] = ($other10);

		return view('cnb/reports/Analgesia_v', $data);                
    }

    public function Co_Morbid() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

// diabetes_mellitus
		$builder = $db->table('cnb_preop');
        $query = $builder->select("count(diabetes_mellitus) as NO");
        $query = $builder->where('diabetes_mellitus ','NO');
        // $query = $builder->orLike('diabetes_mellitus ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record16 = $query->getResult();
        foreach($record16 as $row) {
          $diabetes_mellitus = $row->NO;
        }
        $other16[] = array(
            'day'   => 'NO',
            'sell' => $diabetes_mellitus
        );
    
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(diabetes_mellitus) as YES");
        $query = $builder->where('diabetes_mellitus ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record166 = $query->getResult();
    
        foreach($record166 as $row) {
          $diabetes_mellitus = $row->YES;
        }
        $other16[] = array(
            'day'   => 'YES',
            'sell' => $diabetes_mellitus
        );
        $data['other16'] = ($other16);  
// cvs disease
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(cvs_disease) as NO");
        $query = $builder->where('cvs_disease ','NO');
        // $query = $builder->orLike('cvs_disease ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record15 = $query->getResult();
        foreach($record15 as $row) {
          $cvs_disease = $row->NO;
        }
        $other15[] = array(
            'day'   => 'NO',
            'sell' => $cvs_disease
        );
    
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(cvs_disease) as YES");
        $query = $builder->where('cvs_disease ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record155 = $query->getResult();
    
        foreach($record155 as $row) {
          $cvs_disease = $row->YES;
        }
        $other15[] = array(
            'day'   => 'YES',
            'sell' => $cvs_disease
        );
        $data['other15'] = ($other15); 
// respiratory disease
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(respiratory_disease) as NO");
        $query = $builder->where('respiratory_disease ','NO');
        // $query = $builder->orLike('respiratory_disease ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record14 = $query->getResult();
        foreach($record14 as $row) {
          $respiratory_disease = $row->NO;
        }
        $other14[] = array(
            'day'   => 'NO',
            'sell' => $respiratory_disease
        );
    
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(respiratory_disease) as YES");
        $query = $builder->where('respiratory_disease ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record144 = $query->getResult();
    
        foreach($record144 as $row) {
          $respiratory_disease = $row->YES;
        }
        $other14[] = array(
            'day'   => 'YES',
            'sell' => $respiratory_disease
        );
        $data['other14'] = ($other14); 
// neurological_disorder
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(neurological_disorder) as NO");
        $query = $builder->where('neurological_disorder ','NO');
        // $query = $builder->orLike('neurological_disorder ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record13 = $query->getResult();
        foreach($record13 as $row) {
          $neurological_disorder = $row->NO;
        }
        $other13[] = array(
            'day'   => 'NO',
            'sell' => $neurological_disorder
        );
    
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(neurological_disorder) as YES");
        $query = $builder->where('neurological_disorder ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record133 = $query->getResult();
    
        foreach($record133 as $row) {
          $neurological_disorder = $row->YES;
        }
        $other13[] = array(
            'day'   => 'YES',
            'sell' => $neurological_disorder
        );
        $data['other13'] = ($other13); 
// renal_disorder
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(renal_disorder) as NO");
        $query = $builder->where('renal_disorder ','NO');
        // $query = $builder->orLike('renal_disorder ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record12 = $query->getResult();
        foreach($record12 as $row) {
          $renal_disorder = $row->NO;
        }
        $other12[] = array(
            'day'   => 'NO',
            'sell' => $renal_disorder
        );
    
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(renal_disorder) as YES");
        $query = $builder->where('renal_disorder ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record122 = $query->getResult();
    
        foreach($record122 as $row) {
          $renal_disorder = $row->YES;
        }
        $other12[] = array(
            'day'   => 'YES',
            'sell' => $renal_disorder
        );
        $data['other12'] = ($other12); 
// spin_back_problem
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(spin_back_problem) as NO");
        $query = $builder->where('spin_back_problem ','NO');
        // $query = $builder->orLike('spin_back_problem ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record11 = $query->getResult();
        foreach($record11 as $row) {
          $spin_back_problem = $row->NO;
        }
        $other11[] = array(
            'day'   => 'NO',
            'sell' => $spin_back_problem
        );
    
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(spin_back_problem) as YES");
        $query = $builder->where('spin_back_problem ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record111 = $query->getResult();
    
        foreach($record111 as $row) {
          $spin_back_problem = $row->YES;
        }
        $other11[] = array(
            'day'   => 'YES',
            'sell' => $spin_back_problem
        );
        $data['other11'] = ($other11); 
// fever_infection
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(fever_infection) as NO");
        $query = $builder->where('fever_infection ','NO');
        // $query = $builder->orLike('fever_infection ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record10 = $query->getResult();
        foreach($record10 as $row) {
          $fever_infection = $row->NO;
        }
        $other10[] = array(
            'day'   => 'NO',
            'sell' => $fever_infection
        );
    
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(fever_infection) as YES");
        $query = $builder->where('fever_infection ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record100 = $query->getResult();
    
        foreach($record100 as $row) {
          $fever_infection = $row->YES;
        }
        $other10[] = array(
            'day'   => 'YES',
            'sell' => $fever_infection
        );
        $data['other10'] = ($other10); 
// bleeding_disorder
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(bleeding_disorder) as NO");
        $query = $builder->where('bleeding_disorder ','NO');
        // $query = $builder->orLike('bleeding_disorder ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record9 = $query->getResult();
        foreach($record9 as $row) {
          $bleeding_disorder = $row->NO;
        }
        $other9[] = array(
            'day'   => 'NO',
            'sell' => $bleeding_disorder
        );
    
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(bleeding_disorder) as YES");
        $query = $builder->where('bleeding_disorder ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record9 = $query->getResult();
    
        foreach($record9 as $row) {
          $bleeding_disorder = $row->YES;
        }
        $other9[] = array(
            'day'   => 'YES',
            'sell' => $bleeding_disorder
        );
        $data['other9'] = ($other9); 
// anaemia
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(anaemia) as NO");
        $query = $builder->where('anaemia ','NO');
        // $query = $builder->orLike('anaemia ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record8 = $query->getResult();
        foreach($record8 as $row) {
          $anaemia = $row->NO;
        }
        $other8[] = array(
            'day'   => 'NO',
            'sell' => $anaemia
        );
    
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(anaemia) as YES");
        $query = $builder->where('anaemia ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record88 = $query->getResult();
    
        foreach($record88 as $row) {
          $anaemia = $row->YES;
        }
        $other8[] = array(
            'day'   => 'YES',
            'sell' => $anaemia
        );
        $data['other8'] = ($other8); 
// malignancy
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(malignancy) as NO");
        $query = $builder->where('malignancy ','NO');
        // $query = $builder->orLike('malignancy ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record7 = $query->getResult();
        foreach($record7 as $row) {
          $malignancy = $row->NO;
        }
        $other7[] = array(
            'day'   => 'NO',
            'sell' => $malignancy
        );
    
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(malignancy) as YES");
        $query = $builder->where('malignancy ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record77 = $query->getResult();
    
        foreach($record77 as $row) {
          $malignancy = $row->YES;
        }
        $other7[] = array(
            'day'   => 'YES',
            'sell' => $malignancy
        );
        $data['other7'] = ($other7); 
// other
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(other) as NO");
        $query = $builder->where('other ','NO');
        // $query = $builder->orLike('other ','');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record6 = $query->getResult();
        foreach($record6 as $row) {
          $other = $row->NO;
        }
        $other6[] = array(
            'day'   => 'NO',
            'sell' => $other
        );
    
        $builder = $db->table('cnb_preop');
        $query = $builder->select("count(other) as YES");
        $query = $builder->where('other ','YES');
        if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
        $query = $builder->get();
        $record66 = $query->getResult();
    
        foreach($record66 as $row) {
          $other = $row->YES;
        }
        $other6[] = array(
            'day'   => 'YES',
            'sell' => $other
        );
        $data['other6'] = ($other6); 

		
		return view('cnb/reports/morbid_v', $data);                
    }

    

    public function Anasthetic() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("COUNT(id) as count, cnb_done_by2 as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('cnb_done_by2');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$cnb_done_by2 = [];
		foreach($record as $row) {
			$cnb_done_by2[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['cnb_done_by2'] = ($cnb_done_by1);

		$data['total2'] = $cnb_done_by2;   

		
		return view('cnb/reports/anasthetic_v', $data);                
    }

     public function Supervision() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('cnb_patient_details');
		$query = $builder->select("COUNT(id) as count, supervision as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('supervision');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$supervision = [];
		foreach($record as $row) {
			$supervision[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['supervision'] = ($cnb_done_by1);

		$data['total2'] = $supervision;   

		
		return view('cnb/reports/supervision_v', $data);                
    }

   
    public function Sedation() {  
       $db = \Config\Database::connect();

       $from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

	    $builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, patient_status as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('patient_status');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$patient_status = [];
		foreach($record as $row) {
			$patient_status[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['patient_status'] = ($patient_status);

		$data['total'] = $patient_status;

			return view('cnb/reports/Sedation_v', $data);                
    }

    public function PatientPositon() {  
       $db = \Config\Database::connect();

       $from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

	    $builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, patient_position as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('patient_position');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$patient_position = [];
		foreach($record as $row) {
			$patient_position[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['patient_position'] = ($patient_position);

		$data['total'] = $patient_position;

			return view('cnb/reports/Patientpositon_v', $data);                
    }

    public function vertibral_intraspace() {  
       $db = \Config\Database::connect();

       $from_date = session()->get('from_date');
		$to_date = session()->get('to_date');
// epidural level
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, epedural_level as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('epedural_level');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$epedural_level = [];
		foreach($record as $row) {
			$epedural_level[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['epedural_level'] = ($epedural_level);

		$data['total'] = $epedural_level;
// epidural_name
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, 	epidural_level_name as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('epidural_level_name');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$epidural_level_name = [];
		foreach($record as $row) {
			$epidural_level_name[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['epidural_level_name'] = ($epidural_level_name);

		$data['total1'] = $epidural_level_name;

		

		return view('cnb/reports/Vertebral_v', $data);                
    }

    public function Approach() {  
       $db = \Config\Database::connect();

       $from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

	    $builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, approach as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('approach');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$approach = [];
		foreach($record as $row) {
			$approach[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['approach'] = ($approach);

		$data['total'] = $approach;

			return view('cnb/reports/approach_v', $data);                
    }

    public function no_attempts() {  
       $db = \Config\Database::connect();

        $from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

	    $builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, no_attempts as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('no_attempts');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$no_attempts = [];
		foreach($record as $row) {
			$no_attempts[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['no_attempts'] = ($no_attempts);

		$data['total'] = $no_attempts;

			return view('cnb/reports/noattempts_v', $data);                
    }

    public function Technique() {  
       $db = \Config\Database::connect();
       $from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

	    $builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, technique as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('technique');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$technique = [];
		foreach($record as $row) {
			$technique[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['technique'] = ($technique);

		$data['total'] = $technique;
// cath mark
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, 	cath_mark as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('cath_mark');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$cath_mark = [];
		foreach($record as $row) {
			$cath_mark[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['cath_mark'] = ($cath_mark);

		$data['total1'] = $cath_mark;

			return view('cnb/reports/technique', $data);                
    }

    public function Epidural_LA() {  
        $db = \Config\Database::connect();

        $from_date = session()->get('from_date');
		$to_date = session()->get('to_date');
// ropivaccine
        $builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, 	la_ropivacaine as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('la_ropivacaine');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$la_ropivacaine = [];
		foreach($record as $row) {
			$la_ropivacaine[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$data['products'] = ($products);
		$data['la_ropivacaine'] = ($la_ropivacaine);

		$data['total'] = $la_ropivacaine;
// Bupivaccine
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, la_bupivacaine as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('la_bupivacaine');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$la_bupivacaine = [];
		foreach($record as $row) {
			$la_bupivacaine[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['la_bupivacaine'] = ($la_bupivacaine);

		$data['total1'] = $la_bupivacaine;
// levobupivaccine
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, la_levobupivacaine as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('la_levobupivacaine');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$la_levobupivacaine = [];
		foreach($record as $row) {
			$la_levobupivacaine[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['la_levobupivacaine'] = ($la_levobupivacaine);

		$data['total2'] = $la_levobupivacaine;
// ligovaccine
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, la_lignocaine as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('la_lignocaine');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$la_lignocaine = [];
		foreach($record as $row) {
			$la_lignocaine[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['la_lignocaine'] = ($la_lignocaine);

		$data['total3'] = $la_lignocaine;

		return view('cnb/reports/epiduralLA_v', $data);                
    }

    public function CSA_LA() {  
        $db = \Config\Database::connect();

        $from_date = session()->get('from_date');
		$to_date = session()->get('to_date');
// lignocaine
        $builder = $db->table(' procedure_spinal');
		$query = $builder->select("COUNT(id) as count, 	la_lignocaine as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('la_lignocaine');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$la_lignocaine = [];
		foreach($record as $row) {
			$la_lignocaine[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$data['products'] = ($products);
		$data['la_lignocaine'] = ($la_lignocaine);

		$data['total'] = $la_lignocaine;
// la_bupivacaine
		$builder = $db->table(' procedure_spinal');
		$query = $builder->select("COUNT(id) as count, la_bupivacaine as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('la_bupivacaine');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$la_bupivacaine = [];
		foreach($record as $row) {
			$la_bupivacaine[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['la_bupivacaine'] = ($la_bupivacaine);

		$data['total1'] = $la_bupivacaine;
// la_ropivacaine
		$builder = $db->table(' procedure_spinal');
		$query = $builder->select("COUNT(id) as count, la_ropivacaine as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('la_ropivacaine');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$la_ropivacaine = [];
		foreach($record as $row) {
			$la_ropivacaine[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['la_ropivacaine'] = ($la_ropivacaine);

		$data['total2'] = $la_ropivacaine;
// la_prilocaine
		$builder = $db->table(' procedure_spinal');
		$query = $builder->select("COUNT(id) as count, la_prilocaine as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('la_prilocaine');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$la_prilocaine = [];
		foreach($record as $row) {
			$la_prilocaine[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['la_prilocaine'] = ($la_prilocaine);

		$data['total3'] = $la_prilocaine;
// la_2-chloroprocaine
    	$builder = $db->table(' procedure_spinal');
		$query = $builder->select("COUNT(id) as count, la_2-chloroprocaine as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('la_2-chloroprocaine');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$la_2_chloroprocaine = [];
		foreach($record as $row) {
			$la_2_chloroprocaine[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['la_2-chloroprocaine'] = ($la_2_chloroprocaine);

		$data['total4'] = $la_2_chloroprocaine;
// la_otheraine
		$builder = $db->table(' procedure_spinal');
		$query = $builder->select("COUNT(id) as count, la_otheraine as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('la_otheraine');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$la_otheraine = [];
		foreach($record as $row) {
			$la_otheraine[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['la_otheraine'] = ($la_otheraine);

		$data['total5'] = $la_otheraine;

		return view('cnb/reports/csaLA_v', $data);                
    }
// Epidural Component Single Dose
    public function epidural_singledose() {  
        $db = \Config\Database::connect();

        $from_date = session()->get('from_date');
		$to_date = session()->get('to_date');
// ropivaccine
        $builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, 	la_ropivacaine as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('la_ropivacaine');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$la_ropivacaine = [];
		foreach($record as $row) {
			$la_ropivacaine[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$data['products'] = ($products);
		$data['la_ropivacaine'] = ($la_ropivacaine);

		$data['total'] = $la_ropivacaine;
// Bupivaccine
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, la_bupivacaine as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('la_bupivacaine');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$la_bupivacaine = [];
		foreach($record as $row) {
			$la_bupivacaine[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['la_bupivacaine'] = ($la_bupivacaine);

		$data['total1'] = $la_bupivacaine;
// levobupivaccine
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, la_levobupivacaine as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('la_levobupivacaine');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$la_levobupivacaine = [];
		foreach($record as $row) {
			$la_levobupivacaine[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['la_levobupivacaine'] = ($la_levobupivacaine);

		$data['total2'] = $la_levobupivacaine;
// ligovaccine
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, la_lignocaine as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('la_lignocaine');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$la_lignocaine = [];
		foreach($record as $row) {
			$la_lignocaine[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['la_lignocaine'] = ($la_lignocaine);

		$data['total3'] = $la_lignocaine;
//opiod name
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, opioid_name as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('opioid_name');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$opioid_name = [];
		foreach($record as $row) {
			$opioid_name[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['opioid_name'] = ($opioid_name);

		$data['total4'] = $opioid_name;
// opioid dose
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, opioid_dose as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('opioid_dose');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$opioid_dose = [];
		foreach($record as $row) {
			$opioid_dose[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		$data['products'] = ($products);
		$data['opioid_dose'] = ($opioid_dose);

		$data['total5'] = $opioid_dose;
// Clonidne with Dose(mcgm)
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, clonidina_dose as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('clonidina_dose');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$clonidina_dose = [];
		foreach($record as $row) {
			$clonidina_dose[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['clonidina_dose'] = ($clonidina_dose);

		$data['total6'] = $clonidina_dose;
// Dexmeditomidine with Dose(mcgm)
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, dexmeditomidine_dose as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('dexmeditomidine_dose');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$dexmeditomidine_dose = [];
		foreach($record as $row) {
			$dexmeditomidine_dose[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		// $data['products'] = ($products);
		$data['dexmeditomidine_dose'] = ($dexmeditomidine_dose);

		$data['total7'] = $dexmeditomidine_dose;
// Dexamethasone with Dose(mg)
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, dexmeditomidine_dose as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('dexmeditomidine_dose');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$dexmeditomidine_dose = [];
		foreach($record as $row) {
			$dexmeditomidine_dose[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['dexmeditomidine_dose'] = ($dexmeditomidine_dose);

		$data['total7'] = $dexmeditomidine_dose;


		return view('cnb/reports/epidural_singledose_v', $data);                
    }
     public function median_sensory() {  
        $db = \Config\Database::connect();

        $from_date = session()->get('from_date');
		$to_date = session()->get('to_date');
// motor level
        $builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, motor_level as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('motor_level');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$motor_level = [];
		foreach($record as $row) {
			$motor_level[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['motor_level'] = ($motor_level);

		$data['total'] = $motor_level;
// onset of surgical_anaesthesia
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, onset as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('onset');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$onset = [];
		foreach($record as $row) {
			$onset[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['onset'] = ($onset);

		$data['total1'] = $onset;



        return view('cnb/reports/median_sensory_v', $data);                
    }

     public function motor_block() {  
        $db = \Config\Database::connect();

        $from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

        $builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count, ac_motor_block as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('ac_motor_block');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$ac_motor_block = [];
		foreach($record as $row) {
			$ac_motor_block[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}


		$data['products'] = ($products);
		$data['ac_motor_block'] = ($ac_motor_block);

		$data['total'] = $ac_motor_block;



        return view('cnb/reports/motor_block_v', $data);                
    }
// Rahul
    public function epidural_needle() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count");
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count,needle_type as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('needle_type');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		

		$data['products'] = ($products);
		
		$data['total'] = $total;  
		
		

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count,needle_size as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('needle_size');
		$query = $builder->get();
		$record1 = $query->getResult();
		$total = 0;
		$products1 = [];
		foreach($record1 as $row) {
			$products1[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			// $total += floatval($row->count);
		}

		

		$data['products1'] = ($products1);
		

		return view('cnb/reports/epidural_needle_v', $data);                
    }

	public function spinal_needle() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("COUNT(id) as count,needle_type as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('needle_type');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		

		$data['products'] = ($products);
		
		$data['total'] = $total;  
		
		

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("COUNT(id) as count,needle_size as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('needle_size');
		$query = $builder->get();
		$record1 = $query->getResult();
		$total = 0;
		$products1 = [];
		foreach($record1 as $row) {
			$products1[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			// $total += floatval($row->count);
		}

		

		$data['products1'] = ($products1);
		

		return view('cnb/reports/spinal_needle_v', $data);                
    }


	
	public function csa_needle() {  
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record = $query->getResult();

		foreach($record as $row) {
			$total += floatval($row->count);
		}

		$data['total_n'] = $total; 

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,needle_type as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('needle_type');
		$query = $builder->get();
		$record = $query->getResult();
		$total = 0;
		$products = [];
		foreach($record as $row) {
			$products[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			$total += floatval($row->count);
		}

		

		$data['products'] = ($products);
		
		$data['total'] = $total;  
		
		

		$builder = $db->table('procedure_csa');
		$query = $builder->select("COUNT(id) as count,needle_size as s");
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->groupBy('needle_size');
		$query = $builder->get();
		$record1 = $query->getResult();
		$total = 0;
		$products1 = [];
		foreach($record1 as $row) {
			$products1[] = array(
			'day'   => $row->s,
			'sell' => floatval($row->count)
			);
			// $total += floatval($row->count);
		}

		

		$data['products1'] = ($products1);
		

		return view('cnb/reports/csa_needle_v', $data);                
    }

    public function epidural_adjuvant() {
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');
		$total11 = 0;
		$total12 = 0;
		$all_total1 = 0;
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(opioid_dose) as NO");
		$query = $builder->where('opioid_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record3 = $query->getResult();
		foreach($record3 as $row) {
			$opioid_dose3 = $row->NO;
			$total11 += floatval($row->NO);
			$all_total1 += floatval($row->NO);
		}
		$opioide[] = array(
			    'day'   => 'NO',
			    'sell' => $opioid_dose3,
		);

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(opioid_dose) as YES");
		$query = $builder->where('opioid_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record2 = $query->getResult();

		foreach($record2 as $row) {
			$opioid_dose = $row->YES;
			$total12 += floatval($row->YES);
			$all_total1 += floatval($row->YES);
		}
		$opioide[] = array(
			    'day'   => 'YES',
			    'sell' => $opioid_dose
		);

		$o_number1 = (($total11/$all_total1)*100);
		$o_number2 = (($total12/$all_total1)*100);

		$data['o_perc1'] = number_format((float)$o_number1, 2, '.', '')."%";
		$data['o_perc2'] = number_format((float)$o_number2, 2, '.', '')."%";
		$data['total11'] = $total11;
		$data['total12'] = $total12;

		$data['opioide'] = ($opioide); 


		//  ---------------------------OPIOIDE ADJUVANT----------------------
		$total21 = 0;
		$total22 = 0;
		$all_total2 = 0;
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(clonidina_dose) as NO");
		$query = $builder->where('clonidina_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record4 = $query->getResult();
		foreach($record4 as $row) {
			$clonidina_dose = $row->NO;
			$total21 += floatval($row->NO);
			$all_total2 += floatval($row->NO);
		}
		$clonidina[] = array(
			    'day'   => 'NO',
			    'sell' => $clonidina_dose
		);

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(clonidina_dose) as YES");
		$query = $builder->where('clonidina_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record5 = $query->getResult();

		foreach($record5 as $row) {
			$clonidina_dose = $row->YES;
			$total22 += floatval($row->YES);
			$all_total2 += floatval($row->YES);
		}
		$clonidina[] = array(
			    'day'   => 'YES',
			    'sell' => $clonidina_dose
		);


		$c_number1 = (($total21/$all_total2)*100);
		$c_number2 = (($total22/$all_total2)*100);

		$data['c_perc1'] = number_format((float)$c_number1, 2, '.', '')."%";
		$data['c_perc2'] = number_format((float)$c_number2, 2, '.', '')."%";
		$data['total21'] = $total21;
		$data['total22'] = $total22;
		$data['clonidina'] = ($clonidina); 
// print_r($data);die();
		//  ---------------------------dexmeditomidine ADJUVANT----------------------
		$total31 = 0;
		$total32 = 0;
		$all_total3 = 0;
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(dexmeditomidine_dose) as NO");
		$query = $builder->where('dexmeditomidine_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record6 = $query->getResult();
		foreach($record6 as $row) {
			$dexmeditomidine_dose = $row->NO;
			$total31 += floatval($row->NO);
			$all_total3 += floatval($row->NO);
		}
		$dexmeditomidine[] = array(
			    'day'   => 'NO',
			    'sell' => $dexmeditomidine_dose
		);

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(dexmeditomidine_dose) as YES");
		$query = $builder->where('dexmeditomidine_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record7 = $query->getResult();

		foreach($record7 as $row) {
			$dexmeditomidine_dose = $row->YES;
			$total32 += floatval($row->YES);
			$all_total3 += floatval($row->YES);
		}
		$dexmeditomidine[] = array(
			    'day'   => 'YES',
			    'sell' => $dexmeditomidine_dose
		);

		$de_number1 = (($total31/$all_total3)*100);
		$de_number2 = (($total32/$all_total3)*100);

		$data['de_perc1'] = number_format((float)$de_number1, 2, '.', '')."%";
		$data['de_perc2'] = number_format((float)$de_number2, 2, '.', '')."%";
		$data['total31'] = $total31;
		$data['total32'] = $total32;
		$data['dexmeditomidine'] = ($dexmeditomidine); 


		//  ---------------------------dexamephasone ADJUVANT----------------------

		$total41 = 0;
		$total42 = 0;
		$all_total4 = 0;
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(dexamephasone_dose) as NO");
		$query = $builder->where('dexamephasone_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record8 = $query->getResult();
		foreach($record8 as $row) {
			$dexamephasone_dose = $row->NO;
			$total41 += floatval($row->NO);
			$all_total4 += floatval($row->NO);
		}
		$dexamephasone[] = array(
			    'day'   => 'NO',
			    'sell' => $dexamephasone_dose
		);

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(dexamephasone_dose) as YES");
		$query = $builder->where('dexamephasone_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record9 = $query->getResult();

		foreach($record9 as $row) {
			$dexamephasone_dose = $row->YES;
			$total42 += floatval($row->YES);
			$all_total4 += floatval($row->YES);
		}
		$dexamephasone[] = array(
			    'day'   => 'YES',
			    'sell' => $dexamephasone_dose
		);

		$da_number1 = (($total41/$all_total4)*100);
		$da_number2 = (($total42/$all_total4)*100);

		$data['da_perc1'] = number_format((float)$da_number1, 2, '.', '')."%";
		$data['da_perc2'] = number_format((float)$da_number2, 2, '.', '')."%";
		$data['total41'] = $total41;
		$data['total42'] = $total42;
		$data['dexamephasone'] = ($dexamephasone);


		//  ---------------------------tramadol ADJUVANT----------------------

		$total51 = 0;
		$total52 = 0;
		$all_total5 = 0;
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(tramadol_dose) as NO");
		$query = $builder->where('tramadol_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record10 = $query->getResult();
		foreach($record10 as $row) {
			$tramadol_dose = $row->NO;
			$total51 += floatval($row->NO);
			$all_total5 += floatval($row->NO);
		}
		$tramadol[] = array(
			    'day'   => 'NO',
			    'sell' => $tramadol_dose
		);

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(tramadol_dose) as YES");
		$query = $builder->where('tramadol_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record11 = $query->getResult();

		foreach($record11 as $row) {
			$tramadol_dose = $row->YES;
			$total52 += floatval($row->YES);
			$all_total5 += floatval($row->YES);
		}
		$tramadol[] = array(
			    'day'   => 'YES',
			    'sell' => $tramadol_dose
		);

		$t_number1 = (($total51/$all_total5)*100);
		$t_number2 = (($total52/$all_total5)*100);

		$data['t_perc1'] = number_format((float)$t_number1, 2, '.', '')."%";
		$data['t_perc2'] = number_format((float)$t_number2, 2, '.', '')."%";
		$data['total51'] = $total51;
		$data['total52'] = $total52;
		$data['tramadol'] = ($tramadol);


		//  ---------------------------kepamine ADJUVANT----------------------

		$total61 = 0;
		$total62 = 0;
		$all_total6 = 0;
		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(kepamine_dose) as NO");
		$query = $builder->where('kepamine_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record12 = $query->getResult();
		foreach($record12 as $row) {
			$kepamine_dose = $row->NO;
			$total61 += floatval($row->NO);
			$all_total6 += floatval($row->NO);
		}
		$kepamine[] = array(
			    'day'   => 'NO',
			    'sell' => $kepamine_dose
		);

		$builder = $db->table('procedure_epidural');
		$query = $builder->select("count(kepamine_dose) as YES");
		$query = $builder->where('kepamine_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record13 = $query->getResult();

		foreach($record13 as $row) {
			$kepamine_dose = $row->YES;
			$total62 += floatval($row->YES);
			$all_total6 += floatval($row->YES);
		}
		$kepamine[] = array(
			    'day'   => 'YES',
			    'sell' => $kepamine_dose
		);
		$k_number1 = (($total61/$all_total6)*100);
		$k_number2 = (($total62/$all_total6)*100);

		$data['k_perc1'] = number_format((float)$k_number1, 2, '.', '')."%";
		$data['k_perc2'] = number_format((float)$k_number2, 2, '.', '')."%";
		$data['total61'] = $total61;
		$data['total62'] = $total62;

		$data['kepamine'] = ($kepamine);


			//  ---------------------------midazolam ADJUVANT----------------------

			$total71 = 0;
			$total72 = 0;
			$all_total7 = 0;
			$builder = $db->table('procedure_epidural');
			$query = $builder->select("count(midazolam_dose) as NO");
			$query = $builder->where('midazolam_dose ','');
			if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
			$query = $builder->get();
			$record14 = $query->getResult();
			foreach($record14 as $row) {
				$midazolam_dose = $row->NO;
				$total71 += floatval($row->NO);
			$all_total7 += floatval($row->NO);
			}
			$midazolam[] = array(
					'day'   => 'NO',
					'sell' => $midazolam_dose
			);
	
			$builder = $db->table('procedure_epidural');
			$query = $builder->select("count(midazolam_dose) as YES");
			$query = $builder->where('midazolam_dose !=','');
			if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
			$query = $builder->get();
			$record15 = $query->getResult();
	
			foreach($record15 as $row) {
				$midazolam_dose = $row->YES;
				$total72 += floatval($row->YES);
			$all_total7 += floatval($row->YES);
				
			}
			$midazolam[] = array(
					'day'   => 'YES',
					'sell' => $midazolam_dose
			);

			$m_number1 = (($total71/$all_total7)*100);
			$m_number2 = (($total72/$all_total7)*100);

			$data['m_perc1'] = number_format((float)$m_number1, 2, '.', '')."%";
			$data['m_perc2'] = number_format((float)$m_number2, 2, '.', '')."%";
			$data['total71'] = $total71;
			$data['total72'] = $total72;

			$data['midazolam'] = ($midazolam);

				//  ---------------------------other ADJUVANT----------------------

				$total81 = 0;
				$total82 = 0;
				$all_total8 = 0;
				$builder = $db->table('procedure_epidural');
				$query = $builder->select("count(other7) as NO");
				$query = $builder->where('other7 ','NO');
				if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
				$query = $builder->get();
				$record16 = $query->getResult();
				foreach($record16 as $row) {
					$other7 = $row->NO;
					$total81 += floatval($row->NO);
			       $all_total8 += floatval($row->NO);
				}
				$other[] = array(
						'day'   => 'NO',
						'sell' => $other7
				);
		
				$builder = $db->table('procedure_epidural');
				$query = $builder->select("count(other7) as YES");
				$query = $builder->where('other7 ','YES');
				if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
				$query = $builder->get();
				$record17 = $query->getResult();
		
				foreach($record17 as $row) {
					$other7 = $row->YES;
					$total82 += floatval($row->YES);
			$all_total8 += floatval($row->YES);
				}
				$other[] = array(
						'day'   => 'YES',
						'sell' => $other7
				);

				$oth_number1 = (($total81/$all_total8)*100);
		       $oth_number2 = (($total82/$all_total8)*100);

				$data['oth_perc1'] = number_format((float)$oth_number1, 2, '.', '')."%";
				$data['oth_perc2'] = number_format((float)$oth_number2, 2, '.', '')."%";
				$data['total81'] = $total81;
				$data['total82'] = $total82;

				$data['other'] = ($other);

		return view('cnb/reports/epidural_adjuvant_v', $data);                
    }


	public function spinal_adjuvant() {
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');

		$total11 = 0;
    $total12 = 0;
    $all_total1 = 0;
		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(opioid_dose) as NO");
		$query = $builder->where('opioid_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record3 = $query->getResult();
		foreach($record3 as $row) {
			$opioid_dose3 = $row->NO;
			$total11 += floatval($row->NO);
			$all_total1 += floatval($row->NO);
		}
		$opioide[] = array(
			    'day'   => 'NO',
			    'sell' => $opioid_dose3
		);

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(opioid_dose) as YES");
		$query = $builder->where('opioid_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record2 = $query->getResult();

		foreach($record2 as $row) {
			$opioid_dose = $row->YES;
			$total12 += floatval($row->YES);
        $all_total1 += floatval($row->YES);
		}
		$opioide[] = array(
			    'day'   => 'YES',
			    'sell' => $opioid_dose
		);

		$o_number1 = (($total11/$all_total1)*100);
    $o_number2 = (($total12/$all_total1)*100);

    $data['o_perc1'] = number_format((float)$o_number1, 2, '.', '')."%";
    $data['o_perc2'] = number_format((float)$o_number2, 2, '.', '')."%";
    $data['total11'] = $total11;
    $data['total12'] = $total12;


		$data['opioide'] = ($opioide); 


		//  ---------------------------OPIOIDE ADJUVANT----------------------
		$total21 = 0;
		$total22 = 0;
		$all_total2 = 0;

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(clonidina_dose) as NO");
		$query = $builder->where('clonidina_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record4 = $query->getResult();
		foreach($record4 as $row) {
			$clonidina_dose = $row->NO;
			$total21 += floatval($row->NO);
			$all_total2 += floatval($row->NO);			
		}
		$clonidina[] = array(
			    'day'   => 'NO',
			    'sell' => $clonidina_dose
		);

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(clonidina_dose) as YES");
		$query = $builder->where('clonidina_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record5 = $query->getResult();

		foreach($record5 as $row) {
			$clonidina_dose = $row->YES;
			$total22 += floatval($row->YES);
			$all_total2 += floatval($row->YES);
		}
		$clonidina[] = array(
			    'day'   => 'YES',
			    'sell' => $clonidina_dose
		);

		$c_number1 = (($total21/$all_total2)*100);
		$c_number2 = (($total22/$all_total2)*100);
	
		$data['c_perc1'] = number_format((float)$c_number1, 2, '.', '')."%";
		$data['c_perc2'] = number_format((float)$c_number2, 2, '.', '')."%";
		$data['total21'] = $total21;
		$data['total22'] = $total22;
		$data['clonidina'] = ($clonidina); 

		//  ---------------------------dexmeditomidine ADJUVANT----------------------
		$total31 = 0;
		$total32 = 0;
		$all_total3 = 0;
		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(dexmeditomidine_dose) as NO");
		$query = $builder->where('dexmeditomidine_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record6 = $query->getResult();
		foreach($record6 as $row) {
			$dexmeditomidine_dose = $row->NO;
			$total31 += floatval($row->NO);
        $all_total3 += floatval($row->NO);
		}
		$dexmeditomidine[] = array(
			    'day'   => 'NO',
			    'sell' => $dexmeditomidine_dose
		);

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(dexmeditomidine_dose) as YES");
		$query = $builder->where('dexmeditomidine_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record7 = $query->getResult();

		foreach($record7 as $row) {
			$dexmeditomidine_dose = $row->YES;
			$total32 += floatval($row->YES);
        $all_total3 += floatval($row->YES);
		}
		$dexmeditomidine[] = array(
			    'day'   => 'YES',
			    'sell' => $dexmeditomidine_dose
		);

		$de_number1 = (($total31/$all_total3)*100);
		$de_number2 = (($total32/$all_total3)*100);
	
		$data['de_perc1'] = number_format((float)$de_number1, 2, '.', '')."%";
		$data['de_perc2'] = number_format((float)$de_number2, 2, '.', '')."%";
		$data['total31'] = $total31;
		$data['total32'] = $total32;
		$data['dexmeditomidine'] = ($dexmeditomidine); 


		//  ---------------------------dexamephasone ADJUVANT----------------------

		$total41 = 0;
    $total42 = 0;
    $all_total4 = 0;
		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(dexamephasone_dose) as NO");
		$query = $builder->where('dexamephasone_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record8 = $query->getResult();
		foreach($record8 as $row) {
			$dexamephasone_dose = $row->NO;
			$total41 += floatval($row->NO);
        $all_total4 += floatval($row->NO);
		}
		$dexamephasone[] = array(
			    'day'   => 'NO',
			    'sell' => $dexamephasone_dose
		);

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(dexamephasone_dose) as YES");
		$query = $builder->where('dexamephasone_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record9 = $query->getResult();

		foreach($record9 as $row) {
			$dexamephasone_dose = $row->YES;
			$total42 += floatval($row->YES);
        $all_total4 += floatval($row->YES);
		}
		$dexamephasone[] = array(
			    'day'   => 'YES',
			    'sell' => $dexamephasone_dose
		);

		$da_number1 = (($total41/$all_total4)*100);
		$da_number2 = (($total42/$all_total4)*100);
	
		$data['da_perc1'] = number_format((float)$da_number1, 2, '.', '')."%";
		$data['da_perc2'] = number_format((float)$da_number2, 2, '.', '')."%";
		$data['total41'] = $total41;
		$data['total42'] = $total42;
		$data['dexamephasone'] = ($dexamephasone);


		//  ---------------------------tramadol ADJUVANT----------------------

		$total51 = 0;
		$total52 = 0;
		$all_total5 = 0;
		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(tramadol_dose) as NO");
		$query = $builder->where('tramadol_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record10 = $query->getResult();
		foreach($record10 as $row) {
			$tramadol_dose = $row->NO;
			$total51 += floatval($row->NO);
        $all_total5 += floatval($row->NO);
		}
		$tramadol[] = array(
			    'day'   => 'NO',
			    'sell' => $tramadol_dose
		);

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(tramadol_dose) as YES");
		$query = $builder->where('tramadol_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record11 = $query->getResult();

		foreach($record11 as $row) {
			$tramadol_dose = $row->YES;
			$total52 += floatval($row->YES);
        $all_total5 += floatval($row->YES);
		}
		$tramadol[] = array(
			    'day'   => 'YES',
			    'sell' => $tramadol_dose
		);

		$t_number1 = (($total51/$all_total5)*100);
		$t_number2 = (($total52/$all_total5)*100);
	
		$data['t_perc1'] = number_format((float)$t_number1, 2, '.', '')."%";
		$data['t_perc2'] = number_format((float)$t_number2, 2, '.', '')."%";
		$data['total51'] = $total51;
		$data['total52'] = $total52;
		$data['tramadol'] = ($tramadol);


		//  ---------------------------kepamine ADJUVANT----------------------

		$total61 = 0;
		$total62 = 0;
		$all_total6 = 0;
		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(ketamine_dose) as NO");
		$query = $builder->where('ketamine_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record12 = $query->getResult();
		foreach($record12 as $row) {
			$ketamine_dose = $row->NO;
			$total61 += floatval($row->NO);
			$all_total6 += floatval($row->NO);
		}
		$ketamine[] = array(
			    'day'   => 'NO',
			    'sell' => $ketamine_dose
		);

		$builder = $db->table('procedure_spinal');
		$query = $builder->select("count(ketamine_dose) as YES");
		$query = $builder->where('ketamine_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record13 = $query->getResult();

		foreach($record13 as $row) {
			$ketamine_dose = $row->YES;
			$total62 += floatval($row->YES);
			$all_total6 += floatval($row->YES);
		}
		$ketamine[] = array(
			    'day'   => 'YES',
			    'sell' => $ketamine_dose
		);

		$k_number1 = (($total61/$all_total6)*100);
		$k_number2 = (($total62/$all_total6)*100);
	
		$data['k_perc1'] = number_format((float)$k_number1, 2, '.', '')."%";
		$data['k_perc2'] = number_format((float)$k_number2, 2, '.', '')."%";
		$data['total61'] = $total61;
		$data['total62'] = $total62;
		$data['ketamine'] = ($ketamine);


			//  ---------------------------midazolam ADJUVANT----------------------


			$total71 = 0;
			$total72 = 0;
			$all_total7 = 0;
			$builder = $db->table('procedure_spinal');
			$query = $builder->select("count(midazolam_dose) as NO");
			$query = $builder->where('midazolam_dose ','');
			if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
			$query = $builder->get();
			$record14 = $query->getResult();
			foreach($record14 as $row) {
				$midazolam_dose = $row->NO;
				$total71 += floatval($row->NO);
				$all_total7 += floatval($row->NO);
			}
			$midazolam[] = array(
					'day'   => 'NO',
					'sell' => $midazolam_dose
			);
	
			$builder = $db->table('procedure_spinal');
			$query = $builder->select("count(midazolam_dose) as YES");
			$query = $builder->where('midazolam_dose !=','');
			if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
			$query = $builder->get();
			$record15 = $query->getResult();
	
			foreach($record15 as $row) {
				$midazolam_dose = $row->YES;
				$total72 += floatval($row->YES);
				$all_total7 += floatval($row->YES);
			}
			$midazolam[] = array(
					'day'   => 'YES',
					'sell' => $midazolam_dose
			);

			$m_number1 = (($total71/$all_total7)*100);
        $m_number2 = (($total72/$all_total7)*100);

        $data['m_perc1'] = number_format((float)$m_number1, 2, '.', '')."%";
        $data['m_perc2'] = number_format((float)$m_number2, 2, '.', '')."%";
        $data['total71'] = $total71;
        $data['total72'] = $total72;
			$data['midazolam'] = ($midazolam);

				//  ---------------------------midazolam ADJUVANT----------------------

				$total91 = 0;
				$total92 = 0;
				$all_total9 = 0;
				$builder = $db->table('procedure_spinal');
				$query = $builder->select("count(adrenaline_dose) as NO");
				$query = $builder->where('adrenaline_dose ','');
				if($from_date && $to_date){
		  $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
		  $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
		}
				$query = $builder->get();
				$record18 = $query->getResult();
				foreach($record18 as $row) {
					$adrenaline_dose = $row->NO;
					$total91 += floatval($row->NO);
					$all_total9 += floatval($row->NO);
				}
				$adrenaline[] = array(
						'day'   => 'NO',
						'sell' => $adrenaline_dose
				);
		
				$builder = $db->table('procedure_spinal');
				$query = $builder->select("count(adrenaline_dose) as YES");
				$query = $builder->where('adrenaline_dose !=','');
				if($from_date && $to_date){
		  $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
		  $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
		}
				$query = $builder->get();
				$record19 = $query->getResult();
		
				foreach($record19 as $row) {
					$adrenaline_dose = $row->YES;
					$total92 += floatval($row->YES);
						$all_total9 += floatval($row->YES);
				}
				$adrenaline[] = array(
						'day'   => 'YES',
						'sell' => $adrenaline_dose
				);
	
				$a_number1 = (($total91/$all_total9)*100);
				$a_number2 = (($total92/$all_total9)*100);
		 
				 $data['a_perc1'] = number_format((float)$a_number1, 2, '.', '')."%";
				 $data['a_perc2'] = number_format((float)$a_number2, 2, '.', '')."%";
				 $data['total91'] = $total91;
				 $data['total92'] = $total92;
				$data['adrenaline'] = ($adrenaline);

				//  ---------------------------other ADJUVANT----------------------

				$total81 = 0;
				$total82 = 0;
				$all_total8 = 0;
            $builder = $db->table('procedure_spinal');
            $query = $builder->select("count(other7) as NO");
            $query = $builder->where('other7 ','NO');
            if($from_date && $to_date){
      $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
      $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
    }
            $query = $builder->get();
            $record16 = $query->getResult();
            foreach($record16 as $row) {
                $other7 = $row->NO;
                $total81 += floatval($row->NO);
                $all_total8 += floatval($row->NO);
            }
            $other[] = array(
                    'day'   => 'NO',
                    'sell' => $other7
            );
    
            $builder = $db->table('procedure_spinal');
            $query = $builder->select("count(other7) as YES");
            $query = $builder->where('other7 ','YES');
            $query = $builder->get();
            $record17 = $query->getResult();
    
            foreach($record17 as $row) {
                $other7 = $row->YES;
                $total82 += floatval($row->YES);
					$all_total8 += floatval($row->YES);
            }
            $other[] = array(
                    'day'   => 'YES',
                    'sell' => $other7
            );
            $oth_number1 = (($total81/$all_total8)*100);
            $oth_number2 = (($total82/$all_total8)*100);
     
             $data['oth_perc1'] = number_format((float)$oth_number1, 2, '.', '')."%";
             $data['oth_perc2'] = number_format((float)$oth_number2, 2, '.', '')."%";
             $data['total81'] = $total81;
             $data['total82'] = $total82;
            $data['other'] = ($other);

		return view('cnb/reports/spinal_adjuvant_v', $data);                
    }


	public function csa_adjuvant() {
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');
		
		$total11 = 0;
		$total12 = 0;
		$all_total1 = 0;
		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(opioid_aj) as NO");
		$query = $builder->where('opioid_aj ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record3 = $query->getResult();
		foreach($record3 as $row) {
			$opioid_dose3 = $row->NO;
			$total11 += floatval($row->NO);
			$all_total1 += floatval($row->NO);
		}
		$opioide[] = array(
			    'day'   => 'NO',
			    'sell' => $opioid_dose3
		);

		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(opioid_aj) as YES");
		$query = $builder->where('opioid_aj !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record2 = $query->getResult();

		foreach($record2 as $row) {
			$opioid_dose = $row->YES;
			$total12 += floatval($row->YES);
    $all_total1 += floatval($row->YES);
		}
		$opioide[] = array(
			    'day'   => 'YES',
			    'sell' => $opioid_dose
		);
		$o_number1 = (($total11/$all_total1)*100);
		$o_number2 = (($total12/$all_total1)*100);
		
		$data['o_perc1'] = number_format((float)$o_number1, 2, '.', '')."%";
		$data['o_perc2'] = number_format((float)$o_number2, 2, '.', '')."%";
		$data['total11'] = $total11;
		$data['total12'] = $total12;
		
		$data['opioide'] = ($opioide); 


		//  ---------------------------OPIOIDE ADJUVANT----------------------
		$total21 = 0;
		$total22 = 0;
		$all_total2 = 0;

		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(clonidne_aj) as NO");
		$query = $builder->where('clonidne_aj ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record4 = $query->getResult();
		foreach($record4 as $row) {
			$clonidina_dose = $row->NO;
			$total21 += floatval($row->NO);
        $all_total2 += floatval($row->NO);		
		}
		$clonidina[] = array(
			    'day'   => 'NO',
			    'sell' => $clonidina_dose
		);

		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(clonidne_aj) as YES");
		$query = $builder->where('clonidne_aj !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record5 = $query->getResult();

		foreach($record5 as $row) {
			$clonidina_dose = $row->YES;
			$total22 += floatval($row->YES);
        $all_total2 += floatval($row->YES);
		}
		$clonidina[] = array(
			    'day'   => 'YES',
			    'sell' => $clonidina_dose
		);

		$c_number1 = (($total21/$all_total2)*100);
		$c_number2 = (($total22/$all_total2)*100);
	
		$data['c_perc1'] = number_format((float)$c_number1, 2, '.', '')."%";
		$data['c_perc2'] = number_format((float)$c_number2, 2, '.', '')."%";
		$data['total21'] = $total21;
		$data['total22'] = $total22;
		$data['clonidina'] = ($clonidina); 

		//  ---------------------------dexmeditomidine ADJUVANT----------------------
		$total31 = 0;
		$total32 = 0;
		$all_total3 = 0;
		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(dexmeditomidine_aj) as NO");
		$query = $builder->where('dexmeditomidine_aj ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record6 = $query->getResult();
		foreach($record6 as $row) {
			$dexmeditomidine_dose = $row->NO;
			$total31 += floatval($row->NO);
			$all_total3 += floatval($row->NO);
		}
		$dexmeditomidine[] = array(
			    'day'   => 'NO',
			    'sell' => $dexmeditomidine_dose
		);

		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(dexmeditomidine_aj) as YES");
		$query = $builder->where('dexmeditomidine_aj !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record7 = $query->getResult();

		foreach($record7 as $row) {
			$dexmeditomidine_dose = $row->YES;
			$total32 += floatval($row->YES);
    $all_total3 += floatval($row->YES);
		}
		$dexmeditomidine[] = array(
			    'day'   => 'YES',
			    'sell' => $dexmeditomidine_dose
		);

		$de_number1 = (($total31/$all_total3)*100);
		$de_number2 = (($total32/$all_total3)*100);
	
		$data['de_perc1'] = number_format((float)$de_number1, 2, '.', '')."%";
		$data['de_perc2'] = number_format((float)$de_number2, 2, '.', '')."%";
		$data['total31'] = $total31;
		$data['total32'] = $total32;
		$data['dexmeditomidine'] = ($dexmeditomidine); 


		//  ---------------------------dexamephasone ADJUVANT----------------------

		$total41 = 0;
		$total42 = 0;
		$all_total4 = 0;
		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(dexamethasone_aj) as NO");
		$query = $builder->where('dexamethasone_aj ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record8 = $query->getResult();
		foreach($record8 as $row) {
			$dexamephasone_dose = $row->NO;
			$total41 += floatval($row->NO);
    $all_total4 += floatval($row->NO);
		}
		$dexamephasone[] = array(
			    'day'   => 'NO',
			    'sell' => $dexamephasone_dose
		);

		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(dexamethasone_aj) as YES");
		$query = $builder->where('dexamethasone_aj !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record9 = $query->getResult();

		foreach($record9 as $row) {
			$dexamephasone_dose = $row->YES;
			$total42 += floatval($row->YES);
			$all_total4 += floatval($row->YES);
		}
		$dexamephasone[] = array(
			    'day'   => 'YES',
			    'sell' => $dexamephasone_dose
		);

		$da_number1 = (($total41/$all_total4)*100);
    $da_number2 = (($total42/$all_total4)*100);

    $data['da_perc1'] = number_format((float)$da_number1, 2, '.', '')."%";
    $data['da_perc2'] = number_format((float)$da_number2, 2, '.', '')."%";
    $data['total41'] = $total41;
    $data['total42'] = $total42;
		$data['dexamephasone'] = ($dexamephasone);


		//  ---------------------------tramadol ADJUVANT----------------------

		$total51 = 0;
		$total52 = 0;
		$all_total5 = 0;
		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(tramadol_aj) as NO");
		$query = $builder->where('tramadol_aj ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record10 = $query->getResult();
		foreach($record10 as $row) {
			$tramadol_dose = $row->NO;
			$total51 += floatval($row->NO);
    $all_total5 += floatval($row->NO);
		}
		$tramadol[] = array(
			    'day'   => 'NO',
			    'sell' => $tramadol_dose
		);

		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(tramadol_aj) as YES");
		$query = $builder->where('tramadol_aj !=','');if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record11 = $query->getResult();

		foreach($record11 as $row) {
			$tramadol_dose = $row->YES;
			$total52 += floatval($row->YES);
			$all_total5 += floatval($row->YES);
		}
		$tramadol[] = array(
			    'day'   => 'YES',
			    'sell' => $tramadol_dose
		);
		$t_number1 = (($total51/$all_total5)*100);
    $t_number2 = (($total52/$all_total5)*100);

    $data['t_perc1'] = number_format((float)$t_number1, 2, '.', '')."%";
    $data['t_perc2'] = number_format((float)$t_number2, 2, '.', '')."%";
    $data['total51'] = $total51;
    $data['total52'] = $total52;
		$data['tramadol'] = ($tramadol);


		//  ---------------------------kepamine ADJUVANT----------------------

		$total61 = 0;
		$total62 = 0;
		$all_total6 = 0;
		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(ketamine_aj) as NO");
		$query = $builder->where('ketamine_aj ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record12 = $query->getResult();
		foreach($record12 as $row) {
			$ketamine_dose = $row->NO;
			$total61 += floatval($row->NO);
			$all_total6 += floatval($row->NO);
		}
		$ketamine[] = array(
			    'day'   => 'NO',
			    'sell' => $ketamine_dose
		);

		$builder = $db->table('procedure_csa');
		$query = $builder->select("count(ketamine_aj) as YES");
		$query = $builder->where('ketamine_aj !=','');if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record13 = $query->getResult();

		foreach($record13 as $row) {
			$ketamine_dose = $row->YES;
			$total62 += floatval($row->YES);
        $all_total6 += floatval($row->YES);
		}
		$ketamine[] = array(
			    'day'   => 'YES',
			    'sell' => $ketamine_dose
		);

		$k_number1 = (($total61/$all_total6)*100);
		$k_number2 = (($total62/$all_total6)*100);
	
		$data['k_perc1'] = number_format((float)$k_number1, 2, '.', '')."%";
		$data['k_perc2'] = number_format((float)$k_number2, 2, '.', '')."%";
		$data['total61'] = $total61;
		$data['total62'] = $total62;
		$data['ketamine'] = ($ketamine);


			//  ---------------------------midazolam ADJUVANT----------------------

			$total71 = 0;
			$total72 = 0;
			$all_total7 = 0;
			$builder = $db->table('procedure_csa');
			$query = $builder->select("count(midazolam_aj) as NO");
			$query = $builder->where('midazolam_aj ','');
			if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
			$query = $builder->get();
			$record14 = $query->getResult();
			foreach($record14 as $row) {
				$midazolam_dose = $row->NO;
				$total71 += floatval($row->NO);
            $all_total7 += floatval($row->NO);
			}
			$midazolam[] = array(
					'day'   => 'NO',
					'sell' => $midazolam_dose
			);
	
			$builder = $db->table('procedure_csa');
			$query = $builder->select("count(midazolam_aj) as YES");
			$query = $builder->where('midazolam_aj !=','');
			if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
			$query = $builder->get();
			$record15 = $query->getResult();
	
			foreach($record15 as $row) {
				$midazolam_dose = $row->YES;
				$total72 += floatval($row->YES);
            $all_total7 += floatval($row->YES);
			}
			$midazolam[] = array(
					'day'   => 'YES',
					'sell' => $midazolam_dose
			);
			$m_number1 = (($total71/$all_total7)*100);
			$m_number2 = (($total72/$all_total7)*100);
		
			$data['m_perc1'] = number_format((float)$m_number1, 2, '.', '')."%";
			$data['m_perc2'] = number_format((float)$m_number2, 2, '.', '')."%";
			$data['total71'] = $total71;
			$data['total72'] = $total72;
			$data['midazolam'] = ($midazolam);

				//  ---------------------------midazolam ADJUVANT----------------------

				$total91 = 0;
				$total92 = 0;
				$all_total9 = 0;
				$builder = $db->table('procedure_csa');
				$query = $builder->select("count(adrenaline_aj) as NO");
				$query = $builder->where('adrenaline_aj ','');
				if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
				$query = $builder->get();
				$record18 = $query->getResult();
				foreach($record18 as $row) {
					$adrenaline_dose = $row->NO;
					$total91 += floatval($row->NO);
                $all_total9 += floatval($row->NO);
				}
				$adrenaline[] = array(
						'day'   => 'NO',
						'sell' => $adrenaline_dose
				);
		
				$builder = $db->table('procedure_csa');
				$query = $builder->select("count(adrenaline_aj) as YES");
				$query = $builder->where('adrenaline_aj !=','');
				if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
				$query = $builder->get();
				$record19 = $query->getResult();
		
				foreach($record19 as $row) {
					$adrenaline_dose = $row->YES;
					$total92 += floatval($row->YES);
    				$all_total9 += floatval($row->YES);
				}
				$adrenaline[] = array(
						'day'   => 'YES',
						'sell' => $adrenaline_dose
				);
				$a_number1 = (($total91/$all_total9)*100);
				$a_number2 = (($total92/$all_total9)*100);
		 
				 $data['a_perc1'] = number_format((float)$a_number1, 2, '.', '')."%";
				 $data['a_perc2'] = number_format((float)$a_number2, 2, '.', '')."%";
				 $data['total91'] = $total91;
				 $data['total92'] = $total92;
				$data['adrenaline'] = ($adrenaline);

				//  ---------------------------other ADJUVANT----------------------

				$total81 = 0;
				$total82 = 0;
				$all_total8 = 0;
				$builder = $db->table('procedure_csa');
				$query = $builder->select("count(aj) as NO");
				$query = $builder->where('aj ','NO');
				if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
				$query = $builder->get();
				$record16 = $query->getResult();
				foreach($record16 as $row) {
					$other7 = $row->NO;
					$total81 += floatval($row->NO);
                $all_total8 += floatval($row->NO);
				}
				$other[] = array(
						'day'   => 'NO',
						'sell' => $other7
				);
		
				$builder = $db->table('procedure_csa');
				$query = $builder->select("count(aj) as YES");
				$query = $builder->where('aj ','YES');
				if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
				$query = $builder->get();
				$record17 = $query->getResult();
		
				foreach($record17 as $row) {
					$other7 = $row->YES;
					$total82 += floatval($row->YES);
					$all_total8 += floatval($row->YES);
				}
				$other[] = array(
						'day'   => 'YES',
						'sell' => $other7
				);
				$oth_number1 = (($total81/$all_total8)*100);
				$oth_number2 = (($total82/$all_total8)*100);
		 
				 $data['oth_perc1'] = number_format((float)$oth_number1, 2, '.', '')."%";
				 $data['oth_perc2'] = number_format((float)$oth_number2, 2, '.', '')."%";
				 $data['total81'] = $total81;
				 $data['total82'] = $total82;
				$data['other'] = ($other);

		return view('cnb/reports/csa_adjuvant_v', $data);                
    }


	public function epidural_component_adjuvant() {
        
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');
		
		$total11 = 0;
		$total12 = 0;
		$all_total1 = 0;
		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(opioid_dose) as NO");
		$query = $builder->where('opioid_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record3 = $query->getResult();
		foreach($record3 as $row) {
			$opioid_dose3 = $row->NO;
			$total11 += floatval($row->NO);
			$all_total1 += floatval($row->NO);
		}
		$opioide[] = array(
			    'day'   => 'NO',
			    'sell' => $opioid_dose3
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(opioid_dose) as YES");
		$query = $builder->where('opioid_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record2 = $query->getResult();

		foreach($record2 as $row) {
			$opioid_dose = $row->YES;
			$total12 += floatval($row->YES);
    $all_total1 += floatval($row->YES);
		}
		$opioide[] = array(
			    'day'   => 'YES',
			    'sell' => $opioid_dose
		);
		$o_number1 = (($total11/$all_total1)*100);
		$o_number2 = (($total12/$all_total1)*100);
		
		$data['o_perc1'] = number_format((float)$o_number1, 2, '.', '')."%";
		$data['o_perc2'] = number_format((float)$o_number2, 2, '.', '')."%";
		$data['total11'] = $total11;
		$data['total12'] = $total12;
		
		$data['opioide'] = ($opioide); 


		//  ---------------------------OPIOIDE ADJUVANT----------------------

		$total21 = 0;
		$total22 = 0;
		$all_total2 = 0;
		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(clonidina_dose) as NO");
		$query = $builder->where('clonidina_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record4 = $query->getResult();
		foreach($record4 as $row) {
			$clonidina_dose = $row->NO;
			$total21 += floatval($row->NO);
        $all_total2 += floatval($row->NO);	
		}
		$clonidina[] = array(
			    'day'   => 'NO',
			    'sell' => $clonidina_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(clonidina_dose) as YES");
		$query = $builder->where('clonidina_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record5 = $query->getResult();

		foreach($record5 as $row) {
			$clonidina_dose = $row->YES;
			$total22 += floatval($row->YES);
        $all_total2 += floatval($row->YES);
		}
		$clonidina[] = array(
			    'day'   => 'YES',
			    'sell' => $clonidina_dose
		);

		$c_number1 = (($total21/$all_total2)*100);
    $c_number2 = (($total22/$all_total2)*100);

    $data['c_perc1'] = number_format((float)$c_number1, 2, '.', '')."%";
    $data['c_perc2'] = number_format((float)$c_number2, 2, '.', '')."%";
    $data['total21'] = $total21;
    $data['total22'] = $total22;
		$data['clonidina'] = ($clonidina); 

		//  ---------------------------dexmeditomidine ADJUVANT----------------------
		$total31 = 0;
		$total32 = 0;
		$all_total3 = 0;

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(dexmeditomidine_dose) as NO");
		$query = $builder->where('dexmeditomidine_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record6 = $query->getResult();
		foreach($record6 as $row) {
			$dexmeditomidine_dose = $row->NO;
			$total31 += floatval($row->NO);
			$all_total3 += floatval($row->NO);
		}
		$dexmeditomidine[] = array(
			    'day'   => 'NO',
			    'sell' => $dexmeditomidine_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(dexmeditomidine_dose) as YES");
		$query = $builder->where('dexmeditomidine_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record7 = $query->getResult();

		foreach($record7 as $row) {
			$dexmeditomidine_dose = $row->YES;
			$total32 += floatval($row->YES);
			$all_total3 += floatval($row->YES);
		}
		$dexmeditomidine[] = array(
			    'day'   => 'YES',
			    'sell' => $dexmeditomidine_dose
		);

		$de_number1 = (($total31/$all_total3)*100);
		$de_number2 = (($total32/$all_total3)*100);
	
		$data['de_perc1'] = number_format((float)$de_number1, 2, '.', '')."%";
		$data['de_perc2'] = number_format((float)$de_number2, 2, '.', '')."%";
		$data['total31'] = $total31;
		$data['total32'] = $total32;
		$data['dexmeditomidine'] = ($dexmeditomidine); 


		//  ---------------------------dexamephasone ADJUVANT----------------------

		$total41 = 0;
		$total42 = 0;
		$all_total4 = 0;
		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(dexamephasone_dose) as NO");
		$query = $builder->where('dexamephasone_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record8 = $query->getResult();
		foreach($record8 as $row) {
			$dexamephasone_dose = $row->NO;
			$total41 += floatval($row->NO);
    $all_total4 += floatval($row->NO);
		}
		$dexamephasone[] = array(
			    'day'   => 'NO',
			    'sell' => $dexamephasone_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(dexamephasone_dose) as YES");
		$query = $builder->where('dexamephasone_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record9 = $query->getResult();

		foreach($record9 as $row) {
			$dexamephasone_dose = $row->YES;
			$total42 += floatval($row->YES);
			$all_total4 += floatval($row->YES);
		}
		$dexamephasone[] = array(
			    'day'   => 'YES',
			    'sell' => $dexamephasone_dose
		);

		$da_number1 = (($total41/$all_total4)*100);
    $da_number2 = (($total42/$all_total4)*100);

    $data['da_perc1'] = number_format((float)$da_number1, 2, '.', '')."%";
    $data['da_perc2'] = number_format((float)$da_number2, 2, '.', '')."%";
    $data['total41'] = $total41;
    $data['total42'] = $total42;
		$data['dexamephasone'] = ($dexamephasone);


		//  ---------------------------tramadol ADJUVANT----------------------

		$total51 = 0;
		$total52 = 0;
		$all_total5 = 0;
		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(trmadol_dose) as NO");
		$query = $builder->where('trmadol_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record10 = $query->getResult();
		foreach($record10 as $row) {
			$tramadol_dose = $row->NO;
			$total51 += floatval($row->NO);
			$all_total5 += floatval($row->NO);
		}
		$tramadol[] = array(
			    'day'   => 'NO',
			    'sell' => $tramadol_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(trmadol_dose) as YES");
		$query = $builder->where('trmadol_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record11 = $query->getResult();

		foreach($record11 as $row) {
			$tramadol_dose = $row->YES;
			$total52 += floatval($row->YES);
    $all_total5 += floatval($row->YES);
		}
		$tramadol[] = array(
			    'day'   => 'YES',
			    'sell' => $tramadol_dose
		);
		$t_number1 = (($total51/$all_total5)*100);
    $t_number2 = (($total52/$all_total5)*100);

    $data['t_perc1'] = number_format((float)$t_number1, 2, '.', '')."%";
    $data['t_perc2'] = number_format((float)$t_number2, 2, '.', '')."%";
    $data['total51'] = $total51;
    $data['total52'] = $total52;
		$data['tramadol'] = ($tramadol);


		//  ---------------------------kepamine ADJUVANT----------------------

		$total61 = 0;
		$total62 = 0;
		$all_total6 = 0;
		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(kepamine_dose) as NO");
		$query = $builder->where('kepamine_dose ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record12 = $query->getResult();
		foreach($record12 as $row) {
			$kepamine_dose = $row->NO;
			$total61 += floatval($row->NO);
        $all_total6 += floatval($row->NO);
		}
		$kepamine[] = array(
			    'day'   => 'NO',
			    'sell' => $kepamine_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(kepamine_dose) as YES");
		$query = $builder->where('kepamine_dose !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record13 = $query->getResult();

		foreach($record13 as $row) {
			$kepamine_dose = $row->YES;
			$total62 += floatval($row->YES);
        $all_total6 += floatval($row->YES);
		}
		$kepamine[] = array(
			    'day'   => 'YES',
			    'sell' => $kepamine_dose
		);

		$k_number1 = (($total61/$all_total6)*100);
    $k_number2 = (($total62/$all_total6)*100);

    $data['k_perc1'] = number_format((float)$k_number1, 2, '.', '')."%";
    $data['k_perc2'] = number_format((float)$k_number2, 2, '.', '')."%";
    $data['total61'] = $total61;
    $data['total62'] = $total62;
		$data['ketamine'] = ($kepamine);


			//  ---------------------------midazolam ADJUVANT----------------------

			$total71 = 0;
			$total72 = 0;
			$all_total7 = 0;
			$builder = $db->table('procedure_cse');
			$query = $builder->select("count(midazolam_dose) as NO");
			$query = $builder->where('midazolam_dose ','');
			if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
			$query = $builder->get();
			$record14 = $query->getResult();
			foreach($record14 as $row) {
				$midazolam_dose = $row->NO;
				$total71 += floatval($row->NO);
            $all_total7 += floatval($row->NO);
			}
			$midazolam[] = array(
					'day'   => 'NO',
					'sell' => $midazolam_dose
			);
	
			$builder = $db->table('procedure_cse');
			$query = $builder->select("count(midazolam_dose) as YES");
			$query = $builder->where('midazolam_dose !=','');
			if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
			$query = $builder->get();
			$record15 = $query->getResult();
	
			foreach($record15 as $row) {
				$midazolam_dose = $row->YES;
				$total72 += floatval($row->YES);
            $all_total7 += floatval($row->YES);
			}
			$midazolam[] = array(
					'day'   => 'YES',
					'sell' => $midazolam_dose
			);

			$m_number1 = (($total71/$all_total7)*100);
    $m_number2 = (($total72/$all_total7)*100);

    $data['m_perc1'] = number_format((float)$m_number1, 2, '.', '')."%";
    $data['m_perc2'] = number_format((float)$m_number2, 2, '.', '')."%";
    $data['total71'] = $total71;
    $data['total72'] = $total72;
			$data['midazolam'] = ($midazolam);


							//  ---------------------------adrenaline ADJUVANT----------------------

							$total91 = 0;
							$total92 = 0;
							$all_total9 = 0;
							$builder = $db->table('procedure_cse');
							$query = $builder->select("count(adrenaline_dose) as NO");
							$query = $builder->where('adrenaline_dose ','');
							if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
							$query = $builder->get();
							$record18 = $query->getResult();
							foreach($record18 as $row) {
								$adrenaline_dose = $row->NO;
								$total91 += floatval($row->NO);
								$all_total9 += floatval($row->NO);
							}
							$adrenaline[] = array(
									'day'   => 'NO',
									'sell' => $adrenaline_dose
							);
					
							$builder = $db->table('procedure_cse');
							$query = $builder->select("count(adrenaline_dose) as YES");
							$query = $builder->where('adrenaline_dose !=','');
							if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
							$query = $builder->get();
							$record19 = $query->getResult();
					
							foreach($record19 as $row) {
								$adrenaline_dose = $row->YES;
								$total92 += floatval($row->YES);
    				$all_total9 += floatval($row->YES);
							}
							$adrenaline[] = array(
									'day'   => 'YES',
									'sell' => $adrenaline_dose
							);

							$a_number1 = (($total91/$all_total9)*100);
            $a_number2 = (($total92/$all_total9)*100);
     
             $data['a_perc1'] = number_format((float)$a_number1, 2, '.', '')."%";
             $data['a_perc2'] = number_format((float)$a_number2, 2, '.', '')."%";
             $data['total91'] = $total91;
             $data['total92'] = $total92;
							$data['adrenaline'] = ($adrenaline);

			

				//  ---------------------------other ADJUVANT----------------------


				$builder = $db->table('procedure_cse');
				$query = $builder->select("count(aj_epidural_other) as NO");
				$query = $builder->where('aj_epidural_other ','NO');
				if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
				$query = $builder->get();
				$record16 = $query->getResult();
				foreach($record16 as $row) {
					$other7 = $row->NO;
				
				}
				$other[] = array(
						'day'   => 'NO',
						'sell' => $other7
				);
		
				$builder = $db->table('procedure_cse');
				$query = $builder->select("count(aj_epidural_other) as YES");
				$query = $builder->where('aj_epidural_other ','YES');
				if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
				$query = $builder->get();
				$record17 = $query->getResult();
		
				foreach($record17 as $row) {
					$other7 = $row->YES;
					
					
				}
				$other[] = array(
						'day'   => 'YES',
						'sell' => $other7
				);


				$data['other'] = ($other);

		return view('cnb/reports/epidural_component_adjuvant_v', $data);                
    }



	
	public function spinal_component_adjuvant() {
         	
		$db = \Config\Database::connect();

		$from_date = session()->get('from_date');
		$to_date = session()->get('to_date');
		
		$total11 = 0;
		$total12 = 0;
		$all_total1 = 0;
		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_opioid) as NO");
		$query = $builder->where('aj_spinal_opioid ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record3 = $query->getResult();
		foreach($record3 as $row) {
			$opioid_dose3 = $row->NO;
			$total11 += floatval($row->NO);
			$all_total1 += floatval($row->NO);
		}
		$opioide[] = array(
			    'day'   => 'NO',
			    'sell' => $opioid_dose3
				
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_opioid) as YES");
		$query = $builder->where('aj_spinal_opioid !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record2 = $query->getResult();

		foreach($record2 as $row) {
			$opioid_dose = $row->YES;
			$total12 += floatval($row->YES);
    $all_total1 += floatval($row->YES);
		}
		$opioide[] = array(
			    'day'   => 'YES',
			    'sell' => $opioid_dose
		);

		$o_number1 = (($total11/$all_total1)*100);
		$o_number2 = (($total12/$all_total1)*100);
		
		$data['o_perc1'] = number_format((float)$o_number1, 2, '.', '')."%";
		$data['o_perc2'] = number_format((float)$o_number2, 2, '.', '')."%";
		$data['total11'] = $total11;
		$data['total12'] = $total12;

		$data['opioide'] = ($opioide); 


		//  ---------------------------OPIOIDE ADJUVANT----------------------
		$total21 = 0;
		$total22 = 0;
		$all_total2 = 0;
		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_clonidne) as NO");
		$query = $builder->where('aj_spinal_clonidne ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record4 = $query->getResult();
		foreach($record4 as $row) {
			$clonidina_dose = $row->NO;
			$total21 += floatval($row->NO);
			$all_total2 += floatval($row->NO);			
		}
		$clonidina[] = array(
			    'day'   => 'NO',
			    'sell' => $clonidina_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_clonidne) as YES");
		$query = $builder->where('aj_spinal_clonidne !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record5 = $query->getResult();

		foreach($record5 as $row) {
			$clonidina_dose = $row->YES;
			$total22 += floatval($row->YES);
        $all_total2 += floatval($row->YES);
		}
		$clonidina[] = array(
			    'day'   => 'YES',
			    'sell' => $clonidina_dose
		);

		$c_number1 = (($total21/$all_total2)*100);
		$c_number2 = (($total22/$all_total2)*100);
	
		$data['c_perc1'] = number_format((float)$c_number1, 2, '.', '')."%";
		$data['c_perc2'] = number_format((float)$c_number2, 2, '.', '')."%";
		$data['total21'] = $total21;
		$data['total22'] = $total22;
		$data['clonidina'] = ($clonidina); 

		//  ---------------------------dexmeditomidine ADJUVANT----------------------
		$total31 = 0;
		$total32 = 0;
		$all_total3 = 0;
		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_dexmeditomidine) as NO");
		$query = $builder->where('aj_spinal_dexmeditomidine ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record6 = $query->getResult();
		foreach($record6 as $row) {
			$dexmeditomidine_dose = $row->NO;
			$total31 += floatval($row->NO);
			$all_total3 += floatval($row->NO);
		}
		$dexmeditomidine[] = array(
			    'day'   => 'NO',
			    'sell' => $dexmeditomidine_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_dexmeditomidine) as YES");
		$query = $builder->where('aj_spinal_dexmeditomidine !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record7 = $query->getResult();

		foreach($record7 as $row) {
			$dexmeditomidine_dose = $row->YES;
			$total32 += floatval($row->YES);
    $all_total3 += floatval($row->YES);
		}
		$dexmeditomidine[] = array(
			    'day'   => 'YES',
			    'sell' => $dexmeditomidine_dose
		);

		$de_number1 = (($total31/$all_total3)*100);
    $de_number2 = (($total32/$all_total3)*100);

    $data['de_perc1'] = number_format((float)$de_number1, 2, '.', '')."%";
    $data['de_perc2'] = number_format((float)$de_number2, 2, '.', '')."%";
    $data['total31'] = $total31;
    $data['total32'] = $total32;
		$data['dexmeditomidine'] = ($dexmeditomidine); 


		//  ---------------------------dexamephasone ADJUVANT----------------------

		$total41 = 0;
		$total42 = 0;
		$all_total4 = 0;
		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_dexamethasone) as NO");
		$query = $builder->where('aj_spinal_dexamethasone ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record8 = $query->getResult();
		foreach($record8 as $row) {
			$dexamephasone_dose = $row->NO;
			$total41 += floatval($row->NO);
			$all_total4 += floatval($row->NO);
		}
		$dexamephasone[] = array(
			    'day'   => 'NO',
			    'sell' => $dexamephasone_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_dexamethasone) as YES");
		$query = $builder->where('aj_spinal_dexamethasone !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record9 = $query->getResult();

		foreach($record9 as $row) {
			$dexamephasone_dose = $row->YES;
			$total42 += floatval($row->YES);
			$all_total4 += floatval($row->YES);
		}
		$dexamephasone[] = array(
			    'day'   => 'YES',
			    'sell' => $dexamephasone_dose
		);

		$da_number1 = (($total41/$all_total4)*100);
		$da_number2 = (($total42/$all_total4)*100);
	
		$data['da_perc1'] = number_format((float)$da_number1, 2, '.', '')."%";
		$data['da_perc2'] = number_format((float)$da_number2, 2, '.', '')."%";
		$data['total41'] = $total41;
		$data['total42'] = $total42;
		$data['dexamephasone'] = ($dexamephasone);


		//  ---------------------------tramadol ADJUVANT----------------------

		$total51 = 0;
		$total52 = 0;
		$all_total5 = 0;
		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_tramadol) as NO");
		$query = $builder->where('aj_spinal_tramadol ','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record10 = $query->getResult();
		foreach($record10 as $row) {
			$tramadol_dose = $row->NO;
			$total51 += floatval($row->NO);
			$all_total5 += floatval($row->NO);
		}
		$tramadol[] = array(
			    'day'   => 'NO',
			    'sell' => $tramadol_dose
		);

		$builder = $db->table('procedure_cse');
		$query = $builder->select("count(aj_spinal_tramadol) as YES");
		$query = $builder->where('aj_spinal_tramadol !=','');
		if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
		$query = $builder->get();
		$record11 = $query->getResult();

		foreach($record11 as $row) {
			$tramadol_dose = $row->YES;
			$total52 += floatval($row->YES);
			$all_total5 += floatval($row->YES);
		}
		$tramadol[] = array(
			    'day'   => 'YES',
			    'sell' => $tramadol_dose
		);

		$t_number1 = (($total51/$all_total5)*100);
		$t_number2 = (($total52/$all_total5)*100);
	
		$data['t_perc1'] = number_format((float)$t_number1, 2, '.', '')."%";
		$data['t_perc2'] = number_format((float)$t_number2, 2, '.', '')."%";
		$data['total51'] = $total51;
		$data['total52'] = $total52;
		$data['tramadol'] = ($tramadol);


		

				//  ---------------------------adrenaline ADJUVANT----------------------

				$total91 = 0;
				$total92 = 0;
				$all_total9 = 0;
				$builder = $db->table('procedure_cse');
				$query = $builder->select("count(aj_spinal_adrenaline) as NO");
				$query = $builder->where('aj_spinal_adrenaline ','');
				if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
				$query = $builder->get();
				$record18 = $query->getResult();
				foreach($record18 as $row) {
					$adrenaline_dose = $row->NO;
					$total91 += floatval($row->NO);
					$all_total9 += floatval($row->NO);
				}
				$adrenaline[] = array(
						'day'   => 'NO',
						'sell' => $adrenaline_dose
				);
		
				$builder = $db->table('procedure_cse');
				$query = $builder->select("count(aj_spinal_adrenaline) as YES");
				$query = $builder->where('aj_spinal_adrenaline !=','');
				if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
				$query = $builder->get();
				$record19 = $query->getResult();
		
				foreach($record19 as $row) {
					$adrenaline_dose = $row->YES;
					$total92 += floatval($row->YES);
    				$all_total9 += floatval($row->YES);
				}
				$adrenaline[] = array(
						'day'   => 'YES',
						'sell' => $adrenaline_dose
				);

				$a_number1 = (($total91/$all_total9)*100);
				$a_number2 = (($total92/$all_total9)*100);
		 
				 $data['a_perc1'] = number_format((float)$a_number1, 2, '.', '')."%";
				 $data['a_perc2'] = number_format((float)$a_number2, 2, '.', '')."%";
				 $data['total91'] = $total91;
				 $data['total92'] = $total92;
				$data['adrenaline'] = ($adrenaline);

			

				//  ---------------------------other ADJUVANT----------------------


				$total81 = 0;
				$total82 = 0;
				$all_total8 = 0;
				$builder = $db->table('procedure_cse');
				$query = $builder->select("count(aj_epidural_other) as NO");
				$query = $builder->where('aj_epidural_other ','NO');
				if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
				$query = $builder->get();
				$record16 = $query->getResult();
				foreach($record16 as $row) {
					$other7 = $row->NO;
				}
				// $other[] = array(
				// 		'day'   => 'NO',
				// 		'sell' => $other7
				// );
		
				$builder = $db->table('procedure_cse');
				$query = $builder->select("aj_epidural_other");
				if($from_date && $to_date){
          $query = $builder->where('created_at >=',date('Y-m-d',strtotime($from_date)));
          $query = $builder->where('created_at <=',date('Y-m-d',strtotime($to_date)));
        }
				// $query = $builder->like('aj_epidural_other','[{"name":"","dose":""}]');

				
				$query = $builder->get();
				$record17 = $query->getResult();
				
				foreach($record17 as $key => $row) {
					$other = $record17[11]->aj_epidural_other;
					// foreach($other as $key =>$val){
						
					// 	$other7 = $val;
					// }
					// print_r($other);die();
				}

				$other[] = array(
					'day'   => 'YES',
					'sell' => $other7
				);
				$data['other'] = ($other);

				// $aj_spinal_op = $info['aj_spinal_opioid'];
                // $aj_spinal_opioid = json_decode($other7, true);
				// var_dump($aj_spinal_opioid);die();
				
		return view('cnb/reports/spinal_component_adjuvant_v', $data);                
    }





}