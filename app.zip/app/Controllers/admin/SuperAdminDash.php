<?php 
namespace App\Controllers\admin;
use App\Controllers\BaseController;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\CategoriesModel;
use App\Models\OrganisationModel;

class SuperAdminDash extends BaseController{
  
    public function index(){
        $dr_id = session()->get('dr_id');
        // print_r($dr_id );die();
        if($dr_id ){

            $dash=['a,b,c'];
            $data['dash_b'] = $dash;

            $model = new OrganisationModel();
            $details  = $model->get()->getResultArray();
            $data['org'] = $details;

            return view('admin/super-admin-dashboard', $data);
        }else{
            return view('admin/super-admin-login');
        }

        
    }

    public function power_bi_dash(){

        $dr_id = session()->get('dr_id');
       
        if($dr_id ){

            $dash=['a,b,c'];
            $data['dash_b'] = $dash;

            $model = new OrganisationModel();
            $details  = $model->get()->getResultArray();
            $data['org'] = $details;

            return view('admin/Power-BI-dashboard', $data);
        }else{
            return view('admin/super-admin-login');
        }
    }
}
?>
