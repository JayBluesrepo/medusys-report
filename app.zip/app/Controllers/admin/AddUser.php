<?php 
namespace App\Controllers\admin;
use App\Controllers\BaseController;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\AdminModel;

class AddUser extends BaseController
{
    public function index(){
        $org_id = session()->get('org_id');
        if($org_id ){
            $adduser=['a,b,c'];
            $data['add_user'] = $adduser;
            
            return view('admin/add-user', $data);
        }else{
            return view('admin/super-admin-login');
        }
        
    }

    public function create_user(){
        
        if($this->request->getMethod() == 'post'){
            $organisation = $this->request->getVar('organisation');
            $role = $this->request->getVar('role');
            $userid = $this->request->getVar('userid');
            $password = $this->request->getVar('password');

            $userData = array(
                'user_id'=> $userid,
                'password'=> $password, 
                'organization'=>$organisation,
                'role'=> $role
            );
            
            $model = new AdminModel(); 
            $model->save($userData);
            $insertedID = $model->insertID();

            if($insertedID){
                return json_encode(array(
                     'result'    => 1,
                     'message'   => 'User Created Successfully.....'
                    //  'msg' => $userData
                ));
           }
           else{
                return json_encode(array(
                     'result'    => 0,
                     'message'     => 'Something went wrong.....'
                ));
            }
        }
    }
}
?>